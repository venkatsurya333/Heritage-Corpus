Goa is a state of India. Goans are commonly said to be born with music and football in their blood because both are deeply entrenched in Goan culture.[1][2][3]

Religion

Velha Goa is considered to be the heart of Goan culture and religion.
According to the 1909 statistics in the Catholic Encyclopedia, the total Catholic population was 293,628 out of a total population 365,291 (80.33%).[4] Within Goa, there has been a steady decline of Christianity due to Goan emigration, and a steady rise of other religions, due to massive non-Goan immigration since the Annexation of Goa. Native Goans are outnumbered by non-Goans in Goa, but Christianity remains prevalent in the state, with a higher percentage of Christians than the national average. [5] Conversion seems to play little role in the demographic change. According to the 2011 census, in a population of 1,458,545 people, 66.1% were Hindu, 25.1% were Christian, 8.3% were Muslim and 0.1% were Sikh.[6]

Festivals
The most popular celebrations in the Indian state of Goa include the Goa Carnival, (Konkani: Intruz), Shigmo and São João (Feast of John the Baptist).[7] The most popular festivals in Goa include Ganesh Chaturthi (Konkani: Chavath),[8] Diwali,[9] Christmas (Konkani: Natalam),[10] Easter (Konkani: Paskanchem Fest), Samvatsar Padvo or Sanvsar Padvo and the feast of St. Francis Xavier, who is known as Goencho Saib by the Catholic Community in Goa.[11][12]

Education
Main article: Education in Goa
Cuisine
Main article: Goan cuisine
Rice with fish curry (Xit kodi in Konkani) is the staple diet in Goa.[13] Goan cuisine is renowned for its rich variety of fish dishes cooked with elaborate recipes. Coconut and coconut oil is widely used in Goan cooking along with chili peppers, spices and vinegar giving the food a unique flavour. Pork and beef dishes such as Vindalho,[14][15] Xacuti and Sorpotel are cooked for major occasions among the Catholics. An exotic Goan vegetable stew, known as Khatkhate, is a very popular dish during the celebrations of festivals, Hindu and Christian alike. Khatkhate contains at least five vegetables, fresh coconut, and special Goan spices that add to the aroma. A rich egg-based multi-layered sweet dish known as bebinca is a favourite at Christmas.[16] Cashew feni is made from the fermentation of the fruit of the cashew tree, while coconut feni is made from the sap of toddy palms.

Architecture
Main article: Architecture of Goan Catholics

Our Lady of the Immaculate Conception Church at Panjim.
The architecture of Goa shows a distinct Portuguese influence. Fontainhas in Panaji has been declared a cultural quarter, showcasing the life, architecture and culture of Goa.[17]

The Churches and Convents of Goa are a group of six churches that are a UNESCO World Heritage Site.[18] The Basilica of Bom Jesus holds the mortal remains of St. Francis Xavier, the patron saint of Goa.[19] Once every ten years, the body is taken down for veneration and for public viewing. The last such event was conducted in 2024.[20]

Influences from other eras (Kadambas of Goa, Maratha Empire) are visible in some of Goa's temples, notably the Mahadev Temple[21] and Saptakoteshwar Temple.[22]

Sports
See also: Goans in sports
Football is the most popular sport in Goa along with Cricket.[23] Athletics, chess, hockey, swimming, table tennis and basketball are other popular sports in Goa. Fishing is also a popular recreational activity.

Science
See also: Goans in science and technology
Arts
Music
Main article: Music of Goa
Goan Catholics have been performing Western classical music since the 1500s, because it is an integral part of the Catholic liturgy. Mando, dekhnni, dulpod and tiatr are traditional Goan musical forms in Konkani developed from Western Music.

Goan Hindus are very fond of Natak, Bhajan and Kirtan. Many famous Indian Classical singers hail from Goa, such as, Kishori Amonkar, Kesarbai Kerkar, Jitendra Abhisheki, Prabhakar Karekar.


Fugdi Dancers from South Goa
Dance
Some traditional Goan dance forms are dekhnni, fugdi, corridinho and dashavatara. Western social dancing is a part of most celebrations.

Theatre
Goans are very fond of theatre and acting. Kalo and dashavatar were popular art forms. Marathi Nataks have been very popular among Hindus in Goa for the past two centuries. Tiatr is the major Goan form of theatre common amongst Catholics and is the most commercial offering as it has entertained Goans not only in Goa but also in Mumbai and Pune (which are major cities of India and have a sizeable Goan population) and in the Gulf regions of UAE, Kuwait and so on.

Cinema
See also: Konkani cinema
Literature
Main article: Goan literature
Language
The majority of Goans speak Konkani as their first language, while the remaining speak other languages, like Hindi, Portuguese or Marathi as their primary language.[citation needed] However, practically all Goans can speak and understand Konkani. Konkani is an important part of the Goan identity that binds together all Goans.

Tourism
Main article: Tourism in Goa
Goa developed an international reputation in the 1960s as one of the prime stops on the legendary India-Nepal "hippie trail". In the mid-1960s, several Westerners, including "Eight Finger Eddie" walked over the hill to Calangute, and decided to create a community for Westerners. In the early years, Calangute and Baga were the center of this scene, but it grew over the years to include other nearby cities like Anjuna Beach, which became, and arguably still is, the center of the Western youth culture of Goa. By the mid-1980s, there were over 8000 Westerners living in Goa, mostly from Western Europe. The scene was marked by drug culture, trance music and free love. Goa remains today an international center of youth culture.

Starting in the late 1990s, Goa began to attract a more "upscale" audience, which in turn drove prices up, which in turn drove many in the "hippie" community to other less-expensive areas. Arambol—the beach community furthest away from "civilization", like electricity and running water—became the center of a battle between those wanting to turn Goa into a more traditional upscale resort area, and those wanting Goa to retain its traditional rustic counterculture appeal.