const goa = {
    name: "Goa",
    culture: {
        description: "Goans are commonly said to be born with music and football in their blood.",
        religion: {
            heart: "Velha Goa",
            statistics: {
                totalPopulation: 1458545,
                hindu: "66.1%",
                christian: "25.1%",
                muslim: "8.3%",
                sikh: "0.1%"
            },
            declineOfChristianity: "Due to Goan emigration and non-Goan immigration."
        },
        festivals: [
            "Goa Carnival",
            "Shigmo",
            "São João",
            "Ganesh Chaturthi",
            "Diwali",
            "Christmas",
            "Easter",
            "Feast of St. Francis Xavier"
        ],
        education: {
            description: "Education in Goa is an important aspect of its culture."
        },
        cuisine: {
            staple: "Rice with fish curry (Xit kodi in Konkani)",
            description: "Renowned for its rich variety of fish dishes.",
            notableDishes: [
                "Vindalho",
                "Xacuti",
                "Sorpotel",
                "Khatkhate",
                "Bebinca"
            ],
            beverages: [
                "Cashew feni",
                "Coconut feni"
            ]
        },
        architecture: {
            description: "Distinct Portuguese influence.",
            notableStructures: [
                "Our Lady of the Immaculate Conception Church",
                "Basilica of Bom Jesus"
            ],
            UNESCOWorldHeritage: "Churches and Convents of Goa"
        },
        sports: {
            popularSports: [
                "Football",
                "Cricket",
                "Athletics",
                "Chess",
                "Hockey"
            ],
            recreationalActivities: "Fishing"
        },
        arts: {
            music: {
                description: "Goan Catholics have been performing Western classical music since the 1500s.",
                traditionalForms: [
                    "Mando",
                    "Dekhnni",
                    "Dulpod",
                    "Tiatr"
                ]
            },
            dance: [
                "Dekhnni",
                "Fugdi",
                "Corridinho",
                "Dashavatara"
            ],
            theatre: {
                description: "Goans are fond of theatre and acting.",
                popularForms: [
                    "Kalo",
                    "Dashavatar",
                    "Marathi Nataks",
                    "Tiatr"
                ]
            }
        },
        language: {
            primaryLanguage: "Konkani",
            otherLanguages: [
                "Hindi",
                "Portuguese",
                "Marathi"
            ]
        },
        tourism: {
            description: "Goa developed an international reputation in the 1960s.",
            notableLocations: [
                "Calangute",
                "Baga",
                "Anjuna Beach"
            ],
            culturalSignificance: "Center of youth culture."
        }
    }
};

console.log(goa);
