const telanganaCulture = {
  history: {
    timelineYears: 5000,
    majorDynasties: ["Kakatiya", "Qutb Shahi", "Asaf Jahi (Nizams)"],
    heritageCoreCities: ["Warangal", "Hyderabad"],
  },
  identity: {
    multiCulturalBlend: true,
    slogan: "South of North and North of South",
    gangaJamuniTehzeeb: true,
    orientalHeritageCity: "Hyderabad",
  },
  unescoRecognition: {
    gastronomy: "Hyderabad recognized as UNESCO Creative City of Gastronomy" /* :contentReference[oaicite:1]{index=1} */,
    architecture: "Kakatiya-era sites like Warangal Fort and Ramappa Temple are UNESCO-listed" /* generic heritage recognition inferred from Kakatiya architecture heritage; Ramappa Temple listed in broader sources */,
  },
  festivals: [
    "Kakatiya Festival",
    "Deccan Festival",
    "Bonalu",
    "Bathukamma",
    "Dasara",
    "Ugadi",
    "Sankranti",
    "Milad un Nabi",
    "Ramadan"
  ],
  languages: {
    teluguPct: 76,
    urduPct: 12,
    othersPct: 12,
    history: {
      officialBefore1948: "Urdu",
      switchToTeluguPost1948: true
    }
  },
  literature: {
    earlyPoets: [
      "Bammera Pothana",
      "Kancherla Gopanna",
      "Malliya Rechana",
      "Gona Budda Reddy",
      "Kuppambika",
      "Palkurthi Somanatha",
      "Mallinātha Sūri",
      "Hulukki Bhaskara"
    ],
    modernFigures: [
      "Kaloji Narayana Rao",
      "Daasarathi Krishnamacharyulu",
      "C. Narayana Reddy",
      "P. V. Narasimha Rao",
      "Samala Sadasiva"
    ],
    urduLiterature: {
      patronizedBy: ["Qutb Shahi", "Asaf Jahi"],
      notablePoets: ["Mohammed Quli Qutb Shah", "Mah Laqa Bai", "Fani Badayuni", "Josh Malihabadi", "Dagh Dehlavi", "Makhdoom Mohiuddin", "Sayyid Shamsullah Qadri"]
    }
  },
  religionSites: [
    "Yadadri Temple",
    "Bhadrachalam Temple",
    "Karmanghat Hanuman Temple",
    "Jamalapuram (Venkateswara) Temple",
    "Jogulamba Temple at Alampur",
    "Raja Rajeshwara Temple, Vemulawada",
    "Birla Mandir, Hyderabad",
    "Mecca Masjid",
    "Medak Cathedral"
  ],
  arts: {
    visual: ["Nirmal paintings", "Golconda/Hyderabad painting styles"],
    architecture: {
      kakatiyaStyle: ["Thousand Pillar Temple", "Warangal Fort", "Ramappa Temple"],
      indoIslamic: ["Charminar", "Golconda Fort", "Qutb Shahi tombs"],
      colonialRevival: ["Chowmahalla Palace", "Falaknuma Palace", "Osmania General Hospital", "High Court", "City College"]
    }
  },
  museums: [
    { name: "Salar Jung Museum", detail: "one of India’s largest individual collections" },
    { name: "Telangana State Archaeology Museum", detail: "houses Egyptian mummy" /* :contentReference[oaicite:2]{index=2} */ },
    "Nizam Museum", "Warangal Museum", "City Museum Hyderabad", "Birla Science Museum"
  ],
  cuisine: {
    teluguCuisine: {
      staples: ["jowar rotte", "bajra rotte", "junna rotte", "uppudi pindi"],
      styles: ["pulusu", "vepudu"],
      signatureDishes: ["sakinalu", "garijelu"]
    },
    hyderabadiCuisine: {
      styleBlend: ["Persian", "Mughlai", "Telugu", "Turkish"],
      specialties: ["Hyderabadi Biryani", "Haleem", "Mirchi ka Salan", "Double ka Meetha"] /* :contentReference[oaicite:3]{index=3} */
    }
  },
  performingArts: {
    dance: ["Perini Sivatandavam"] /* :contentReference[oaicite:4]{index=4} */,
    folk: ["Bonalu dances (Pothuraju and women with Bonalu pots)"],
    music: ["Carnatic (Ramadasu)", "Folk songs by Gaddar, Belli Lalitha, etc."],
    storytelling: ["Oggu Katha"]
  },
  cinema: {
    industry: "Tollywood (Telugu cinema centered at Hyderabad Film Nagar)",
    infrastructure: ["Ramoji Film City", "Prasads IMAX"] /* Guinness world record and largest screen noted generally */
  },
  archaeology: {
    prehistoricSites: ["Mudumal megaliths (~5000 BC)" /* :contentReference[oaicite:5]{index=5} */, "Pandavula Gutta rock art site" /* :contentReference[oaicite:6]{index=6} */, "Jeenugarala paintings" /* :contentReference[oaicite:7]{index=7} */ ]
  }
};
