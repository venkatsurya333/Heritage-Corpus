The Culture of Telangana in India has a cultural history of about 5,000 years[citation needed]. The region emerged as the foremost centre of culture in Indian subcontinent during the rule of Kakatiyas, the Qutb Shahis and Asaf Jahi dynasties— (also known as the Nizams of Hyderabad). The rulers patronage and interest for culinary, arts and culture transformed Telangana into a multi-cultural region where two different cultures coexist together, thus making Telangana the representative of the Deccan Plateau and its heritage with Warangal and Hyderabad being its epicenter. Hyderabadi cuisine and Kakatiya architecture both from Telangana, are on the list of UNESCO creative city of gastronomy and UNESCO World Heritage Site. The regions major cultural events celebrated are "Kakatiya Festival" and Deccan Festival along with religious festivals Bonalu, Bathukamma, Dasara, Ugadi, Sankranthi, Milad un Nabi and Ramadan.[1]

Telangana State has long been a meeting place for diverse languages and cultures. It is known as "South of North and North of South".[2] It is also known for its Ganga-Jamuna Tehzeeb and the capital Hyderabad is an epicenter of oriental culture making it first Heritage city of India.[3][4][5]

Languages of Telangana
About 76% of the population of Telangana speak Telugu, 12% speak Urdu, and 12% speak other languages.[6][7] Before 1948, Urdu was the official language of Hyderabad State, and due to a lack of Telugu-language in educational institutions, Urdu was spoken by the educated people of Telangana, including the elite. After 1948, once Hyderabad State joined the new Republic of India, Telugu became the language of government, and as Telugu was introduced as the medium of instruction in schools and colleges, the use of Urdu among non-Muslims decreased.[8]

Literature
See also: List of Telangana poets
Poets of Telangana from the early era include Bammera Pothana, Kancherla Gopanna or Bhakta Ramadasu, Malliya Rechana, Gona Budda Reddy, Kuppambika, Palkurthi Somanatha, Mallinātha Sūri, and Hulukki Bhaskara. In the modern era poets include such figures as Padma Vibhushan Kaloji Narayana Rao, Sahitya Akademi Award recipient Daasarathi Krishnamacharyulu, and Jnanpith Award recipient C. Narayana Reddy, as well as P. V. Narasimha Rao, ninth Prime Minister of India. Samala Sadasiva was selected for the Kendra Sahitya Puraskaram distinction. His book Swaralayalu on the subject of Hindustani classical music won the award for the year 2011.[9]


Statue of Bammera Pothana in Bammera village of Jangoan district
Urdu literature has always enjoyed patronage from successive rulers of the Qutb Shahi and Asaf Jahi era. Mohammed Quli Qutb Shah, the fifth ruler of the Qutb Shahi dynasty is regarded as one of the pioneers of early Urdu poetry.

During the rule of Nizams of Hyderabad, printing was introduced in the area. The 18th-century courtesan and poet Mah Laqa Bai are also regarded as a pioneer of this time. During the 18th 19th and 20th centuries, many Urdu scholars emigrated to Hyderabad seeking the patronage of the Nizam. This included Fani Badayuni, Josh Malihabadi and Dagh Dehlavi. Other scholars of repute from Telangana included Makhdoom Mohiuddin and Sayyid Shamsullah Qadri.

Religion
Main article: Demographics of Telangana
The major religions of the people are Hinduism and Islam,[10] though Buddhism was the dominant religion up to the 6th century. Hinduism was revived during the time of the Chalukyas and the Kakantiyas in the 12th century. The Vijayanagar rule saw the glorious days of Hinduism when the famed emperors, Krishnadeva Raya in particular, built new temples and beautified the old ones. Shiva, Vishnu, Hanuman and Ganapati have been the popular Hindu Gods. The Vugra Narasimha Swami Temple at Yadagirigutta and Thousand Pillar Temple at Warangal are among the oldest shrines in the state attracting people from different parts of the country for hundreds of years.

In terms of influence, Islam occupies the second place. It started spreading from the 14th century onwards. Mosques began to come up in many parts of the region during the Muslim rule. Christianity began to spread from 1701, especially among the socially disabled people. Educational institutions and churches grew in number in the Circars in the 18th-19th centuries when the East India Company and later the British government encouraged them. Other European countries were also active in building churches and taking care of the weaker sections of the people.

Major Religious Structures.
Yadadri : Lord Vishnu (whose reincarnation is Lord Narasimha). The main deity is Lakshmi Narasimha Swamy.[11] Located in Yadadri District. In Ancient days Sri Yada Maharshi son of Sri Rushyashrunga Maharshi with the Blessings of Anjaneya Swamy had performed great penance for Lord Narasimha Swamy. After securing blessing for his penance Lord Narasimha had come into existence in Five Avatharas called as Sri Jwala Narasimha, Sri Yogananda Narasimha, Sri Ugra Narasimha, Sri Gandaberunda Narasimha, Sri Lakshmi Narasimha. As such this is known

Bhadrachalam Temple is a Lord Sree Sita Ramachandra Swamy Temple in Bhadrachalam, Bhadradri District. Bhadrachalam-The name derived from Bhadragiri (Mountain of Bhadra-a boon child of Meru and Menaka). According to an Ithihasas, the significance of this shrine dates back to the Ramayana Era. This coherent hill place existed in "Dandakaranya" Of Ramayana period where Rama with his consort Sita and brother Laxmana had spent their vanavasa- and Parnashaala (the place connected to the famous Golden Deer and the place from where Sita was abducted by Ravana.) is also in the vicinity of this temple site. It is at this Mandir site that, long after Ramavatara, Bhagawan Mahavishnu manifested Himself as Rama again to fulfil a promise He made to His Bhakta Bhadra, who continued his Tapas through Yugas, praying for the grace of the Bhagawan Sri Ramachandra murthy.[12]

Karmanghat Hanuman TempleThe Karmanghat Hanuman Temple is one of the oldest and popular Hindu temples in Hyderabad, in the state of Telangana, India. The presiding deity of the temple is Lord Hanuman and the temple complex also houses other deities viz. Lord Rama, Lord Shiva, Goddess Saraswathi, Goddess Durga, Goddess Santoshimata, Lord Venugopala Swamy, and Lord Jagannath. The temple is located at Karmanghat, near Santoshnagar and closer to the Nagarjuna Sagar Ring Road.

Jamalapuram Temple is a Lord Sree Venkateswara Swamy Temple in Jamalapuram, near Errupalem, Khammam District is a famous temple in Khammam district of Telangana and is famously known as Telangana Tirupathi. The presiding deity in this temple is Lord Balaji and is said to be a swayambhu Lord, who self-manifested in this place. Since it is a swayambhoo temple, this temple seems to have been in existence from thousands of years. It was renovated by Sri Krishna Devarayalu, the emperor of Vijayanagara kingdom. The temple is located in a serene pleasant ambience surrounded by lush green hills. The temple has sub-shrines for Padmavathi Ammavaru, Sri Alivelu Ammavaru, Lord Shiva, Lord Ganesh, Lord Ayyappa, and Lord Anjaneya. Gadwal jogulamba temple.

Sri Venkateswara Swamy Temple in Jamalapuram

Alampur Jogulamba TempleJogulamba temple is a Hindu temple dedicated to Goddess Jogulamba, a form of Shakti located in Alampur, Telangana, India. The temple is one of the Maha Shakti Peethas, a group of eighteen (Ashtadasa) temples considered the most significant shrines and pilgrimage destinations in Shaktism. Alampur is located on the banks of the Tungabhadra river near its confluence with Krishna river. Jogulamba temple is located in the same complex as that of the Navabrahma Temples, a group of nine Shiva temples built in the seventh-eighth century CE.

Sri Raja Rajeshwara temple, Vemulawada is a site of pilgrimage for both Hindu (particularly devotees of Vishnu and Shiva) and Muslim worshippers. Built by Chalukya Kings between AD 750 and 975, the complex is named for its presiding deity Sri Raja Rajeshwara Swamy, an incarnation of Lord Shiva. It houses several temples dedicated to other deities including Sri Rama, Lakshmana, Lakshmi, Ganapathy, Lord Padmanabha Swamy and Lord Bhimeshwara.This Shrine is popularly known as ‘Dakshina Kashi’ [Southern Banaras][13] and also as "Harihara Kshetram" for their being two Vaishnava Temples in main Temple complex i.e., Sri Anantha Padmanabha Swamy Temple & Sri Seetharama Chandra Swamy Temple The complex also contains a 400-year-old mosque which stands as an ample evidence for religious tolerance. The temple is located in Karimnagar District. kondagattu hanuman temple located in jagithyal district.

Birla Mandir, Hyderabad: Built on a 280 feet (85 m) high hillock called Naubath Pahad on a 13 acres (53,000 m2) plot in Hyderabad

Basara: Gnana Saraswati Temple (Goddess of Knowledge) is located on the Deccan plateau

Mecca Masjid, is one of the oldest mosques in Hyderabad, Telangana in India, And it is one of the largest Mosques in India. Makkah Masjid is a listed heritage building in the old city of Hyderabad, close to the historic landmarks of Chowmahalla Palace, Laad Bazaar, and Charminar. Muhammad Quli Qutb Shah, the fifth ruler of the Qutb Shahi dynasty, commissioned bricks to be made from the soil brought from Mecca, the holiest site of Islam, and used them in the construction of the central arch of the mosque, thus giving the mosque its name. It formed the centerpiece around which the city was planned by Muhammad Quli Qutub Shah.[14]

Medak Church at Medak in Telangana, India, is the largest church in Telangana and has been the cathedral church of the Diocese of Medak of the Church of South India since 1947. Originally built by British Wesleyan Methodists, it was consecrated on 25 December 1924. The Medak diocese is the single largest diocese in Asia and the second in the world after the Vatican.[15] The church was built under the stewardship of the Methodist Christian, the Reverend Charles Walker Posnett, who was driven by the motto My best for my Lord. Charles Posnett had arrived in Secunderabad in 1895, and after first ministering among British soldiers at Trimullghery, had launched into the villages and had reached Medak village in 1896.[16]

Banjara (Lambadi) spiritual / religious persons
Jairam Bapuji,[17] Sevya Bapuji[18] are the very famous Banjara Or Lambadi Spiritual Persons from Balu Thanda / Jairam Thanda, Madgul Mandal, Mahabubnagar District, Telangana.

Festivals
Festivals are celebrated with much fervor and people used to go to temples on these days to offer special prayers. Some of the Festivals are Bathukamma, Dasara, Bonalu, Eid ul fitr, Bakrid, Ugadi, Makara Sankranti, Guru Purnima, Sri Rama Navami, Hanuman Jayanti, Holi, Peerla Panduga, Rakhi Pournami, Vinayaka Chaviti, Nagula Panchami, Krishnashtami, Deepavali, Mukkoti Ekadasi, Karthika Purnima and Ratha Saptami.

Bathukamma flower arrangement

Telangana's citizens (Telanganites) also celebrate festivals like 'Bonalu, Batukamma' which are specific to the region of Telangana[19] all over Telangana districts, Yedupayala Jatara in Medak, Sammakka Saralamma in Warangal district.


Mallanna Patnam
Visual arts
Paintings
Nirmal paintings are a popular form of painting done in Nirmal in Adilabad District. The paintings have golden hues.[20][21] The region is well known for its Golconda and Hyderabad painting styles which are branches of Deccan painting.[22] Developed during the 16th century, the Golconda style is a native style blending foreign techniques and bears some similarity to the Vijayanagara paintings of neighbouring Mysore. A significant use of luminous gold and white colours is generally found in the Golconda style.[23] The Hyderabad style originated in the 17th century under the Nizams. Highly influenced by Mughal painting, this style makes use of bright colours and mostly depicts regional landscape, culture, costumes and jewellery.[22]

Sculpture
Ramappa Temple - It lies in a valley at Palampet village of Venkatapur Mandal, in erstwhile Mulug Taluq of Warangal district, a tiny village long past its days of glory in the 13th-14th centuries.[24] An inscription in the temple dates it to the year 1213 and said to have been built by a General Recherla Rudra, during the period of the Kakatiya ruler Ganapati Deva.

Mallanna Swamy - This medieval temple is a Shivalaya (where Shiva is worshipped) and named after the sculptor Ramappa. It is the only temple in the world named after its sculptor/architect. Its presiding deity, Ramalingeswara, is the form of Shiva and a personal god of the Avatar of Vishnu, Rama. The history says that it took 40 years to build this temple. Planned and sculpted by Ramappa, the temple was built on the classical pattern of being lifted above the world on a high star-shaped platform. Intricate carvings line the walls and cover the pillars and ceilings. Starting at its base to its wall panels, pillars and ceiling are sculpted figures drawn from Hindu mythology.[25] The roof (garbhalayam) of the temple is built with bricks, which are so light that they are able to float on water.[26]

Architecture
Sangameshwar temple at Alampur

Main article: Architecture of Telangana
Mecca Masjid frontage

Alampur Temples:There are a total of nine temples in Alampur, all dedicated to Shiva. These temples date back to the 7th century A.D, and were built by the Badami Chalukyas rulers, who were great patrons of art and architecture. Even after a time span of several hundred years, these grand temples still stand firm reflecting the rich architectural heritage of the country.

Bhadrachalam Temple
The temples are emblematic of the Northern and Western Indian styles of architecture. They do not reflect the Dravidian style of architecture as is generally common with the temples in this region. The shikharas of all these temples have a curvilinear form and are adorned with the miniature architectural devices. The plans and decoration similar to that of the rock cut temples. The Alampur Navabhrama Temples are historically important and reflect remarkable architectural skills.

Alampur was previously Known as Halampuram, Hamalapuram And Alampuram. Name of this place as Hatampura, mentioned in the inscription dated AD 1101 belongs to Western Chalukya[27]

Kakatiya

The best examples of architecture under the Kakatiya dynasty (1163–1323) are the ruins of the Warangal Fort.

In The Thousand Pillar Temple is one of the very old temples of South India that was built by the kakatiyas.[28] It stands out to be a masterpiece and achieved major heights in terms of architectural skills by the ancient Kakathiya Vishwakarma Sthapathis. It is believed that the Thousand Pillar Temple was built by Queen Rudrammadevi in 1163 AD. The Thousand Pillar Temple is a specimen of the Kakatiyan style of architecture of the 12th century.

It was destroyed by the invasion of Tuglaq dynasty to South India. However, Mir Osman Ali Khan, the 7th Nizam of Hyderabad, contributed immensely towards re-building the temple.[29] The temple consists of one building and temple building. There are one thousand pillars in the building and the temple, but no pillar obstructs a person in any point of the temple to see the god/deity in the other temple.

The Church of South India Cathedral at Medak. It is one of the largest churches in Asia

Apart from Warangal, the Kakatiya dynasty constructed many hill forts including Golconda,[note 1] Medak and Elgandal, and subsequent additions to these forts were made by the Bahmani and Qutb Shahi Sultanates.

Indo-Islamic

Early Indo-Islamic style of architecture is reflected in the monuments built by the Golconda Sultanate in Hyderabad. These include the Charminar, Golconda Fort and Qutb Shahi tombs.

Modern

During the reign of the Nizams of Hyderabad, European styled palaces and buildings became prevalent in the city of Hyderabad. Among the oldest surviving examples of architecture of this time is the Chowmahalla Palace, which showcases a diverse array of architectural styles, from the Baroque Harem to its Neoclassical royal court. The other palaces include Falaknuma Palace (inspired by the style of Andrea Palladio), Purani Haveli and King Kothi Palace all of which were built during the 19th century.

In the early 20th century, British Architect Vincent Esch was invited to Hyderabad by Asaf Jah VII. He designed the Kachiguda railway station (1914), the High Court (1916), the City College (1920) and Osmania General Hospital (1921) in the Indo-Saracenic Revival style, which combines Indo-Islamic and European architectural styles.[30]

Carved pillar at Thousand Pillar Temple

Architecture of Telangana
Kakatiya Kala Thoranam at the Warangal Fort, the capital of the Kakatiya dynasty. The fort was destroyed by the Delhi Sultanate in the 13th century.
Kakatiya Kala Thoranam at the Warangal Fort, the capital of the Kakatiya dynasty. The fort was destroyed by the Delhi Sultanate in the 13th century.
Mandapam at Warangal Fort.
Mandapam at Warangal Fort.
Ramappa Temple built by the Kakatiya dynasty in the 11th century.
Ramappa Temple built by the Kakatiya dynasty in the 11th century.
Charminar at Hyderabad was built by the Golconda Sultanate in the 16th century.
Charminar at Hyderabad was built by the Golconda Sultanate in the 16th century.
The Falaknuma Palace at Hyderabad was built in Palladian style of architecture in the 19th century.
The Falaknuma Palace at Hyderabad was built in Palladian style of architecture in the 19th century.
Cultural sites
Salar Jung Museum, Hyderabad, Telangana established in 1951 is the largest collection of antiques of an individual in the world.

Telangana has many museums which depicts the culture of the erstwhile kingdoms of the state. The Salar Jung Museum is an art museum located on the southern bank of the Musi river in the city of Hyderabad, Telangana, India. It is one of the three National Museums of India.[31] The museum's collection was sourced from the property of the Salar Jung family. The Salar Jung Museum is the third largest museum in India housing the biggest one-man collections of antiques in the world. It is well known throughout India for its prized collections belonging to different civilizations dating back is very largest collection to the 1st century.

The Telangana State Archaeology Museum in Hyderabad also houses a collection of rare Indian sculpture, art, artifacts as well as its most prized exhibit, an Egyptian mummy. The other prominent Museums are Nizam Museum, Warangal Museum, City Museum, Hyderabad and Birla Science Museum.

Cuisine
Main articles: Telugu cuisine and Hyderabadi cuisine
Hyderabadi biryani

Telangana has two types of cuisines, the Telugu cuisine and Hyderabadi cuisine. Telugu cuisine is the part of South Indian cuisine characterized by their highly spicy food. The Telangana state lies on the Deccan plateau and its topography dictates more millet and roti (leavened bread) based dishes. Jowar and Bajra features more prominently in their cuisine. Due to its proximity with Maharashtra, Chhattisgarh and northwest Karnataka, it shares some similarities of the Deccan plateau cuisine. Telangana has some unique dishes in its cuisine, such as jonna rotte (sorghum), sajja rotte (penisetum), or Uppudi Pindi (broken rice). In Telangana a gravy or curry is called Koora and Pulusu (Sour) in based on Tamarind. A deep fry reduction of the same is called Vepudu. Kodi pulusu and Mamsam (meat) vepudu are popular dishes in meat. Vankaya Brinjal Pulusu or Vepudu, Aritikaya Banana pulusu or Vepudu are one of the many varieties of vegetable dishes.[32] Telangana palakoora is a spinach dish cooked with lentils eaten with steamed rice and rotis. Peanuts are added as special attraction and in Karimnagar District, cashew nuts are added.

Sakinalu also called as Chakinalu, is one of the most popular savory in Telangana, is often cooked during Makara Sankranti festival season. This a deep-fried snack made of rice flour, sesame seeds and flavoured with ajwain (carom seeds or vaamu in Telugu). Garijelu is a dumpling dish similar to the Maharashtrian karanji, which in Telangana is cooked with sweet stuffing or a savory stuffing with mutton or chicken kheema.[33]

Double ka meetha
Hyderabadi cuisine, an amalgamation of Persian cuisine, Mughlai, Telugu, Turkish cuisines, developed by the Qutb Shahi dynasty and the Nizams of Hyderabad. It comprises a broad repertoire of rice, wheat and meat dishes and various spices and herbs.[34][35]

Hyderabadi cuisine is the cuisine of the Hyderabadi Muslims, and an integral part of the cuisines of the former Hyderabad State that includes the state of Telangana and the regions of Marathwada (now in Maharashtra) and Kalyana-Karanataka (now in Karnataka). The Hyderabadi cuisine contains city specific specialties like Hyderabad (Hyderabadi Biryani and Hyderabadi Haleem)[36] and Aurangabad (Naan Qalia), Gulbarga (Tahari), Bidar (Kalyani Biryani) and others. The use of dry coconut, tamarind, and red chillies along with other spices are the main ingredients that make Hyderabadi cuisine different from the North Indian cuisine

Performing arts
Dance
Main article: Perini Shivatandavam
Perini Sivatandavam or PeriniN Thandavam is an ancient danceO from Telangana which has been revived in recent times.[37]

The Perini Thandavam is a dance form usually performed by males. It is called 'Dance of Warriors'. Warriors before leaving to the battlefield enact this dance before the idol of Lord Shiva. The dance form, Perini, reached its pinnacle during the rule of the 'Kakatiyas' who established their dynasty at Warangal and ruled for almost two centuries. It is believed that this dance form invokes 'Prerana' (inspiration) and is dedicated to supreme dancer, Lord Shiva.

Bonalu The folk festival of Bonalu in the Telangana region brings with it celebrations which see the colourfully dressed female dancers balancing pots (Bonalu), step to the rhythmic beats and tunes in praise of the village deity Mahakali. Male dancers called Pothuraju's precede the female dancers to the temple lashing whips and neem leaves adding colour to the festivity.

Music
Telangana has a diverse variation of music from carnatic music to folk music. [Kancherla Gopanna,[38] popularly known as Bhakta Ramadasu or Bhadrachala Ramadasu was a 17th-century Indian devotee of Rama and a composer of Carnatic music. He is one among the famous vaggeyakaras (a person who not only composes the lyrics but also sets them to music; vāk = word, speech; geya = singing, singable; geyakāra = singer) in the Telugu language. there are many types of instruments in telangana

The folk songs of Telangana had left a profound impact on the Statehood movement[39] as it played a significant role in the success of the Dhoom-Dham, a cultural event that was a vital part of the agitations.

Some of the known folk singers who took active part in the Telangana movement are Gaddar, Belli Lalitha, Sai Chand, Vimalakka and singers like Deshapati Srinivas and Rasamayi Balakishan.

Oggu Katha
Main article: Oggu Katha
A western street replica at Ramoji Film City

Oggu Katha or Oggukatha is a traditional folklore singing praising and narrating the stories of Hindu gods Mallana, Beerappa and Yellamma.[40] It originated among the Yadav and Kuruma Golla communities, who devoted themselves to the singing of ballads in praise of Lord Shiva's son Sri Mallanna swamy (also called Sri Mallikarjuna swamy).[41] Oggus are the traditional priests of the Yadavas and perform the marriage of Mallanna with Bhramaramba.

The narrator and his chorus i.e. two or more narrators-help in dramatizing the narration as very often, they transform themselves into two characters. The dramatization of the narrative is what gives the Oggu Katha its predominant place in the ballad tradition in Telangana, where Oggu Katha is prevalent. The singers visit the shrine of Komuravelli Mallanna swamy Temple every year.

Cinema
Main article: Telugu Cinema
Telugu cinema, also known by its sobriquet as Tollywood, is a part of Indian cinema producing films in the Telugu language, and is centered in the Hyderabad, Telangana neighbourhood of Film Nagar.[42] The industry holds the Guinness World Record for the largest film production facility in the world, is one of the best tourist attraction in hyderabad Ramoji Film City.[43] The Prasads IMAX located in Hyderabad is one of the largest 3D IMAX screen, and the most attended cinema screen in the world.[44][45][46] As per the CBFC report of 2012, the industry is placed second in India, in terms of films produced yearly.[47] because of the film "Bahubali" (I and ii) casting Prabhas and Anushka.