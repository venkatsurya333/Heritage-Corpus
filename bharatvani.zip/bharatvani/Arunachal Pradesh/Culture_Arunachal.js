const arunachalPradesh = {
    name: "Arunachal Pradesh",
    etymology: {
        meaning: "Land of the Dawn-Lit Mountains",
        previousName: "North-East Frontier Agency",
        formationDate: "20 February 1987"
    },
    geography: {
        area: "83,743 km²",
        population: 1383727,
        density: "17 inhabitants per km²",
        capital: "Itanagar",
        borders: {
            states: ["Assam", "Nagaland"],
            international: {
                Bhutan: "west",
                Myanmar: "east",
                China: {
                    region: "Tibet Autonomous Region",
                    borderLength: "1,129 km"
                }
            }
        },
        majorRivers: ["Kameng", "Subansiri", "Siang", "Dibang", "Lohit", "Noa Dihing"],
        highestPeak: {
            name: "Kangto",
            height: "7,060 m"
        }
    },
    demographics: {
        tribes: [
            "Monpa",
            "Tani",
            "Mishmi",
            "Tai",
            "Naga",
            "Nocte",
            "Adi",
            "Nyishi",
            "Singpho",
            "Galo",
            "Tagin",
            "Apatani"
        ],
        languages: {
            major: [
                { name: "Nyishi", percentage: 20.74 },
                { name: "Adi", percentage: 17.35 },
                { name: "Nepali", percentage: 6.89 },
                { name: "Tagin", percentage: 4.54 },
                { name: "Bhotia", percentage: 4.52 },
                { name: "Wancho", percentage: 4.23 }
            ],
            official: ["Hindi", "English"]
        },
        religions: {
            Christianity: "30.26%",
            Hinduism: "29.04%",
            Donyi-Polo: "26.2%",
            Buddhism: "11.77%",
            Islam: "1.95%"
        }
    },
    history: {
        ancientPeriod: {
            description: "Very little ancient history is known about the region.",
            notableEvents: [
                "Monpa kingdom of Monyul flourished between 500 BCE and 600 CE.",
                "Monyul was ruled by Gongkar Gyal."
            ]
        },
        medievalPeriod: {
            description: "Tawang Monastery built in the 17th century.",
            notableFigures: ["5th Dalai Lama", "6th Dalai Lama Tsangyang Gyatso"]
        },
        modernHistory: {
            independence: "1947",
            statehood: "20 February 1987",
            recentClaims: [
                "14th Dalai Lama's statements on sovereignty.",
                "Chinese claims on Tawang."
            ]
        }
    },
    economy: {
        mainSectors: ["Agriculture", "Forestry", "Hydroelectric Power"],
        notableCrops: ["Rice", "Maize", "Millet", "Wheat", "Pulses"],
        GDP: {
            2015: "155.88 billion ₹",
            2020: "Estimated at US$1.75 billion"
        }
    },
    transport: {
        air: ["Itanagar Airport", "Pasighat Airport"],
        roads: ["Trans-Arunachal Highway", "NH-15"],
        rail: ["Harmuti-Naharlagun railway line"]
    },
    education: {
        literacyRate: "66.95%",
        majorInstitutions: [
            "Rajiv Gandhi University",
            "National Institute of Technology, Arunachal Pradesh"
        ]
    },
    stateSymbols: {
        animal: "Mithun",
        bird: "Hornbill",
        flower: "Foxtail orchid",
        tree: "Hollong"
    }
};

console.log(arunachalPradesh);
