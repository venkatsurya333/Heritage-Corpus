Arunachal Pradesh (/ərʊˌnɑːtʃəl prəˈdeɪʃ/;[11] lit. 'Dawn-Lit Mountain Province')[12] is a state in northeast India. It was formed from the North-East Frontier Agency (NEFA) region, and India declared it as a state on 20 February 1987. Itanagar is its capital and largest town. It borders the Indian states of Assam and Nagaland to the south. It shares international borders with Bhutan in the west, Myanmar in the east, and a disputed 1,129 km border with China's Tibet Autonomous Region in the north at the McMahon Line.[13] Arunachal Pradesh is claimed in its entirety[14][15][16] by China as South Tibet as part of the Tibet Autonomous Region;[17][18] China occupied some regions of Arunachal Pradesh in 1962 but later withdrew its forces.[19]: 22 [20]

As of the 2011 Census of India, Arunachal Pradesh has a population of 1,383,727 and an area of 83,743 square kilometres (32,333 sq mi). With only 17 inhabitants per square kilometre, it is the least densely populated state of India. It is an ethnically diverse state, with predominantly Monpa people in the west, Tani people in the centre, Mishmi and Tai people in the east, and Naga people in the southeast of the state. About 23 major tribes and 100 sub-tribes live in the state,[citation needed] including Nocte, Adi, Nyishi, Singpho, Galo, Tagin, Apatani. The Nyishi are the largest ethnic group in the region. The Mishmi tribe has three sub-tribes, namely Idu-Mishmi, Digaru-Mishmi and Miju-Mishmi.

Etymology
Arunachal Pradesh means Land of the Dawn-Lit Mountains, which is the sobriquet for the state in Sanskrit.[21] The term was coined during the formation of the state. Prior to the year 1972, it was called North-East Frontier Agency.

The People's Republic of China (PRC) claims the land to be part of Tibet, and calls it South Tibet (Chinese: 藏南 pinyin: Zàngnán).[19]: 22 : 155 [22] In ancient Tibetan texts, eastern Arunachal Pradesh[clarification needed] and some parts of Tibet[which?] were called Lhoyü while the residents were called Lhobha people,[23][failed verification] while Tawang district and West Kameng district in western Arunachal Pradesh were called Monyul.[a]

History
Ancient period
Main articles: Monpa people and Prince Tsangma
Very little ancient history is known about the region apart from the Northwestern corner, and the areas bordering current Assam. The Northwestern regions came under Monpa and Tibetan control.

Northwestern parts of this area came under the control of the Monpa kingdom of Monyul under Tibet which flourished between 500 BCE and 600 CE. The Monpa and Sherdukpen keep historical records of the existence of local chiefdoms in the northwest as well.[24]

According to Tibetan chronicles, Monyul was ruled by Gongkar Gyal, descendent of an exiled Tibetan ruler named Lhase Tsangma, the brother of Tibetan king Ralpacan who arrived in Monyul in 837 A.D or earlier.[25]

A descendant of Gongkar Gyal became the ruler of Trashiyangtse region of Bhutan and Gapde Tsan another descendant was the ruler of Khorwong valley in Thembang town (now West Kameng district, Arunachal Pradesh).[26]


Thembang dzong built during the 12th century, a type of dzong commonly found in Bhutan and Tibet
Later, the second son of Gongkar Gyal, Wongme Palde who returned to Tibet owing to the poverty in Khorwong valley came back to Monyul to become its ruler.[26]

The Rgyal rigs text written in 1668 or 1728 contains a record of taxes collected. Taxes were paid via coins, foodstuffs, or livestock from area around present-day Kameng district and Tawang district.[27]

The Monpas (Tibetan: མོན་པ) ་known to the Chinese as Menba[28] were responsible for trade between Assam and Tibet and held the Koriapar Dooar at Sonitpur district of Assam. The Monpa chief were subordinate to the ruler of Tawang who in turn were subordinate to the Government of Tibet or Ganden Phodrang in Lhasa.[29] The Tibetan government at Lhasa appointed Tibetan officials called Gellongs to supervise the local Monpa chief. The Monpa chief who looked after the Duar were called Tsorgon, a position created in the 16th century.[29]

According to historical Tibetan text the state of Arunachal Pradesh known as Lhoyu came under the control of Tubo Kingdom or Tibetan Empire in the 7th century CE.[30]


Arunachal Pradesh under the Tibetan Empire in 7th and 8th century CE
Medieval period
Main articles: Tsangyang Gyatso and Tawang Monastery

Tawang Monastery built in the 17th century under the instruction of the 5th Dalai Lama, is the largest monastery in India and second-largest in the world after the Potala Palace in Lhasa, Tibet. It is one of the few monasteries of Tibetan Buddhism that have remained protected from Mao's Cultural Revolution without any damage.[31]
In the 17th century, the 5th Dalai Lama Ngawang Lobsang Gyatso (1617–1682), who achieved political supremacy over Tibet in 1642, imposed a tax called Khrey over Monyul and instructed the construction of fortresses in Monpa area called Dzong which served as centers for administration and tax collection.[32]


Dirang Dzong build under instruction of the 5th Dalai Lama Ngawang Lobsang Gyatso
The fortressess built were Dirang Dzong, Taklung Dzong and Gyangkhar Dzong to collect tax from the Dirang Monpa, Kalaktang Monpa and Tawang Monpa respectively. The officials who collected the taxes were called Dzongpon.[32]

The tax was carried to Tawang Monastery and then to Lhasa via Tsona city (present-day China).[32]


Urgelling Monastery built in 1489 A.D by Urgen Sangpo in Tawang is the birthplace of 6th Dalai Lama, Tsangyang Gyatso
The 6th Dalai Lama Tsangyang Gyatso (1683–1706) was born in Tawang and died in Amdo (present-day China) on his way to Beijing after being kidnapped by the Mongol forces under Lha-bzang Khan, the last ruler of Khoshut Khanate on the approval of Kangxi Emperor of the Qing dynasty.

Before his death the 6th Dalai Lama instructed the construction of notable buildings like Tromzikhang in Barkhor, Lhasa.


Tromzikhang in Lhasa build under the instruction of the 6th Dalai Lama
Arunachal Pradesh falls under Kham (Tibetan: ཁམས་) and Ü-Tsang (Tibetan: དབུས་གཙང་) cultural region of Tibet which also includes the Brahmaputra River watershed.

The foothills and the plains, were under the control of the Chutia kings of Assam. Inner parts of the state remained independent and self-governed even though interactions with external parties did exist.[33]

The main archaeological sites of the state include:[34]

Site	Dated to	Built by
Bhismaknagar Fort, Roing	8th–15th century[35]	Chutia kings
Bolung Fort, Bolung	13th century	Chutia kings
Dimachung-Betali, West Kameng	13th century	Chutia kings
Gomsi Fort, East Siang	13th century[36]	Chutia kings
Rukmini Fort, Roing	14th–15th century[35]	Chutia kings
Tezu Fort, Roing	14th–15th century[37]	Chutia kings
Naksha Parbat ruins, East Kameng	14th–15th century[38]	Chutia kings
Ita Fort, Itanagar	14th–15th century[39]	Chutia kings
Buroi Fort, Papum Pare	13th century[40]	Chutia kings
Malinithan Temple, Likabali	13th–14th century[41]	Chutia kings
Ita Pukhuri, Ithili	13th–14th century[42]	Chutia kings
Padum Pukhuri, Ithili	13th–14th century[42]	Chutia kings
Kampona brick tank, Idili	13th–14th century[42]	Chutia kings
Kanying brick tank, Idili	13th–14th century[42]	Chutia kings
Bolung brick canal, Bolung	13th–14th century[43]	Chutia kings
Dirang Dzong, West Kameng	17th century	Monpa
Tawang Monastery, Tawang	17th century (1680–1681)	Merak Lama Lodre Gyatso
British India

Map of the British Indian Empire from the Imperial Gazetteer of India, 1909 showing the Outer Line as the border of Assam

The North-East Frontier Tracts in 1946
In 1912–13, the British Indian government established the North-East Frontier Tracts. It was divided into three sections, which eventually came to be called the Ballipara Frontier Tract, Lakhimpur Frontier Tract and Sadiya Frontier Tract.[45]

The McMahon line
Main article: McMahon Line

The neutrality of this section is disputed. Relevant discussion may be found on the talk page. Please do not remove this message until conditions to do so are met. (July 2021) (Learn how and when to remove this message)

A 1936 map of Tibet by Survey of India, showing the McMahon Line

The first political map of India (1947)

The North-East Frontier Tracts in 1947
In 1913–1914, representatives of the de facto independent state of Tibet and Britain met in India to define the borders of 'Outer Tibet' (with respect to China). British administrator Sir Henry McMahon drew the 550 miles (890 km) McMahon Line as the border between British India and Tibet, placing Tawang and other areas within British India. The Tibetan and British representatives devised the Simla Accord including the McMahon Line,[46] but the Chinese representatives did not concur.[47] The Simla Accord denies other benefits to China while it declines to assent to the Accord.[48]

The Chinese position was that Tibet was not independent from China and could not sign treaties, so the Accord was invalid, like the Anglo-Chinese (1906) and Anglo-Russian (1907) conventions.[49] British records show that the condition for the Tibetan government to accept the new border was that China must accept the Simla Convention. As Britain was not able to get an acceptance from China, Tibetans considered the McMahon line invalid.[47]

In the time that China did not exercise power in Tibet, the line had no serious challenges. In 1935, a Deputy Secretary in the Foreign Department, Olaf Caroe, "discovered" that the McMahon Line was not drawn on official maps. The Survey of India published a map showing the McMahon Line as the official boundary in 1937.[50] In 1938, two decades after the Simla Conference, the British finally published the Simla Accord as a bilateral accord and the Survey of India published a detailed map showing the McMahon Line as a border of India.

In April 1938, a small British force led by Captain G. S. Lightfoot arrived in Tawang and informed the monastery that the district was now Indian territory.[51] The Tibetan government at Lhasa protested and its authority was restored after Lightfoot's return.

In 1944, Britain established administrations in the area, from Dirang Dzong in the west to Walong in the east. Administrative control extended over the area of the Tawang tract lying south of the Sela Pass when J.P. Mills set up an Assam Rifles post at Dirang Dzong and sent the Tibetan tax-collectors packing. Tibetan protests were brushed aside. However, no steps were taken to evict Tibet from the area north of the pass which contained Tawang town.[52] The Tawang district remained under Tibetan authority until 1951.

Sino-Indian War
Main article: Sino-Indian War
Following the conclusion of British rule, India gained independence in 1947, while the People's Republic of China (PRC) was founded in 1949. The new Chinese administration maintained the position that the McMahon Line was not valid.[47]

In October 1947, independent Tibet wrote a note to the Government of India asking for a "return" of the territories that the British had allegedly occupied from Tibet. Among these were listed Zayul and Walong and in direction of Pemakoe, Lonag, Lopa, Mon, Bhutan, Sikkim, Darjeeling. After negotiation with the Indian government, Tibet relinquished claims on these territories.[53][54][55]

In November 1950, the PRC was poised to take over Tibet by force, and India supported Tibet. Journalist Sudha Ramachandran argued that China claimed Tawang on behalf of Tibetans, though Tibetans did not claim Tawang as part of Tibet.[56]

In February 1951, India sent Ralengnao Khathing of Manipur with a small escort and several hundred porters to Tawang and took control of the remainder of the Tawang tract from the Tibetans, removing the Tibetan administration.[57][b] The Indian efforts were warmly welcomed by the native population as a respite from the oppressive feudal regime.[citation needed]

What is now Arunachal Pradesh was established as the North-East Frontier Agency (NEFA) in 1954. Sino-Indian relations were cordial until 1960. Resurgence of the border disagreement was a factor leading to the Sino-Indian War in 1962, during which China captured most of Arunachal Pradesh, including the Tawang tract.[59][60][61] China soon declared victory, withdrew back to the McMahon Line, and returned Indian prisoners of war in 1963.[59][60][61]

The war resulted in the termination of barter trade with Tibet, although since 2007 the Indian government has shown signs of wanting to resume barter trade.[62]

Renaming and statehood
Under the leadership of Indira Gandhi, The North-East Frontier Agency (NEFA) was renamed Arunachal Pradesh by Bibhabasu Das Shastri, Daya Krishna Goswami and O. P. Upadhya[citation needed] on 20 January 1972, and it became a union territory. Later on, Arunachal Pradesh became a state on 20 February 1987 during Rajiv Gandhi's government.[63]

NB: K A A Raja, as Chief Commissioner to NEFA, under Assam, whose Capital used to be Shillong, later on went to become the first Lieutenant Governor to the Union Territory of Arunachal Pradesh.[64]

Recent claims
The 14th Dalai Lama did not originally recognise India's sovereignty over Arunachal Pradesh. As late as 2003, he said that "Arunachal Pradesh was actually part of Tibet".[65] In January 2007, the Dalai Lama said that both Britain and Tibet had recognised the McMahon Line in 1914. In 2008, he said that Arunachal Pradesh was a part of India under the agreement signed by Tibetan and British representatives.[66] According to the Dalai Lama, "In 1962 during the India-China war, the People's Liberation Army (PLA) occupied all these areas (Arunachal Pradesh) but they announced a unilateral ceasefire and withdrew, accepting the current international boundary".[67]

In recent years, China has occasionally asserted its claims on Tawang. India rebutted these claims and told the Chinese government that Tawang is an integral part of India. India reiterated this to China when the two prime ministers met in Thailand in October 2009. A report that the Chinese Army had briefly invaded Arunachal Pradesh in 2016 was denied by India's Minister of State for Home Affairs, Kiren Rijiju.[68] In April 2017, China strongly objected to a visit to Tawang by the Dalai Lama, as it had to an earlier visit by the US ambassador to India.[69] China had objected to the Dalai Lama's previous visits to the area.[70]

In 2024, The New York Times reported that, according to satellite imagery, China had constructed villages along and inside of disputed territory within Arunachal Pradesh.[71] Chinese individuals, called "border guardians", received annual subsidies to relocate to newly built villages and paid to conduct border patrols.[71]

Insurgency
Main article: Insurgency in Arunachal Pradesh
Arunachal Pradesh has faced threats from insurgent groups, notably the National Socialist Council of Nagaland (NSCN), who are believed to have base camps in the districts of Changlang and Tirap.[72] These groups seek to decrease the influence of Indian government in the region and merge part of Arunachal Pradesh into Nagaland.

The Indian army is present along the Tibetan border to thwart any Chinese incursion. Under the Foreigners (Protected Areas) Order 1958 (India), Inner Line Permits (ILPs) are required to enter Arunachal Pradesh through any of its checkgates on the border with Assam.[citation needed]

Geography
Main article: Geography of Arunachal Pradesh

A kettle lake at Se La in Tawang district.
Arunachal Pradesh is located between 26.28° N and 29.30° N latitude and 91.20° E and 97.30° E longitude and has an area of 83,743 km2 (32,333 sq mi).

The highest peak in the state is Kangto, at 7,060 metres (23,160 ft). Nyegi Kangsang, the main Gorichen peak, and the Eastern Gorichen peak are other tall Himalaya peaks. The state's mountain ranges, in the extreme East of India, are described as "the place where the sun rises" in historical Indian texts and named the Aruna Mountains, which inspired the name of the state. The villages of Dong (more accessible by car, and with a lookout favoured by tourists) and Vijaynagar (on the edge of Myanmar) receive the first sunlight in all of India.


A view from Bhalukpong, a small town by the southern reaches of the Himalayas.
Major rivers of Arunachal Pradesh include the Kameng, Subansiri, Siang (Brahmaputra), Dibang, Lohit and Noa Dihing rivers. Subsurface flows and summer snow melt contribute to the volume of water. Mountains until the Siang river are classified as the Eastern Himalayas. Those between the Siang and Noa Dihing are classified as the Mishmi Hills that may be part of the Hengduan Mountains. Mountains south of the Noa Dihing in Tirap and Longding districts are part of the Patkai Range.

Climate
The climate of Arunachal Pradesh varies with elevation. The low-altitude areas have a humid subtropical climate. High-altitude areas (3,500–5,500 m) have a subtropical highland climate and alpine climate. Arunachal Pradesh receives 2,000 to 5,000 millimetres (79 to 197 in) of rainfall annually,[73] 70%–80% obtained between May and October.

Biodiversity
Arunachal Pradesh has among the highest diversity of mammals and birds in India. There are around 750 species of birds[74] and more than 200 species of mammals[75] in the state.


Ziro valley
Arunachal's forests account for one-third of habitat area within the Himalayan biodiversity hot-spot.[76] In 2013, 31,273 km2 (12,075 sq mi) of Arunachal's forests were identified as part of a vast area of continuous forests (65,730 km2 or 25,380 sq mi, including forests in Myanmar, China and Bhutan) known as Intact forest landscapes.[77] There are three tiger reserves in the state: a reserve in Namdapha National Park, Mouling National Park and Pakke Tiger Reserve.[78]

Flora
In the year 2000, Arunachal Pradesh was covered with 63,093 km2 (24,360 sq mi) of tree cover[79] (77% of its land area). It harbours over 5,000 plants.[80] At the lowest elevations, essentially at Arunachal Pradesh's border with Assam, are Brahmaputra Valley semi-evergreen forests. Much of the state, including the Himalayan foothills and the Patkai hills, are home to Eastern Himalayan broadleaf forests. Toward the northern border with Tibet, with increasing elevation, come a mixture of Eastern and Northeastern Himalayan subalpine conifer forests followed by Eastern Himalayan alpine shrub and meadows and ultimately rock and ice on the highest peaks. It supports many medicinal plants and within Ziro valley of Lower Subansiri district 158 medicinal plants are being used by its inhabitants.[81] The mountain slopes and hills are covered with alpine, temperate, and subtropical forests of dwarf rhododendron, oak, pine, maple and fir.[82] The state has Mouling and Namdapha national parks.

Fauna
The major animal species are tiger, leopard, snow leopard, Asian elephant, sambar deer, chital deer, barking deer, sloth bear, mithun (Bos frontalis), gaur, dhole, giant squirrel, marbled cat, leopard cat.[83] A new subspecies of hoolock gibbon has been described from the state which has been named as the Mishmi Hills hoolock gibbon (H. h. mishmiensis).[84] Three new giant flying squirrels were also described from the state during the last one and half-decade. These were, Mechuka giant flying squirrel,[85] Mishmi Hills giant flying squirrel,[86] and Mebo giant flying squirrel.[87]

Administration
Districts
Main article: Districts of Arunachal Pradesh
Arunachal Pradesh comprises three divisions, namely, Central, East and West, each headed by a divisional commissioner and twenty-five districts, each administered by a deputy commissioner. Arunachal Pradesh has a total of 28 districts, West Siang being the largest district in terms of area and Tawang being the smallest district. Papum is the largest district in terms of population and Diwang Valley is the smallest district.[88]

Arunachal Pradesh is located in Arunachal PradeshTawangTawangWest KamengWest KamengPakke-KessangPakke-KessangEast KamengEast KamengKurung KumeyKurung KumeyPapum ParePapum PareLower SubansiriLower SubansiriKamleKamleKra DaadiKra DaadiUpper SubansiriUpper SubansiriLower SiangLower SiangLepa RadaLepa RadaWest SiangWest SiangShi YomiShi YomiSiangSiangUpper SiangUpper SiangEast SiangEast SiangDibang ValleyDibang ValleyLower Dibang ValleyLower Dibang ValleyAnjawAnjawLohitLohitNamsaiNamsaiChanglangChanglangTirapTirapLongdingLongdingItanagarItanagar
Districts of Arunachal Pradesh since 2018
Legend：  Capital  Year created 2018  Year created 2017  Year created 2015  Created before 2015
Division[89]	West	Central	East
Headquarters	Yazali	Basar	Namsai
Districts	
East Kameng
Kamle
Kra Daadi
Kurung Kumey
Lower Subansiri
Pakke-Kessang
Papum Pare
Tawang
West Kameng
Lepa-Rada
Lower Siang
Shi-Yomi
Upper Subansiri
West Siang
Anjaw
Changlang
Dibang Valley
East Siang
Lohit
Longding
Lower Dibang Valley
Namsai
Siang
Tirap
Upper Siang
Major towns
See also: List of cities and towns in Arunachal Pradesh
Below are the major towns in Arunachal Pradesh.

Municipal corporation
Itanagar Municipal Corporation
Municipal councils
Pasighat Municipal council
Municipal committees
Deomali
Aalo
Seppa
Tezu
Daporijo
Namsai
Ziro
Roing
Tawang
Khonsa
Bomdila
Pasighat
Towns
Jairampur
Deomali
Aalo
Yingkiong
Changlang
Miao
Basar
Dirang
Anini
Koloriang
Rupa
Boleng
Hawai
Sagalee
Yupia
Doimukh
Gumto
Longding
Pangin
Likabali
Malinithan
Bhalukpong
Nampong
Hayuliang
Palin
Jamin
Bhismaknagar
Akshiganga
Mechukha
Pasighat
Ziro
Raga
Demographics
Main article: Demographics of Arunachal Pradesh

This section needs additional citations for verification. Please help improve this article by adding citations to reliable sources in this section. Unsourced material may be challenged and removed. (May 2020) (Learn how and when to remove this message)

Nyishi man in traditional dress
Historical population
Year	Pop.	±%
1961	336,558	—    
1971	467,511	+38.9%
1981	631,839	+35.1%
1991	864,558	+36.8%
2001	1,097,968	+27.0%
2011	1,383,727	+26.0%
Source: Census of India[90][91][92]
As per the 2011 Census, Arunachal Pradesh has 12 Scheduled Tribes, comprising 68.79% of its population. The state can be roughly divided into a set of semi-distinct cultural spheres, on the basis of tribal identity, language, religion and material culture: the Tibetic-speaking Monpa area bordering Bhutan in the west, the Tani area in the centre of the state, the Mishmi area to the east of the Tani area, the Tai/Singpho/Tangsa area bordering Myanmar, and the Naga area to the south, which also borders Myanmar. In between there are transition zones, such as the Aka/Hruso/Miji/Sherdukpen area, between the Tibetan Buddhist tribes and the animist Tani hill tribes. In addition, there are isolated peoples scattered throughout the state, such as the Sulung.


An Adi gaon-bura (village headman) in G.B.Simong village of the Upper Siang district, Arunachal Pradesh
Within each of these cultural spheres, one finds populations of related tribes speaking related languages and sharing similar traditions. In the Tibetic area, one finds large numbers of Monpa tribespeople, with several subtribes speaking closely related but mutually incomprehensible languages, and also large numbers of Tibetan refugees. Within the Tani area, major tribes include the Nyishi. Apatani also live among the Nyishi, but are distinct. In the north one find the Tagin People. In the centre, one finds predominantly Galo people, with the major sub-groups of Karka, Lodu, Bogum, Lare and Pugo among others, extending to the Ramo and Pailibo areas (which are close in many ways to Galo). In the east, one finds the Adi with many subtribes including Padam, Pasi, Minyong and Bokar, among others. Milang, while also falling within the general Adi sphere, are in many ways quite distinct. Moving east, the Idu, Miju and Digaru make up the Mishmi cultural-linguistic area.

Moving southeast, the Tai Khamti are linguistically distinct from their neighbours and culturally distinct from the majority of other Arunachalese tribes. They follow the Theravada sect of Buddhism. They also exhibit considerable convergence with the Singpho and Tangsa Naga tribes of the same area, all of which are also found in Burma. They are one of the most recent people group migrated to Arunachal region from Burma. The Nocte Naga and Wancho Naga are another two major ethnic tribes. Both the tribes exhibit very much cultural similarities. Finally, the Deori tribe is also a major community in the state, with their own distinctive identity. They are the descendants of the priestly class of Chutia people who were allowed to continue their livelihood after the defeat of the Chutias. Deoris are one of the only Arunachal tribes in the historical records – which shows they are among the first ethnic groups to inhabit the Himalayas of the districts of Dibang Valley and Lohit, before the arrival of many other tribes in the region between 1600 and 1900.

Religion
Main article: Religion in Arunachal Pradesh

Buddhism is practised by 12% of the population. Shown here is a statue of the Buddha in Tawang, Arunachal Pradesh.
Religion in Arunachal Pradesh (2011)[94]
Christianity (30.26%)
Hinduism (29.04%)
Donyi-Polo[93] (26.2%)
Buddhism (11.77%)
Islam (1.95%)
Others (0.78%)
According to the 2011 Indian Census, 418,732 (30.26%) are Christians, 401,876 (29.04%) are Hindus, 162,815 (11.77%) Buddhists, 27,045 (1.95%) Muslims, 3,287 (0.24%) Sikhs, 771 (0.06%) Jains and 362,553 (26.20%) are adherents of various tribals belief including Donyi-Polo.[95] However, the religious landscape of Arunachal Pradesh is diverse with no single religious group representing the majority of the population, although it is one of the few Indian states where Christianity has the most followers. A relatively large percentage of Arunachal's population are nature worshippers (indigenous religions), and follow their own distinct traditional institutions like the Nyedar Namlo by the Nyishi, the Rangfrah by the Tangsa & Nocte, Medar Nelo by the Apatani, the Kargu Gamgi by the Galo and Donyi-Polo Dere by the Adi under the umbrella of the indigenous religion the Donyi-Polo. A small number of Arunachali people have traditionally identified as Hindus,[96] although the number may grow as animist traditions are absorbed into Hinduism. Tibetan Buddhism predominates in the districts of Tawang, West Kameng, and isolated regions adjacent to Tibet. Theravada Buddhism is practised by groups living near the Myanmar border. Around 30% of the population are Christians.[97]

Buddhism arrived in Arunachal Pradesh in 8th century CE from Tibet.[98]

In 1971, the percentage of Christians in the state was 0.79%. This increased to 10.3% by 1991 and by 2011 it had crossed 25%.[99]

Languages
See also: Arunachal languages
Languages of Arunachal Pradesh in 2011[100]
Nyishi (20.74%)
Adi (17.35%)
Nepali (6.89%)
Tagin (4.54%)
Bhotia (4.52%)
Wancho (4.23%)
Assamese (3.89%)
Bengali (3.66%)
Hindi (3.45%)
Chakma (3.4%)
Apatani (3.21%)
Mishmi (3.04%)
Tangsa (2.64%)
Nocte (2.19%)
Bhojpuri (2.04%)
Sadri (1.04%)
Others (13.16%)
Hindi is spoken by 62.8% (nearly 0.9 million) of the state population as a primary, secondary, or additional language, serving as the lingua franca for diverse ethnolinguistic social groups.[101]
The speakers of major languages of the state according to the 2011 census are Nyishi (20.74%), Adi (17.35%, includes Adi and Gallong), Nepali (6.89%), Tagin (4.54%), Bhotia (4.51%), Wancho (4.23%), Assamese (3.9%), Bangla (3.65%), Hindi (3.45%), Chakma (3.40%), Apatani (3.21%), Mishmi (3.04%), Tangsa (2.64%), Nocte (2.19%), Bhojpuri (2.04%) and Sadri (1.03%).

The vast majority of Arunachal Pradesh speaks Tani languages of the Tibeto-Burman language family. Tani people are indigenous to central Arunachal Pradesh, including (moving from west to east) the Nyishi, the Apatani, the Tagin, the Galo, the Bokar, the Adi, the Padam, the Pasi, and the Minyong. The Tani languages are noticeably characterised by an overall relative uniformity, suggesting relatively recent origin and dispersal within their present-day area of concentration. Most of the Tani languages are mutually intelligible with at least one other Tani language, meaning that the area constitutes a dialect chain, as was once found in much of Europe; only Apatani and Milang stand out as relatively unusual in the Tani context. Tani languages are among the better-studied languages of the region.[citation needed]

To the east of the Tani area lie three virtually undescribed and highly endangered languages of the "Mishmi" group of Tibeto-Burman: Idu, Digaru and Mishmi people. A number of speakers of these languages are also found in Tibet. The relationships of these languages, both among one another and to other area languages, are as yet uncertain. Further south, one finds the Singpho (Kachin) language, which is primarily spoken by large populations in Myanmar's Kachin State, and the Nocte and Wancho languages, which show affiliations to certain Naga languages spoken to the south in modern-day Nagaland.

To the west and north of the Tani area are found at least one and possibly as many as four Bodic languages, including Dakpa and Tshangla language; within modern-day India, these languages go by the cognate but, in usage, distinct designations Monpa and Memba. Most speakers of these languages or closely related Bodic languages are found in neighbouring Bhutan and Tibet, and Monpa and Memba populations remain closely adjacent to these border regions.[citation needed]

Between the Bodic and Tani areas lie many almost completely undescribed and unclassified languages, which, speculatively considered Tibeto-Burman, exhibit many unique structural and lexical properties that probably reflect both a long history in the region and a complex history of language contact with neighbouring populations. Among them are Sherdukpen, Bugun, Hruso, Koro, Miji, Bangru and Puroik/Sulung. The high linguistic significance these languages is belied by the extreme paucity of documentation and description of them, even in view of their highly endangered status. Puroik, in particular, is perhaps one of the most culturally and linguistically unique and significant populations in all of Asia from proto-historical and anthropological-linguistic perspectives, and yet virtually no information of any real reliability regarding their culture or language can be found in print.[citation needed]

Finally, other than the Bodic and Tani groups, there are also certain migratory languages that are largely spoken by migratory and central government employees serving in the state in different departments and institutions in modern-day Arunachal Pradesh.[citation needed] They are classified as Non-Tribal as per the provisions of the Constitution of India.

Outside of Tibeto-Burman, one finds in Arunachal Pradesh a single representative of the Tai family, spoken by Tai Khamti, which is closely affiliated to the Shan language of Myanmar's Shan State. Seemingly, Khampti is a recent arrival in Arunachal Pradesh whose presence dates to 18th and/or early 19th-century migrations from northern Myanmar.[citation needed]

In addition to English, various Indo-Aryan languages Assamese, Bengali, Nepali and especially Hindi are making strong inroads into Arunachal Pradesh. Primarily as a result of the primary education system—in which classes are generally taught by Hindi-speaking migrant teachers from Bihar and other Hindi-speaking parts of northern India, a large and growing section of the population now speaks a semi-creolised variety of Hindi as a mother tongue. Hindi acts as a lingua franca for most of the people in the state.[102] Despite, or perhaps because of, the linguistic diversity of the region, English is the only official language recognised in the state.

Education
Literacy has risen in official figures to 66.95% in 2011 from 54.74% in 2001. The literate population is said to number 789,943. The number of literate males is 454,532 (73.69%) and the number of literate females is 335,411 (59.57%).[103]

Economy
See also: List of Indian states by GDP
The chart below displays the trend of the gross state domestic product of Arunachal Pradesh at market prices by the Ministry of Statistics and Programme Implementation with figures in billions of Indian Rupees.[citation needed]

Year	Gross Domestic Product (Billion ₹)
1980	1.070
1985	2.690
1990	5.080
1995	11.840
2000	17.830
2005	31.880
2010	65.210
2015	155.880
Arunachal Pradesh's gross state domestic product was estimated at US$706 million at current prices in 2004 and US$1.75 billion at current prices in 2012. Agriculture primarily drives the economy. Jhum, the local term used for shifting cultivation is being widely practised among the tribal groups, though owing to the gradual growth of other sources of income in the recent years, it is not being practised as prominently as it was earlier. Arunachal Pradesh has close to 61,000 km2 of forests, and forest products are the next most significant sector of the economy. Among the crops grown here are rice, maize, millet, wheat, pulses, sugarcane, ginger, and oilseeds. Arunachal is also ideal for horticulture and fruit orchards. Its major industries are rice mills, fruit preservation and processing units, and handloom handicrafts. Sawmills and plywood trades are prohibited under law.[104] There are many saw mills in the state.[105] A significant portion of India's unexplored hydroelectric capacity is attributed to Arunachal Pradesh. In 2008, the Arunachal Pradesh government entered into several memoranda of understanding with multiple companies, outlining around 42 hydroelectric projects intended to generate over 27,000 MW of electricity.[106] Construction of the Upper Siang Hydroelectric Project, which is expected to generate between 10,000 and 12,000 MW, began in April 2009.[107]

Transport
Air
Itanagar Airport, a Greenfield project serving Itanagar was constructed at Holongi at a cost of ₹6.5 billion.[108] In 2022, IndiGo began direct flights to Itanagar from Mumbai and Kolkata.[109][non-primary source needed] Alliance Air operates flights to the state flying from Kolkata via Guwahati to Pasighat Airport. This route commenced in May 2018 under the Government's Regional Connectivity Scheme UDAN following the completion of a passenger terminal at Pasighat Airport in 2017.[110] State-owned Daporijo Airport, Ziro Airport, Along Airport, and Tezu Airport are small and not in operation, but the government has proposed to develop them.[111] Before the state was connected by roads, these airstrips were used to distribute food.

Roads

The road from Tinsukia to Parshuram Kund

Hunli Signboard
The main highway of Arunachal Pradesh is the Trans-Arunachal Highway, National Highway 13 (1,293 km (803 mi); formerly NH-229 and NH-52). It originates in Tawang and spans most of the width of Arunachal Pradesh, then crosses south into Assam and ends at Wakro. The project was announced by then Prime Minister Manmohan Singh in 2008 for completion by 2015–16, but only became operational in 2018.

NH-15 through Assam follows the southern border of Arunachal Pradesh. Access to central Arunachal Pradesh has been facilitated by the Bogibeel Bridge, an earthquake-resistant rail and road bridge over the Brahmaputra River in Assam, opened for public use on 25 December 2018 by Prime Minister Narendra Modi. A spur highway numbered NH-415 services Itanagar.

State-owned Arunachal Pradesh State Transport Services (APSTS) runs daily bus service from Itanagar to most district headquarters including Tezpur, Guwahati in Assam, Shillong in Meghalaya, and Dimapur in Nagaland.[112][113][114][115]

As of 2007, every village is connected by road, thanks to funding provided by the central government. Every small town has its own bus station with daily bus service. Connections to Assam have increased commerce.

In 2014, two additional east–west highways were proposed: an Industrial Corridor Highway in the lower foothills, and a Frontier Highway along the McMahon Line.[116][117][118][119] The proposed alignment of the Frontier Highway has been published.[120]

Railway
Arunachal Pradesh got its first railway line in late 2013 with the opening of the new link line from Harmuti on the main Rangpara North–Murkongselak railway line to Naharlagun in Arunachal Pradesh. The construction of the 33-kilometre 5 ft 6 in (1,676 mm) broad-gauge railway line was completed in 2012, and the link became operational after the gauge conversion of the main line from Assam. The state capital Itanagar was added to the Indian railway map on 12 April 2014 via the newly built 20-kilometre Harmuti-Naharlagun railway line, when a train from Dekargaon in Assam reached Naharlagun railway station, 10 kilometres from the centre of Itanagar, a total distance of 181 kilometres.[121][122]

On 20 February 2015, the first through train was run from New Delhi to Naharlagun, flagged off from the capital by the Indian prime minister, Narendra Modi. India plans to eventually extend the railway to Tawang, near the border with China.[123]

Education
Main article: Education in Arunachal Pradesh
See also: List of institutions of higher education in Arunachal Pradesh

NERIST academic block

NIT Arunachal Pradesh temporary campus in Yupia
The state government is expanding the relatively underdeveloped education system with the assistance of NGOs like Vivekananda Kendra, leading to a sharp improvement in the state's literacy rate. The main universities are the Rajiv Gandhi University (formerly known as Arunachal University), under which come 36 institutions offering regular undergraduate courses as well as teacher education and health sciences and nursing degrees, both under governmental and private managements, Indira Gandhi Technological and Medical Sciences University and Himalayan University[124] as well. The first college, Jawaharlal Nehru College, Pasighat, was established in 1964. The First Technical University is Established in 2014 namely North East Frontier Technical University (NEFTU). In Aalo, West Siang District by The Automobile Society India, New Delhi. There is also a deemed university, the North Eastern Regional Institute of Science and Technology as well as the National Institute of Technology, Arunachal Pradesh, established on 18 August 2010, is located in Yupia (headquarter of Itanagar).[125] NERIST plays an important role in technical and management higher education. The directorate of technical education conducts examinations yearly so that students who qualify can continue on to higher studies in other states.


St Claret College Ziro
Of the above institutions, only the following institutions are accredited by NAAC (National Assessment and Accreditation Council), in the order of their grade: Jawaharlal Nehru College, Pasighat (Grade A), St Claret College, Ziro (Grade A), Indira Gandhi Govt. College, Tezu (Grade B++), Rajiv Gandhi University (Grade B), National Institute of Technology, Arunachal Pradesh (Grade B), Dera Natung Government College, Itanagar (Grade B), Govt. College, Bomdila (Grade B), Donyi Polo Govt. College, Kamki (Grade B), and Rang Frah Govt. College, Changeling (Grade C).

Wangcha Rajkumar Government College, Deomali[126] is the only college in the southeastern part of Arunachal Pradesh. It caters to the students from Tirap, Changlang and Longding districts.

There are also trust institutes, like Pali Vidyapith, run by Buddhists. They teach Pali and Khamti scripts in addition to typical education subjects. Khamti is the only tribe in Arunachal Pradesh that has its own script. Libraries of scriptures are in a number of places in Lohit district, the largest one being in Chowkham.

The state has two polytechnic institutes: Rajiv Gandhi Government Polytechnic in Itanagar established in 2002 and Tomi Polytechnic College in Basar established in 2006. There are two law colleges, namely, the private-owned Arunachal Law Academy at Itanagar and the government-owned Jarbom Gamlin Government Law College at Jote, Itanagar. The College of Horticulture and Forestry is affiliated to the Central Agricultural University, Imphal.

Politics
See also: Politics of Arunachal Pradesh
Arunachal Pradesh suffered political crisis between April 2016 and December 2016. The Indian National Congress Chief Minister Nabam Tuki replaced Jarbom Gamlin as the Chief Minister of Arunachal Pradesh on 1 November 2011 and continued until January 2016. After a political crisis in 2016, President's rule was imposed ending his tenure as the chief minister. In February 2016, Kalikho Pul became the Chief Minister when 14 disqualified MLAs were reinstated by the Supreme Court. On 13 July 2016, the Supreme Court quashed the Arunachal Pradesh Governor J.P. Rajkhowa's order to advance the Assembly session from 14 January 2016 to 16 December 2015, which resulted in President's rule in Arunachal Pradesh. As a result, Nabam Tuki was reinstated as the Chief Minister of Arunachal Pradesh on 13 July 2016. But hours before floor test, he resigned as the chief minister on 16 July 2016. He was succeeded by Pema Khandu as the INC Chief Minister who later joined PPA in September 2016 along with majority of MLAs. Pema Khandu further joined BJP in December 2016 along with majority of MLAs. Arunachal Pradesh becomes second northeast Indian state to achieve ODF status.[127] During 2017, 2021, and 2023, China compiled a list of name alterations for multiple locations in Arunachal Pradesh, in both Chinese and Tibetan languages. China asserts these areas as belonging to "Southern Tibet" and being integral parts of China. The proposed changes encompassed 11 alterations, covering geographical landmarks like mountain summits and rivers, as well as residential zones.[128] The Indian government has continued to reject Chinese claims of geographical ownership of parts of Arunachal Pradesh. National military forces on both sides have increased over the Indian-Chinese border.[14]

On 28 August 2023, China further provoked India when the PRC's Ministry of Natural Resources released its new 'standard map' in which Arunachal Pradesh was depicted as a part of PRC. Other internationally disputed lands and waters were also depicted as PRC territory on their new map.[128]

State symbols
See also: List of symbols of Indian states and territories
Emblem	Emblem of Arunachal Pradesh	
Animal	Mithun (Bos frontalis)	
Bird	Hornbill (Buceros bicornis)	
Flower	Foxtail orchid (Rhynchostylis retusa)	
Tree	Hollong (Dipterocarpus retusus)[129]	
Geographical indication
Arunachal Pradesh Khaw Tai (Khamti Rice) was awarded the Geographical Indication (GI) status tag from the Geographical Indications Registry, under the Union Government of India, on 3 October 2023 and is valid until 12 December 2031.[130]

Namsai Organic Spices and Agricultural Producer Company Limited from Lohit, proposed the GI registration of Arunachal Pradesh Khaw Tai (Khamti Rice). After filing the application in December 2021, the rice was granted the GI tag in 2023 by the Geographical Indication Registry in Chennai, making the name "Arunachal Pradesh Khaw Tai (Khamti Rice)" exclusive to the rice grown in the region. It thus became the first rice variety from Arunachal Pradesh and the 3rd type of goods from Arunachal Pradesh to earn the GI tag. The GI tag protects the rice from illegal selling and marketing, and gives it legal protection and a unique identity.

