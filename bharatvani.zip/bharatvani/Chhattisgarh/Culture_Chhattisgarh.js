const chhattisgarh = {
    name: "Chhattisgarh",
    etymology: "Thirty-six forts",
    nickname: "Rice bowl of India",
    motto: "Satyameva Jayate (Truth alone triumphs)",
    anthem: "Arpa Pairi Ke Dhar",
    formationDate: "1 November 2000",
    capital: "Raipur",
    area: {
        total: "135,192 km²",
        rank: 9,
        dimensions: {
            length: "435 km",
            width: "750 km",
            elevation: "275 m",
            highestPoint: {
                name: "Bailadila Range",
                height: "1,276 m"
            }
        }
    },
    population: {
        total: 29436231,
        rank: 17,
        density: "220/km²",
        urban: "23.24%",
        rural: "76.76%"
    },
    government: {
        governor: "Ramen Deka",
        chiefMinister: "Vishnu Deo Sai (BJP)",
        deputyChiefMinisters: ["Arun Sao (BJP)", "Vijay Sharma (BJP)"],
        chiefSecretary: "Amit Jain (IAS)",
        legislature: {
            type: "Unicameral",
            assemblySeats: 90
        },
        nationalParliament: {
            rajyaSabhaSeats: 5,
            lokSabhaSeats: 11
        }
    },
    symbols: {
        bird: "Common hill myna",
        fish: "Walking catfish",
        flower: "French marigold",
        fruit: "Jackfruit",
        mammal: "Wild water buffalo",
        tree: "Sal tree"
    },
    geography: {
        description: "Chhattisgarh is a landlocked state in Central India.",
        borders: [
            "Uttar Pradesh (north)",
            "Madhya Pradesh (northwest)",
            "Maharashtra (southwest)",
            "Jharkhand (northeast)",
            "Odisha (east)",
            "Andhra Pradesh (south)",
            "Telangana (south)"
        ],
        climate: "Tropical climate with hot summers and a monsoon season.",
        rivers: [
            "Mahanadi",
            "Hasdeo",
            "Rihand",
            "Indravati",
            "Jonk",
            "Arpa",
            "Shivnath"
        ]
    },
    history: {
        ancient: "The region was known as Dakshina Kosala and has historical significance dating back to the Mauryan period.",
        modern: "Chhattisgarh was formed from Madhya Pradesh on 1 November 2000."
    },
    economy: {
        gdp: {
            total: "₹6.35 lakh crore (US$75 billion) (2025–26 est.)",
            rank: 18,
            perCapita: "₹199,700 (US$2,400)"
        },
        agriculture: {
            description: "Agriculture is the chief economic occupation.",
            mainCrops: [
                "Rice",
                "Maize",
                "Kodo-kutki",
                "Pulses",
                "Oilseeds"
            ]
        },
        industry: {
            sectors: {
                agriculture: "32%",
                industry: "32%",
                services: "36%"
            },
            notableCompanies: [
                "Bhilai Steel Plant",
                "NTPC",
                "Jindal Steel and Power"
            ]
        }
    },
    demographics: {
        literacy: {
            total: "78.5%",
            female: "60.59%"
        },
        sexRatio: {
            total: "991 females per 1,000 males",
            child: "964 females per 1,000 males"
        },
        scheduledTribes: "30.62% of the population",
        scheduledCastes: "12.8% of the population"
    },
    culture: {
        cuisine: {
            description: "Chhattisgarh is known as the rice bowl of India.",
            notableDishes: [
                "Aamat",
                "Bafauri",
                "Bhajia",
                "Chousela",
                "Dubkikadhi"
            ]
        },
        festivals: [
            "Bastar Dussehra",
            "Madai Festival",
            "Rajim Kumbh Mela"
        ],
        arts: {
            danceStyles: [
                "Panthi",
                "Raut Nacha",
                "Pandwani"
            ],
            crafts: [
                "Kosa silk",
                "Dhokra art"
            ]
        }
    },
    transport: {
        roads: {
            nationalHighways: "20 national highways measuring 3,078 km",
            stateHighways: "8,031 km"
        },
        rail: {
            description: "Major railway junctions include Bilaspur, Durg, and Raipur.",
            totalLength: "1,108 km"
        },
        air: {
            primaryAirport: "Swami Vivekananda Airport in Raipur",
            regionalAirports: [
                "Bilaspur Airport",
                "Jagdalpur Airport",
                "Ambikapur Airport"
            ]
        }
    },
    website: "cgstate.gov.in"
};

console.log(chhattisgarh);
