Chhattisgarh
State
State of Chhattisgarh

Bhoramdeo Temple

Nava Raipur

Teerathgarh Falls

Ghasidas Jaitkham

Bastar Dussehra

Kanger Ghati National Park

Chitrakote Falls
Official emblem of Chhattisgarh
Emblem of Chhattisgarh
Etymology: "Thirty-six forts"
Nickname: Rice bowl of India
Motto(s): Satyameva Jayate (Sanskrit)
"Truth alone triumphs"
Anthem: Arpa Pairi Ke Dhar (Chhattisgarhi)[1][2]
"The Streams of Arpa and Pairi"
The map of India showing Chhattisgarh
Location of Chhattisgarh in India
Coordinates: 21.25°N 81.60°E
Country	India
Region	Central India
Previously was	Part of Madhya Pradesh
Formation	1 November 2000
Capital
and largest city	Raipur
Districts	33 (5 divisions)
Government
 • Body	Government of Chhattisgarh
 • Governor	Ramen Deka
 • Chief minister	Vishnu Deo Sai[3] (BJP)
 • Deputy chief minister	Arun Sao (BJP)
Vijay Sharma (BJP)
 • Chief secretary	Amit Jain (IAS)
State Legislature	Unicameral
 • Assembly	Chhattisgarh Legislative Assembly (90 seats)
National Parliament	Parliament of India
 • Rajya Sabha	5 seats
 • Lok Sabha	11 seats
High Court	Chhattisgarh High Court
Area[4]
 • Total
135,192 km2 (52,198 sq mi)
 • Rank	9th
Dimensions
 • Length	435 km (270 mi)
 • Width	750 km (470 mi)
Elevation	275 m (902 ft)
Highest elevation (Bailadila Range section[5])	1,276 m (4,186 ft)
Population (2020)[6]
 • Total
Increase29,436,231
 • Rank	17th
 • Density	220/km2 (600/sq mi)
 • Urban	23.24%
 • Rural	76.76%
Demonym	Chhattisgarhiya
Language
 • Official	Hindi
 • Additional official	Chhattisgarhi[7]
 • Official script	Devanagari script
GDP
 • Total (2025-26)	₹6.35 lakh crore (US$75 billion) (2025–26 est.)[8]
 • Rank	18th
 • Per capita	Neutral increase₹199,700 (US$2,400)[9] (26rd)
Time zone	UTC+05:30 (IST)
ISO 3166 code	IN-CG [10]
Vehicle registration	CG[11]
HDI (2022)	Increase 0.625[12] medium (28th)
Literacy (2024)	78.5%[13] (29th)
Sex ratio (2011)	991♀/1000 ♂[14] (13th)
Website	cgstate.gov.in
Symbols of Chhattisgarh

Emblem of Chhattisgarh
Song	Arpa Pairi Ke Dhar (Chhattisgarhi)[1][2]
"The Streams of Arpa and Pairi"
Foundation day	Chhattisgarh Rajyotsava
Bird	Common hill myna
Fish	Walking catfish
Flower	French marigold
Fruit	Jackfruit
Mammal	Wild water buffalo
Tree	Sal tree
State highway mark

State highway of Chhattisgarh
CT SH1 – CT SH29
List of Indian state symbols
Chhattisgarh (/ˈtʃætɪsɡɑːr/; Hindi: [ˈtʃʰət̪ːiːsgəɽʱ]) is a landlocked state in Central India. It is the ninth largest state by area, and with a population of roughly 30 million, the seventeenth most populous.[15] It borders seven states – Uttar Pradesh to the north, Madhya Pradesh to the northwest, Maharashtra to the southwest, Jharkhand to the northeast, Odisha to the east, Andhra Pradesh and Telangana to the south.[16] Formerly a part of Madhya Pradesh, it was granted statehood on 1 November 2000 with Raipur as the designated state capital.[17]

The Sitabenga caves in Chhattisgarh, one of the earliest examples of theatre architecture in India, are dated to the Mauryan period of 3rd century BCE. The region was split between rivaling dynasties from the sixth to twelfth centuries, and parts of it were briefly under the Chola dynasty in the 11th century. Eventually, most of Chhattisgarh was consolidated under the Kingdom of Haihaiyavansi, whose rule lasted for 700 years until they were brought under Maratha suzerainty in 1740. The Bhonsles of Nagpur incorporated Chhattisgarh into the Kingdom of Nagpur in 1758 and ruled until 1845, when the region was annexed by the East India Company, and was later administered under the Raj until 1947 as the Chhattisgarh Division of the Central Provinces. Some areas constituting present-day Chhattisgarh were princely states that were later merged into Madhya Pradesh. The States Reorganisation Act, 1956 placed Chhattisgarh in Madhya Pradesh, and it remained a part of that state for 44 years.

Chhattisgarh is one of the fastest-developing states in India.[18] Its Gross State Domestic Product (GSDP) is ₹5.09 lakh crore (US$60 billion) (2023–24 est.),[8] with a per capita GSDP of ₹152,348 (US$1,800)[8] (2023–24 est.). A resource-rich state, it has the third largest coal reserves in the country and provides electricity, coal, and steel to the rest of the nation.[19][20] It also has the third largest forest cover in the country after Madhya Pradesh and Arunachal Pradesh with over 40% of the state covered by forests.

Etymology
There are several theories as to the origin of the name Chhattisgarh, which in ancient times was known as Dakshina Kosala (South Kosala),[21] the native place of Rama's mother Kausalya. "Chhattisgarh" was popularised later during the time of the Maratha Empire and was first used in an official document in 1795.[22] The Bastar region was previously referred to as Chakrakotya and Cakkarakoṭṭam.[23]

The most popular theory claims that Chhattisgarh takes its name from the 36 ancient forts (from chhattis meaning thirty-six and garh meaning fort) in the area.[24][25] The old state had 36 demesnes (feudal territories): Ratanpur, Vijaypur, Kharound, Maro, Kautgarh, Nawagarh, Sondhi, Aukhar, Padarbhatta, Semriya, Champa, Lafa, Chhuri, Kenda, Matin, Aparora, Pendra, Kurkuti-kandri, Raipur, Patan, Simaga, Singarpur, Lavan, Omera, Durg, Saradha, Sirasa, Menhadi, Khallari, Sirpur, Figeswar, Rajim, Singhangarh, Suvarmar, Tenganagarh and Akaltara.[26] However, most historians disagree with this theory as 36 forts have not been found and identified.

According to the opinion of Hiralal, it is said that at one time there were 36 strongholds in this area, that is why its name was Chhattisgarh. But even after the increase in the number of strongholds, there was no change in the name, Chhattisgarh is the State of India which has been given the status of 'Mahtari' (Mother).[citation needed] There are two regions in India which are named for special reasons – one was 'Magadha' which became "Bihar" due to the abundance of Buddhism viharas and the other was 'Dakshina Kosala' which became "Chhattisgarh" due to the inclusion of thirty-six strongholds.[citation needed]

Another view, more popular with experts and historians, is that Chhattisgarh is the corrupted form of Chedisgarh meaning Raj or "Empire of the Chedis".[citation needed] In ancient times, Chhattisgarh region had been part of the Chedi dynasty of Kalinga, in modern Odisha. In the medieval period up to 1803, a major portion of present eastern Chhattisgarh was part of the Sambalpur Kingdom of Odisha.

History
See also: Sirpur Group of Monuments and Malhar, Chhattisgarh
Ancient and medieval history
During post Vedic period the Chhattisgarh region south-east to Daśārṇas was referred as Pulinda. Pulinda tribe were dominating tribe in this region.[27]

Surguja District of Chhattisgarh is notable for finding of Mauryan and Nanda period coins. Few gold and silver coins of the Nanda - Mauryan ages, picked up at Akaltara and Thathari of the adjacent district of Bilaspur.[28] Another major discovery was Sirpur of Chhattisgarh.[29][30] According to the Chinese traveler Hiuen Tsang, Ashoka erected Buddhist stupas in Shripura (modern-day Sirpur), the ancient capital of Dakshina Kosala.[31]

Sitabenga caves are one of the earliest examples of theatre architecture in India located on Ramgarh hill of Chhattisgarh dated to Mauryan period of 3rd century BCE.[32]


Jogimara cave inscription, Brahmi script, Chhattisgarh (300–160 BCE).

Line1 Poets venerable by nature kindle the heart, who (.... lost ....)
Line2 At the swing-festival of the vernal full-moon, when frolics and music abound, people thus tie (....lost...) thick with jasmine flowers.

— Translated by T. Bloch[33]
Jogimara caves contain ancient Brahmi inscription and the oldest painting known in India. The inscription can be translated as either a love proclamation by a girl or a dancer-painter creating a cave theatre together.[34] In ancient times, this region was known as Dakshina Kosala. This area is also mentioned in Ramayana and Mahabharata.One of the earliest statues of Vishnu has been excavated from Shunga period site at Malhar.


Carved statue in the medieval city of Sirpur

6th 7th century Bhima Kichak Temple, Malhar Chhattisgarh India
The plains region of Chhattisgarh was formerly under the Mauryas, although they likely did not exercise much direct control in the region. After the collapse of the Mauryas, Kharavela of the Mahameghavahana dynasty, which was based in neighbouring Kalinga, took over most of Dakshina Kosala. Later in the third century, the Sathavahanas took over Dakshina Kosala, but this was contested and it returned to Megha rule. Mahendra of Dakshina Kosala, who is believed to be identified with a Megha monarch, was the ruler when Samudragupta carried out his Dakshinapatha conquests and conquered Dakshina Kosala, as recorded in Gupta inscriptions in the early 4th century CE. Afterwards the Guptas held control over Chhattisgarh through vassal rulers, and shared control with the contemporaneous Vakatakas. In the late 5th century CE, the Vakataka ruler Harisena recorded his conquest of the Dakshina Kosala region.

After the death of Vakataka ruler Harisena, the Rajarsitulyakula dynasty centred at Arang, former Gupta feudatories, took power and briefly ruled all of Dakshina Kosala. They were contemporaneous with the Nala dynasty, which was centered on the Bastar and Koraput regions.[35] Both these dynasties were succeeded by the Sharabhpurias in the early 6th century, who were likely also former Gupta vassals who had their capital at present-day Sirpur.[36] The Panduvanshis of Mekala, centered in the northern Chhattisgarh plain, and the Panduvamshis of Dakshina Kosala both ruled parts of Chhattisgarh, but the chronology of these kingdoms is not certain. These kingdoms variously controlled the region from the 6th to 8th centuries CE.[37] There is some evidence that the Somavanshis, who later gained power in Kalinga, originated from the Panduvanshis of Dakshina Kosala and were driven out by the Kalachuris of Tripuri in the late 8th century.[36] The Kalachuris of Tripuri held on to the region for the next 200 years, splitting off their territories in Kosala in the late 10th century to be given to a vassal branch which also called itself Kalachuris.[38]

The Kalachuris of Ratnapura, who were these vassals, became independent at the start of the 11th century to rule and fight off challenges to their authority by neighbouring kingdoms, most notably the Eastern Gangas. The last known successor is from the late 13th century, after which the records become less available. By the early 14th century, it appears as if the dynasty split into two branches: one ruling from Ratnapur and another moving to Raipur. This is attested to by inscriptions of the king Vahara in the late 15th century, identified wtih a figure Bahar Sahai in local tradition at the end of the 18th century.[39] Vahara fought against the Afghans and shifted the capital to Kosgain from Ratnapur. These rulers are now identified as the Haihaiyavanshis and acknowledged the nominal overlordship of the Mughals when they arrived. In the late 14th century, Bastar was ruled by a dynasty which claimed descent from the brother of Prataparudra, the last Kakatiya king, Annamaraja.

Most of Chhattisgarh was consolidated under the Haihaiyavanshi Kingdom, who ruled central Chhattisgarh and held smaller kingdoms like Kanker under their authority.[40][41][42] The Haihaiyavanshis continued to rule the region for 700 years until they were invaded by the Marathas in 1740 and came under their authority. Chhattisgarh was directly annexed to the Maratha Nagpur Kingdom in 1758 on the death of Mohan Singh, the last independent ruler of Chhattisgarh.[43][44]

Modern history
See also: Chhattisgarh Division
Chhattisgarh was under Maratha Rule (Bhonsles of Nagpur) from 1741 to 1845. It came under British rule from 1845 to 1947 as the Chhattisgarh Division of the Central Provinces. Raipur gained prominence over the capital Ratanpur with the advent of the British in 1845. In 1905, the Sambalpur district was transferred to Odisha and the estates of Surguja were transferred from Bengal to Chhattisgarh.

The area constituting the new state merged into Madhya Pradesh on 1 November 1956, under the States Reorganisation Act, 1956, and remained a part of that state for 44 years. Prior to that, the region was part of the Central Provinces and Berar (CP and Berar) under British rule. Some areas constituting the Chhattisgarh state were princely states under British rule, but were later on merged into Madhya Pradesh.[45]

Separation of Chhattisgarh

Mantralaya in Naya Raipur
The demand for Chhattisgarh to be a separate state first rose in the 1920s, with similar demands appearing at regular intervals; however, a well-organised movement was never initiated. Several all-party platforms were created and usually resolved around petitions, public meetings, seminars, rallies and strikes.[46] The demand was raised by the Raipur Congress unit in 1924 and was also discussed in the Indian Congress at Tripuri. A discussion about forming a Regional Congress organisation for Chhattisgarh took place. In 1954, when the State Reorganisation Commission was set up, the demand was put forward but was rejected. In 1955, the demand was raised in the Nagpur assembly of Madhya Bharat.[46]

In the 1990s, the demand became more prominent, resulting in the formation of a statewide political forum known as the Chhattisgarh Rajya Nirman Manch. The forum was led by Chandulal Chadrakar and several successful region-wide strikes and rallies were organised under it, all of which were supported by major political parties, such as the Indian National Congress and the Bharatiya Janata Party.[46]

The new National Democratic Alliance government sent the Separate Chhattisgarh Bill for approval by the Madhya Pradesh Assembly, where it was unanimously approved and then submitted to the Lok Sabha. The bill was passed in the Lok Sabha and the Rajya Sabha, which allowed the creation of the state of Chhattisgarh. K. R. Narayanan gave his consent to the Madhya Pradesh Reorganisation Act on 25 August 2000 and the government of India set 1 November 2000 as the day Chhattisgarh would be separated from Madhya Pradesh.[46] As such, Chhattisgarh was formed from Madhya Pradesh.[17]

Geography
The northern and southern parts of the state are hilly, while the central part is a fertile plain. The highest point in the state is the Gaurlata near Samri, Balrampur-Ramanujganj district.[47] Deciduous forests of the Eastern Highlands Forests cover roughly 44% of the state.[48] In the north lies the edge of the great Indo-Gangetic plain. The Rihand River, a tributary of the Ganges, drains this area. The eastern end of the Satpura Range and the western edge of the Chota Nagpur Plateau form an east–west belt of hills that divide the Mahanadi River basin from the Indo-Gangetic plain. The outline of Chhattisgarh is like a sea horse.

The central part of the state lies in the fertile upper basin of the Mahanadi and its tributaries, of which Shivnath River is a major one running around 300 km long. This area has extensive rice cultivation. The upper Mahanadi basin is separated from the upper Narmada basin to the west by the Maikal Hills (part of the Satpuras) and from the plains of Odisha to the east by ranges of hills. The southern part of the state lies on the Deccan plateau, in the watershed of the Godavari River and its tributary, the Indravati River. The Mahanadi is the chief river of the state. The other main rivers are Hasdeo (a tributary of Mahanadi), Rihand, Indravati, Jonk, Arpa and Shivnath.[49]


The Mahanadi River, in Chhattisgarh
Forest

Achanakmar-Amarkantak Biosphere Reserve
The state has the third largest forest by area in India. The state animal is the van bhainsa, or wild Asian buffalo. The state bird is the pahari myna, or hill myna. The state tree is the Sal (Sarai) found in Bastar division.


Shorea robusta, the State Tree of Chhattisgarh
Chhattisgarh has the 3rd largest forest cover in the country. The state is surrounded by the forests in Madhya Pradesh (1st), Odisha (4th), Maharashtra (5th), Jharkhand and Telangana making it India's largest covered forests across state boundaries. There are multiple National Parks, Tiger Reserves across the state. Achanakmar-Amarkantak Biosphere Reserve is UNESCO recognised Biosphere with total area of 383,551 hectares (3,835.51 square kilometres; 1,480.90 square miles)


[50]
Climate
Chhattisgarh has a tropical climate. It is hot and humid in the summer because of its proximity to the Tropic of Cancer and its dependence on the monsoons for rains. Summer temperatures in Chhattisgarh can reach up to 49 °C (120 °F).[51] The monsoon season is from late June to October and is a welcome respite from the heat. Chhattisgarh receives an average of 1,292 millimetres (50.9 in) of rain. Winter is from November to January. Winters are pleasant with low temperatures and less humidity. Ambikapur, Mainpat, Pendra Road, Samri and Jashpur are some of the coldest places in the state.[52]

Transport
Roads
Chhattisgarh has four-lane or two-lane roads that provide connectivity to major cities. A total of 20 national highways pass through the state, together measuring 3,078 km (1,913 mi). Many national highways exist only on paper and are not fully converted into four-lane, let alone six-lane or eight-lane, highways. These include:

NH 130A New
NH 130B New
NH 130C New
NH 130D New
NH 149B New
NH 163A New
NH 343 New
NH 930 New
NH 53
NH 16
NH 43
NH 12A
NH 78
NH 111
NH 200
NH 202
NH 216
NH 217
NH 221
NH 30
NH 930 New.
The state highways and major district roads constitute another network of 8,031 km (4,990 mi).

Rail network

Bilaspur Junction Railway Station

Raipur Junction railway station
Almost the entire railway network spread over the state comes under the geographical jurisdiction of the South East Central Railway Zone of Indian Railways centred around Bilaspur, which is the zonal headquarters of this zone. Almost 85% of tracks are electrified, the non-electrified route is the Maroda–Bhanupratappur line from the Durg–Bhanupratappur branch line, which is 120 km long. The main railway junctions are Bilaspur Junction, Durg Junction, and Raipur, which is also a starting point of many long-distance trains. These three junctions are well-connected to the major cities of India and also these station comes under the top 50 booking stations in India.[53]

The state has the highest freight loading in the country, and one-sixth of the Indian Railway's revenue comes from Chhattisgarh. The length of the rail network in the state is 1,108 km, while a third track has been commissioned between Durg and Raigarh.[54] Construction of some new railway lines include Dalli–Rajhara–Jagdalpur rail line, Pendra Road–Gevra Road rail line, Raigarh–Mand Colliery to Bhupdeopur rail line and Barwadih–Chirmiri rail line.[55] Freight/goods trains provide services mostly to coal and iron ore industries in east–west corridor (Mumbai–Howrah route). There is a lack of passenger services to the north and south of Chhattisgarh.

Major railway stations of Chhattisgarh
Bilaspur Junction
Durg Junction
Raipur Junction
Ambikapur
Raigarh
Korba
Champa Junction
Mahasamund
Rajnandgaon
Dongargarh
Gevra Road
Pendra Road
Bhatapara
Air

Swami Vivekananda Airport
The air infrastructure in Chhattisgarh is gradually improving. Swami Vivekananda Airport in Raipur is the primary airport (domestic) and is well connected to all major cities of India. Besides this, the smaller Bilaspur Airport, Jagdalpur Airport and Ambikapur Airport are regionally connected with scheduled commercial services. A massive reduction in sales tax on aviation turbine fuel (ATF) from 25 to 4% in Chhattisgarh in 2003 contributed to a sharp rise in passenger flow. The passenger flow increased by 58% between 2011 and November 2012.[56]

Governance
Main articles: Government of Chhattisgarh and Legislative Assembly of Chhattisgarh
The State Legislative Assembly is composed of 90 members of the Legislative Assembly. There are 11 members of the Lok Sabha from Chhattisgarh. The Rajya Sabha has five members from the state

Administration
Divisions
Bastar Division	Durg division	Raipur division	Bilaspur division	Surguja division
Bastar (Jagdalpur)
Bijapur
Dakshin Bastar Dantewada (Dakshin Bastar)
Kondagaon
Narayanpur
Sukma
Uttar Bastar Kanker (Uttar Bastar)
Balod
Bemetara
Durg
Kabirdham (Kabirdham)
Khairagarh-Chhuikhadan-Gandai
Mohla Manpur district
Rajnandgaon
Baloda Bazar
Dhamtari
Gariaband
Mahasamund
Raipur
Bilaspur
Gaurela-Pendra-Marwahi
Janjgir-Champa
Korba
Mungeli
Raigarh
Sarangarh-Bilaigarh
Shakti
Balrampur-Ramanujganj
Jashpur
Koriya (Baikunthpur)
Manendragarh-Chirmiri-Bharatpur
Surajpur
Surguja (Ambikapur)
Districts
Main article: List of districts of Chhattisgarh

Districts of Chhattisgarh state in 2020
Chhattisgarh comprises 33 districts.[57] The following are the list of the districts of Chhattisgarh State with major cities:

District	Headquarter	Largest City	Other Major Cities
Raipur	Raipur	Raipur	Arang, Tilda-Neora
Bilaspur	Bilaspur	Bilaspur	Kota (Kargi Road), Bilha
Durg	Durg	Bhilai	Charoda, Kumhari, Patan
Korba	Korba	Korba	Katghora, Dipka, Pali
Raigarh	Raigarh	Raigarh	Kharsia, Gharghora
Rajnandgaon	Rajnandgaon	Rajnandgaon	Dongargarh, Dongargaon
Koriya	Baikunthpur	Baikunthpur	Ramgarh
Surguja	Ambikapur	Ambikapur	Sitapur
Balrampur-Ramanujganj	Balrampur	Balrampur	Ramanujganj
Jashpur	Jashpur Nagar	Jashpur Nagar	Kunkuri, Patthalgaon, Tapkara
Surajpur	Surajpur	Surajpur	Telgaon, Bishrampur
Janjgir–Champa	Janjgir	Champa	Janjgir-Naila, Akaltara, Shivrinarayan
Mungeli	Mungeli	Mungeli	Lormi, Takhatpur
Kabirdham	Kawardha	Kawardha	Pandariya, Pandatarai
Bemetara	Bemetara	Bemetara	Nawagarh, Saja
Balod	Balod	Balod	Dalli-Rajhara
Baloda Bazar-Bhatapara	Baloda Bazar	Bhatapara	Simga, Palari, Lawan, Kasdol
Gariaband	Gariaband	Gariaband	Rajim, Deobhog
Mahasamund	Mahasamund	Mahasamund	Saraipali, Bagbahra
Dhamtari	Dhamtari	Dhamtari	Kurud
Bijapur	Bijapur	Bijapur	Sangampal, Kasiguda
Narayanpur	Narayanpur	Narayanpur	Kodenar, Orchha
Kanker	Kanker	Kanker	Bhanupratapur,
Pakhanjore

Bastar	Jagdalpur	Jagdalpur	Bastar
Dantewada	Dantewada	Dantewada	Kirandul, Geedam
Kondagaon	Kondagaon	Kondagaon	Keshkal
Sukma	Sukma	Sukma	Tadmetla, Murtonda
Gaurela-Pendra-Marwahi	Gaurella	Pendra	Marwahi, Basti-Bagra, Rajmergarh, Pasan
Manendragarh-Chirmiri-Bharatpur	Manendragarh	Chirmiri	Bharatpur, Khongapani, Jhagrakhand, New Ledri, Janakpur
Mohla-Manpur-Ambagarh Chowki	Mohla	Ambagarh Chowki	Manpur, Chilamtol
Sakti	Sakti	Sakti	Sonthi
Sarangarh-Bilaigarh	Sarangarh	Sarangarh	Bilaigarh
Khairagarh-Chhuikhadan-Gandai	Khairagarh	Khairagarh	Gandai, Chhuikhadan
Major cities
Main article: List of cities in Chhattisgarh
Largest cities in Chhattisgarh
(2011 Census of India estimate)[58]
Rank	City	District	Population
1	Raipur	Raipur	1,010,087
2	Bhilai-Durg	Durg	1,003,406
3	Bilaspur	Bilaspur	717,030
4	Korba	Korba	365,253
5	Ambikapur	Sarguja	214,575
6	Rajnandgaon	Rajnandgaon	163,122
7	Raigarh	Raigarh	150,019
8	Jagdalpur	Bastar	125,463
9	Chirmiri	Koriya	103,575
10	Dhamtari	Dhamtari	101,677
11	Mahasamund	Mahasamund	54,413
Economy
Economy of Chhattisgarh
Statistics
GDP	₹6.359 lakh crore (US$75 billion) (2025–26 est.)[8]
GDP rank	17th
GDP growth	8% (2020–21)[8]
GDP per capita	₹152,348 (US$1,800) (2023–24)[8]
GDP by sector	Agriculture 32%
Industry 32%
Services 36% (2023–24)[8]
Public finances
Government debt	23.8% of GSDP (2023–24 est.)[8]
Budget balance	₹−17,461 crore (US$−2.1 billion) (3.33% of GSDP) (2023–24 est.)[8]
Revenues	₹106,301 crore (US$13 billion) (2023–24 est.)[8]
Expenses	₹121,495 crore (US$14 billion) (2023–24 est.)[8]
All values, unless otherwise stated, are in US dollars.
Chhattisgarh's nominal gross state domestic product (GSDP) is estimated at ₹5.09 lakh crore (US$60 billion) in 2023–24, the 17th largest state economy in India. The economy of Chhattisgarh recorded a growth rate of 11.2% in 2023–24.[8] Chhattisgarh's success factors in achieving high growth rate are growth in agriculture and industrial production.


GEVRA DUMPERS

NTPC Korba Power Plant - panoramio
Agriculture
Agriculture is counted as the chief economic occupation of the state. According to a government estimate, the net sown area of the state is 4.828 million hectares and the gross sown area is 5.788 million hectares.[59] Horticulture and animal husbandry also engage a major share of the total population of the state.[60] About 80% of the population of the state is rural and the main livelihood of the villagers is agriculture and agriculture-based small industry.

The majority of the farmers are still practicing the traditional methods of cultivation, resulting in low growth rates and productivity. The farmers have to be made aware of modern technologies suitable to their holdings. Providing adequate knowledge to the farmers is essential for a better implementation of the agricultural development plans and to improve productivity.[61]

Considering this and a very limited irrigated area, the productivity of not only rice but also other crops is low, hence the farmers are unable to obtain economic benefits from agriculture and it has remained as subsistence agriculture till now.

Chloroxylon is used for pest management in organic rice cultivation in Chhattisgarh
Chloroxylon is used for pest management in organic rice cultivation in Chhattisgarh
 
Medicinal rice of Chhattisgarh used as an immune booster
Medicinal rice of Chhattisgarh used as an immune booster
 
Aloe vera farming in Chhattisgarh
Aloe vera farming in Chhattisgarh
 
Herbal farming in Chhattisgarh: Gulbakawali
Herbal farming in Chhattisgarh: Gulbakawali
Agricultural products
The main crops are rice, maize,[62] kodo-kutki and other small millets and pulses (tuar[63] and kulthi); oilseeds, such as groundnuts (peanuts), soybeans[64] and sunflowers are also grown. In the mid-1990s, most of Chhattisgarh was still a monocrop belt. Only one-fourth to one-fifth of the sown area was double-cropped. When a very substantial portion of the population is dependent on agriculture, a situation where nearly 80% of a state's area is covered only by one crop, immediate attention to turn them into double crop areas is needed. Also, very few cash crops are grown in Chhattisgarh, so there is a need to diversify the agricultural produce towards oilseeds and other cash crops. Chhattisgarh is also called the "rice bowl of central India".[59]

Kodo Millet is used as a life-saving medicine in Chhattisgarh
Kodo Millet is used as a life-saving medicine in Chhattisgarh
 
Bastar beer prepared from Sulfi
Bastar beer prepared from Sulfi
Irrigation

Amritdhara chirimiri
In Chhattisgarh, rice, the main crop, is grown on about 77% of the net sown area. Only about 20% of the area is under irrigation; the rest depends on rain. Of the three agroclimatic zones, about 73% of the Chhattisgarh plains, 97% of the Bastar plateau, and 95% of the northern hills are rainfed. The irrigated area available for double cropping is only 87,000 ha in the Chhattisgarh plains and 2300 ha in Bastar plateau and northern hills. Due to this, the productivity of rice and other crops is low, hence the farmers are unable to obtain economic benefits from agriculture and it has remained as subsistence agriculture till now, though agriculture is the main occupation of more than 80% of the population.[61]

In the Chhattisgarh region, about 22% of the net cropped area was under irrigation as compared to 36.5% in Madhya Pradesh in 1998–99, whereas the average national irrigation was about 40%. The irrigation is characterised by a high order of variability ranging from 1.6% in Bastar to 75.0% in Dhamtari. Based on an average growth trend in the irrigated area, about 0.43% of additional area is brought under irrigation every year as compared to 1.89% in Madhya Pradesh and 1.0% in the country as a whole. Thus, irrigation has been growing at a very low rate in Chhattisgarh and the pace of irrigation is so slow, that it would take about 122 years to reach the 75% level of net irrigated area in Chhattisgarh at the present rate of growth.[61]

Chhattisgarh has a limited irrigation system, with dams and canals on some rivers. Average rainfall in the state is around 1400 mm and the entire state falls under the rice agroclimatic zone. The Large variation in the yearly rainfall directly affects the production of rice. Irrigation is the prime need of the state for its overall development and therefore the state government has given top priority to the development of irrigation.[59]

A total of four major, 33 medium, and 2199 minor irrigation projects have been completed and five major, nine medium, and 312 minor projects are under construction, as of 31 March 2006.[needs update]

Industrial sector
Power sector
Chhattisgarh is one of the few states of India where the power sector is effectively developed. Based on the current production of surplus electric power, the position of the State is comfortable and profitable. The Chhattisgarh State Electricity Board (CSEB) is in a strong position to meet the electricity requirement of the state and is in good financial health. According to Central Electricity Authority (CEA), Chhattisgarh provides electricity to several other states because of surplus production.[65]

In Chhattisgarh, National Thermal Power Corporation Limited (NTPC) has Sipat Thermal Power Station with a capacity of 2,980 MW at Sipat, Bilaspur; LARA Super Thermal Power Station with a nameplate capacity of 1600MW and Korba Super Thermal Power Station with a capacity of 2,600 MW at Korba, while CSEB's units have a thermal capacity of 1,780 MW and hydel capacity of 130 MW. Apart from NTPC and CSEB, there are several private generation units of large and small capacity. The state government has pursued a liberal policy with regard to captive generation which has resulted in a number of private companies coming up.[66]

The state has a potential of 61,000 MW of additional thermal power in terms of availability of coal for more than 100 years and more than 2,500 MW hydel capacity. To use this vast potential, substantial additions to the existing generation capacity are already underway.[66]

Steel sector
The steel industry is one of the biggest heavy industries of Chhattisgarh. Bhilai Steel Plant, Bhilai operated by SAIL, with a capacity of 5.4 million tonnes per year, is regarded as a significant growth indicator of the state. More than 100 steel rolling mills, 90 sponge iron plants, and ferro-alloy units are in Chhattisgarh. Along with Bhilai, today Jagdalpur, Raipur, Bilaspur, Korba and Raigarh have become the steel hub of Chhattisgarh. Today, Raipur and Jagdalpur has become the centre of the steel sector, the biggest market for steel in India.[67]


Aluminium sector
The aluminium industry of Chhattisgarh was established by the erstwhile Bharat Aluminium Company (now Vedanta Resources) in Korba, Chhattisgarh, which has a capacity of around 5,700,000 tonnes each year.[67]

Natural resources
Gevra, Dipka, Kusmunda open cast coal mines in Korba are the largest in India and the biggest man-made structure visible in satellite images of India. Major coal companies are SECL, Adani, Jindal which operate multiple coal mines across northeast Chhattisgarh.

Central India Coalfields
The Central India Coalfields are spread over the districts of Surguja, Koriya (both in Chhattisgarh), Shahdol and Umaria (both in Madhya Pradesh). The group covers an area of about 5,345 square kilometres (2,064 sq mi) with estimated reserves of 15,613.98 million tonnes. The deposits are at a depth of 0–1200 meters. Therefore, extraction is mainly amenable to underground mining except for a few blocks in the eastern part of these coalfields which have opencast potential.[68]

Jhilimili Coalfield located in Surguja district is spread over an area of 180 square kilometres (69 sq mi). Estimated total reserves are 215.31 million tonnes, out of which about half have been indicated to be Grade I.[69] According to the Geological Survey of India, total reserves of non-coking coal (as of 1 January 2004) in Jhilimili Coalfield (up to a depth of 300m) was 267.10 million tonnes.[70]

The Sonhat is a large coal field representing one of the largest coal reserves in India having estimated reserves of 2.67 billion tonnes of coal.[71]

Bisrampur coal field represents one of the largest coal reserves in India having estimated reserves of 1.61 billion tonnes of coal.[71]

Chirimiri Coalfield is located in the valley of the Hasdeo River, a tributary of the Mahanadi. Opened in 1930 with production starting in 1932, and has been owned by several companies and owners such as Chirimiri Colliery Company Pvt. Ltd., Dababhoy's New Chirimiri Ponri Hill Company (Private) Limited, United Collieries Limited, K.N. Dhady and Indra Singh & Sons (Private) Limited. These were nationalized in 1973.[citation needed] This coalfield is spread over 125 square kilometres (48 sq mi) of hilly country and includes both the sections – Kurasia and Chirimiri. Total reserves in the Chirimiri coalfield have been estimated to be around 312.11 million tonnes.[72][73] According to Geological Survey of India reserves of non-coking coal up to a depth of 300 m in Chirimiri Coalfield was 362.16 million tonnes.[74]

South Chhattisgarh coalfields
The South Chhattisgarh Coalfields are made up of the Mand Raigarh, Korba, and Hasdo Arand coalfields. Of at least twelve seams in the Mand Valley, the Mand and Taraimar seams are important.[75]

Mand Raigarh Coalfield includes the areas earlier known as North Raigarh, South Raigarh, and Mand River Coalfields and is located in Raigarh district and lies in the valley of the Mand River, a tributary of the Mahanadi. This coalfield is spread over an area of 520 square kilometres (200 sq mi). The field has a potential for mining power-grade coal, much of which can be extracted through open-cast mining. Gare block has been identified for captive mining by private companies.[76][77]

According to the Geological Survey of India total reserves (including proved, indicated, and inferred reserves) of non-coking coal in the Mand Raigarh Coalfield is 18,532.93 million tonnes. Out of this 13,868.20 million tonnes is up to a depth of 300 metres, 4569.51 million tonnes is at a depth of 300–600 metres and 95.22 million tonnes is at a depth of 600–1200 m.[78]

Mineral deposits in the Maikal Hills
Mineral deposits in the Maikal Hills
 
Mineral Wealth from Chandidongri
Mineral Wealth from Chandidongri
Mineral deposits
Chhattisgarh is rich in minerals. It produces 50% of the country's total cement production. Due to its proximity to the western States of Maharashtra and Gujarat, it has the highest producing coal mines in India. It has the highest output of coal in the country with the second-highest reserves. It is third in iron ore production and first in tin production. Limestone, dolomite and bauxite are abundant. It is the only tin ore-producing state in India. Other commercially extracted minerals include corundum, garnet, quartz, marble, alexandrite and diamonds.

Rowghat iron ore deposits are located in the Antagarh Tahsil of Kanker district and contain the largest iron ore deposits after the Bailadila Iron Ore Mine. Rowghat Mines' reserves have been assessed at 731.93 Mn tonnes. Bailadila has reserves assessed at 1.343 Bn tonnes.[79] Iron ore deposits in Rowghat were discovered in 1899 and in 1949 Geological Survey of India investigated the area.[80] Rowghat deposit is 29 km (18 mi) NNW of Narayanpur, and about 140 km (87 mi) from Jagdalpur. Fe content varies in the various blocks - A Block (62.58% Fe), B Block (50.29% Fe), C Block (57.00% Fe), D Block (60.00% Fe), E Block (52.93% Fe), and F Block (59.62% Fe).

Information and technologies
In recent years, Chhattisgarh has also received exposure in information technology (IT) projects and consultancy. Its government is also promoting IT and has set up a body to take care of IT solutions. The body, known as CHiPS, is providing large IT projects such as Choice, Swan, and so forth.

Major companies
Major companies with a presence in the state include:

Metal: Bhilai Steel Plant, Jindal Steel and Power, Bharat Aluminium Company
Oil: Indian Oil Corporation, Hindustan Petroleum Corporation Limited
Mining: NMDC, South Eastern Coalfields
Power : NTPC, Lanco Infratech, KSK Energy Ventures, Jindal Power Limited
Exports
Chhattisgarh's total exports were US$353.3 million in 2009–10. Nearly 75% of exports come from Bhilai and the remaining are from Urla, Bhanpuri, and Sirgitti. The major export products include steel, handicrafts, handlooms, blended yarn, food and agri-products, iron, aluminum, cement, minerals, and engineering products. CSIDC (Chhattisgarh State Industrial Development Corporation Limited) is the nodal agency of the government of Chhattisgarh for export promotion in the state.

Media
Mainline print media present in Chhattisgarh are Hari Bhoomi,[81] Dainik Bhaskar, Patrika, Navabharat, and Nai Duniya.

Human Development Indicators
HDI
As of 2018, Chhattisgarh state had a Human Development Index value of 0.613 (medium), ranking 31st in Indian states & union territories. The national average is 0.647 according to Global Data Lab.[82]

Standard of living
The standard of living in Chhattisgarh is extremely imbalanced. The cities such as Durg, Raipur, Bhilai and Bilaspur have a medium to high standard of living, while the rural and forested areas lack even the basic resources and amenities. For example, Bhilai has a literacy rate of 86%, while Bastar has a literacy rate of 54%.[83]

Raipur, the capital of Chhattisgarh, is one of the fastest-developing cities in India.[84] Atal Nagar (Formerly Naya Raipur[85]) is the new planned city that is touted to become the financial hub of the Central Indian region. New world-class educational institutions and hospitals have already been established in the city.[86]

According to the NITI Aayog's Fiscal Health Index 2025, Chhattisgarh ranks second with a score of 55.2.[87]

Education Index

School children in Chhattisgarh
Chhattisgarh has an Education Index of 0.526 according to the 2011 NHDR, which is higher than that of the states of Bihar, Jharkhand, Uttar Pradesh, and Rajasthan. The Average Literacy rate in Chhattisgarh for Urban regions was 84.05 percent in which males were 90.58% literate while female literacy stood at 73.39%. Total literates in the urban region of Chhattisgarh were 4,370,966.[citation needed]

Among the marginalized groups, STs are at the bottom of the rankings, further emphasizing the lack of social development in the state. Bastar and Dantewada in south Chhattisgarh are the most illiterate districts and the dropout ratio is the highest among all the districts. The reason for this is the extreme poverty in rural areas.

Ramakrishna Mission Asharama Narainpur serves the tribals in the abhjhmad jungle region of Chhattisgarh for their upliftment and education.[88]

As per census 2011, the State has a population of 25.5 million and six medical colleges (five Government and one private) with an intake capacity of 700 students and a doctor-patient ratio of 1:17,000.[89] Under The NITI Aayog released Health Index report titled, "Healthy States, Progressive India", Chhattisgarh has an index of 52.02 Out of 100, which is better than states such as Madhya Pradesh, Haryana, Rajasthan, Odisha, Bihar, Assam and Uttar Pradesh.[90]

Despite different health-related schemes and programs, the health indicators such as the percentage of women with BMI<18.5, Under Five Mortality Rate and underweight children, are poor. This may be due to the difficulty in accessing the remote areas in the state. The prevalence of female malnutrition in Chhattisgarh is higher than the national average—half of the ST females are malnourished. The performance of SCs is a little better than the corresponding national and state average. The Under Five Mortality Rate among STs is significantly higher than the national average.

Net state domestic product
Chhattisgarh is one of the emerging states with relatively high growth rates of net state domestic product (NSDP) (8.2% vs. 7.1% All India over 2002–2008) and per capita NSDP (6.2% vs. 5.4% All India over 2002–2008). The growth rates of the said parameters are above the national averages and thus it appears that Chhattisgarh is catching up with other states in this respect. However, the state still has very low levels of per capita income as compared to the other states.

Urbanisation
Out of the total population of Chhattisgarh, 23.24% live in urban regions. The total population living in urban areas is 5,937,237, of which 3,035,469 are males and the remaining 2,901,768 are females.

Raipur, Durg, Bhilai Nagar, Bilaspur, Korba, Jagdalpur, Rajnandgaon, Ambikapur and Raigarh are some of the urban towns and cities in the region.[91]

Sex ratio
There are more than 13 million males and 12.9 million females in Chhattisgarh, which constitutes 2.11% of the country's population. The sex ratio in the state is one of the most balanced in India with 991 females per 1,000 males, as is the child sex ratio with 964 females per 1,000 males (Census 2011)

Fertility rate
Chhattisgarh has a fairly high fertility rate (2.4) as of 2017 compared to All India (2.2) and the replacement rate (2.1). It has a rural fertility rate of 2.6 and an urban fertility rate of 1.9

SC and ST population
With the exception of the hilly states of the north-east, Chhattisgarh has one of highest shares of Scheduled Tribe (ST) populations within a state, accounting for about 10 percent of the STs in India. Scheduled Tribes make up 30.62% of the population. The tribals are an important part of the state population and mainly inhabit the dense forests of Bastar and other districts of south Chhattisgarh. The percentage increase in the population of the scheduled list of tribals during the 2001–2011 decade had been at the rate of 18.23%. The Scheduled Caste (SC) population of Chhattisgarh is 2,418,722 as per the 2001 census constituting 11.6 percent of the total population (20,833,803). The proportion of Scheduled Castes has increased from 11.6 percent in 2001 to 12.8% in 2011.

Poverty

Tendu Patta (Leaf) collection in Chhattisgarh, India.
The incidence of poverty in Chhattisgarh is very high. The estimated poverty ratio in 2004–05 based on uniform reference period consumption was around 50 percent, which is approximately double the all-India level. The incidence of poverty in the rural and urban areas is almost the same.

More than half of the rural STs and urban SCs are poor. In general, the proportion of poor SC and ST households in the state is higher than the state average and their community's respective national averages (except for rural SC households). Given that more than 50 percent of the state's population is ST and SC, the high incidence of income poverty among them is a matter of serious concern in the state.

This indicates that the good economic performance in recent years has not percolated to this socially deprived group, which is reflected in their poor performance in human development indicators.

Access to drinking water
In terms of access to improved drinking water sources, at the aggregate level, Chhattisgarh fared better than the national average and the SCs of the state performed better than the corresponding national average. Scheduled Tribes are marginally below the state average, but still better than the STs at the all-India level.

The proportion of households with access to improved sources of drinking water in 2008–09 was 91%. This proportion was over 90% even in states like Bihar, Chhattisgarh, Madhya Pradesh and Uttar Pradesh. This was largely because these states had over 70% of their households accessing tube wells/hand pumps as sources of drinking water.

Sanitation
Sanitation facilities in the state were abysmally low with only about 41 percent having toilet facilities before the Swachh Bharat Mission was launched by the Government of India. The Urban areas of Chhattisgarh attained the title of open defecation free on 2 October 2017 and the rural areas have achieved a 90.31% sanitation coverage. What sets Chhattisgarh apart from other states of India is an approach to bring in behavioral change in order to get open defecation-free status. In Chhattisgarh, people don't get toilet incentives before the construction of toilets, so they have to construct the toilet with their own money, and only after using the toilet for 3 months are they entitled to the incentive amount.[92]

In 2020, it again won the title of the cleanest state with more than 100 Urban Local Bodies, as announced by Minister for Housing and Urban Affairs Hardeep Singh Puri following the 'Swachh Survekshan 2020'.[93] In the Swachh Survekshan Awards-2023, Chhattisgarh secured the third rank in the 'Best Performing States' category.[94]

Teledensity
Across states, it has been found that teledensity (telephone density) was below 10 percent in 2010 for Chhattisgarh and Jharkhand, reflecting a lack of access to telephones in these relatively poorer states. But due to development of new technology the teledensity in 2017 is 68.08 percent which shows improvement of telecom infrastructure. On the other hand, for states like Delhi and Himachal Pradesh and metropolitan cities like Kolkata, Mumbai, and Chennai, teledensity was over 100 percent in 2010 implying that individuals have more than one telephone connection.

Road density
The total density of National Highways (NHs) in Chhattisgarh is at 23.4 km per 1,000 km2 out of the total length of 3,168 km in the State, the Central Government has informed. Chhattisgarh Government had completed construction of 5,266 cement concrete (CC) roads having a total length of 1,530 km in various villages of the State as on 31 May 2016 under 'Mukhyamantri Gram Sadak Yojana'.[95]

Witchcraft

This section needs additional citations for verification. Please help improve this article by adding citations to reliable sources in this section. Unsourced material may be challenged and removed. (August 2023) (Learn how and when to remove this message)

Social Mission Against Blind Faith
To bring about social reforms and with a view to discourage undesirable social practices, Chhattisgarh government has enacted the Chhattisgarh Tonhi Atyachar (Niwaran) Act, 2005 against witchery.[citation needed] Much has to be done on the issue of law enforcement by judicial authorities to protect women in this regard, bringing such persecution to an end.[96]

Some sections of tribal population of Chhattisgarh state believe in witchcraft.[96] Women are believed to have access to supernatural forces and are accused of being witches (tonhi) often to settle personal scores.

As of 2010, they are still hounded out of villages on the basis of flimsy accusations by male village sorcerers paid to do so by villagers with personal agendas, such as property and goods acquisition.[96] According to National Geographic Channel's investigations, those accused are fortunate if they are only verbally bullied and shunned or exiled from their village.

Demographics
Historical population
Year	Pop.	±%
1901	4,181,554	—    
1911	5,191,583	+24.2%
1921	5,264,976	+1.4%
1931	6,028,778	+14.5%
1941	6,814,886	+13.0%
1951	7,457,000	+9.4%
1961	9,154,000	+22.8%
1971	11,637,000	+27.1%
1981	14,010,000	+20.4%
1991	17,615,000	+25.7%
2001	20,834,000	+18.3%
2011	25,540,198	+22.6%
Source: Census of India[97][98]
Chhattisgarh has an urban population of 23.4% (around 5.1 million people in 2011) residing in urban areas. According to a report by the government of India,[99] at least 30% are Scheduled Tribes, 12% are Scheduled Castes and over 45.5% belong to the official list of Other Backward Classes. The plains are numerically dominated by castes such as Teli, Satnami and Yadav while forest areas are mainly occupied by tribes such as Gond, Halba, Kamar/Bujia and Oraon. There is also a major general population like Rajputs, Brahmin, Kurmi, Bania, etc. A community of Bengalis has existed in major cities since the times of the British Raj. They are associated with education, industry, and services.


Danteshwari Temple is one of the Shakti peethas
Religion
Religion in Chhattisgarh (2011)
Hinduism (93.25%)
Islam (2.02%)
Christianity (1.92%)
Buddhism (0.28%)
Sikhism (0.27%)
Jainism (0.24%)
Other (Tribal religion) (1.94%)
None or not stated (0.09%)
According to the 2011 census, 93.25% of Chhattisgarh's population practised Hinduism, while 2.02% followed Islam, 1.92% followed Christianity and a smaller number followed Buddhism, Sikhism, Jainism or other religions.[100]

Hindus are the majority in the state and are the dominant religion in all districts of the state. One sect particular to Chhattisgarh are the Satnamis aka Satnampanthis, who follow Guru Ghasidas, a saint who promoted bhakti towards God and against the caste system. Chhattisgarh has many famous pilgrimage sites, such as the Bambleshwari Temple in Dongargarh and Danteshwari temple in the Dantewada, one of the Shakti Peethas. Buddhism was once a major religion in Chhattisgarh.

Islam is the second-largest religion, concentrated in urban centres. Most Christians are tribals from the Surguija region.

Language

Languages spoken by district
Chhattisgarhi
  30–40%
  50–60%
  60–70%
  70-80%
  80-90%
  90–100%
Gondi
  50–60%
  60–70%
Nagpuri
  40–50%
Hindi
  30–40%
Halbi
  30–40%
  40–50%
Main article: Chhattisgarhi language
Language data from 2011 census[101]
Chhattisgarhi(Including Surgujia dialect) (68.7%)
Hindi (10.61%)
Gondi (3.95%)
Halbi (2.76%)
Odia (2.68%)
Sadri (2.53%)
Kurukh (2.02%)
Bengali (0.95%)
Other (5.80%)
The official language of the state is Hindi, with Chhattisgarhi being the additional official language. Chhattisgarhi is spoken and understood by the majority of people in Chhattisgarh and is the dominant language in the Chhattisgarh plain. Chhattisgarhi is called Khaltahi by tribals and Laria in Odia. Chhattisgarhi is itself divided into many dialects, one of the most distinct being Surgujia from the Surguja region, which is sometimes considered its own language. Near the Uttar Pradesh border this dialect merges into Bhojpuri, while it merges with Bagheli near the Madhya Pradesh border. Surgujia also merges into Sadri in the northeast along the border with Jharkhand. Hindi is spoken by many migrants from outside the state, and is a major language in the cities and industrial centres, while many whose language is actually Chhattisgarhi record their speech as Hindi in the census. Odia is widely spoken in eastern Chhattisgarh, especially near the Odisha border. Telugu and Marathi speaking minorities can be found along the Telangana and Maharashtra borders respectively. In the eastern Bastar region, Halbi and Bhatri are major languages.

In addition, Chhattisgarh has several indigenous languages. Kurukh and Korwa are both spoken in the Surguja region. Gondi is a major language in southern Chhattisgarh: Bastar and the adjoining districts. Gondi has many dialects, such as Muria in north Bastar, which transitions to Madia further south and Dorli, transitional between Gondi and Koya, along the borders of Andhra Pradesh and Telangana. In the east of Bastar. Most Gonds in the north and east of Bastar, as well as the rest of the state, speak regional languages and have largely forgotten their original tongue.[102][103][104][105]

Gender ratio
Chhattisgarh has a high female-male sex ratio (991)[106] ranking at the fifth position among other states of India. Although this ratio is small compared to other states, it is unique in India because Chhattisgarh is the 10th-largest state in India.

The gender ratio (number of females per 1,000 males) has been steadily declining over 20th century in Chhattisgarh. But it is conspicuous that Chhattisgarh always had a better female-to-male ratio compared with national average.

Year	1901	1911	1921	1931	1941	1951	1961	1971	1981	1991	2001	2011
India	972	964	955	950	945	946	941	930	934	927	933	940
Chhattisgarh	1046	1039	1041	1043	1032	1024	1008	998	998	985	989	991
Rural women, although poor, are independent, better organised, and socially outspoken. According to another local custom, women can choose to terminate a marriage relationship through a custom called chudi pahanana, if she desires. Most of the old temples and shrines follow Shaktism and are goddess-centric (e.g., Shabari, Mahamaya, Danteshwari) and the existence of these temples gives insight into the historical and current social fabric of this state. However, a mention of these progressive local customs in no way suggests that the ideology of female subservience does not exist in Chhattisgarh. On the contrary, male authority and dominance are seen quite clearly in social and cultural life.[107]

Culture
See also: List of folktales of Chhattisgarh

A carving in the 10th- or 11th-century Hindu temple of Malhar village. This area, 40 km from Bilaspur, was supposedly a major Buddhist centre in ancient times.

Pandwani

Raut Nacha

Suwa Nacha at Khudmudi Village, Chhattisgarh

Natya Samaroh by IPTA

Red Velvet Mite is used as medicine in traditional healing in Chhattisgarh
The state hosts many religious sects such as Satnampanth, Kabirpanth, Ramnami Samaj and others. Champaran is a small town with religious significance as the birthplace of the saint Vallabhacharya, increasingly important as a pilgrimage site for the Gujarati community.

Chhattisgarh has a significant role in the life of the Lord Rama. Lord Rama along with his wife Sita and his younger brother Lakshmana had started his Vanvas (exile) in the Bastar, then known as Dandakarayna. They lived more than 10 of their 14 years of Vanvas in different places of Chhattisgarh. One of the remarkable places is Shivrinarayan which is nearby Bilaspur district of Chhattisgarh. Shivrinarayan was named after an old lady Shabari. When Ram visited Shabari she said "I do not have anything to offer other than my heart, but here are some berry fruits. May it please you, my Lord."[This quote needs a citation] Saying so, Shabari offered the fruits she had meticulously collected to Rama. When Rama was tasting them, Lakshmana raised the concern that Shabari had already tasted them and therefore unworthy of eating. To this Rama said that of the many types of food he had tasted, "nothing could equal these berry fruits, offered with such devotion. You taste them, then alone will you know. Whomsoever offers a fruit, leaf, flower or some water with love, I partake it with great joy."[This quote needs a citation]

The Odia culture is prominent in the eastern parts of Chhattisgarh bordering Odisha.

Literature
Chhattisgarh is a storehouse of literature, performing arts and crafts—all of which derives its substance and sustenance from the day-to-day life experiences of its people. Religion, mythology, social and political events, nature, and folklore are favourite motifs. Traditional crafts include painting, woodcarving, bell metal craft, bamboo ware, and tribal jewellery. Chhattisgarh has a rich literary heritage with roots that lie deep in the sociological and historical movements of the region. Its literature reflects the regional consciousness and the evolution of an identity distinct from others in Central India.

Crafts
Chhattisgarh is known for "Kosa silk" and "Dhokra or Bell metal art". Besides saris and salwar suits, the fabric is used to create lehengas, stoles, shawls and menswear including jackets, shirts, achkans and sherwanis. Works by the internationally renowned sculptor, Sushil Sakhuja's Dhokra Nandi, are available at the government's Shabari Chhattisgarh State Emporium, Raipur.

Dance
Panthi, Raut Nacha, Pandwani, Chaitra, Kaksar, Saila, Khamb-swang, Bhatra Naat, Rahas, Raai, Maao-Pata and Soowa are the several indigenous dance styles of Chhattisgarh.

Panthi, the folk dance of the Satnami community, has religious overtones. Panthi is performed on Maghi Purnima, the anniversary of the birth of Guru Ghasidas. The dancers dance around a jaitkhamb set up for the occasion, to songs eulogising their spiritual head. The songs reflect a view of nirvana, conveying the spirit of their guru's renunciation and the teachings of saint poets like Kabir, Ramdas and Dadu. Dancers with bent torsos and swinging arms dance, carried away by their devotion. As the rhythm quickens, they perform acrobatics and form human pyramids.[108]

Pandavani
Pandavani is a folk ballad form performed predominantly in Chhattisgarh. It depicts the story of the Pandavas, the leading characters in the epic Mahabharata. The artists in the Pandavani narration consist of a lead artist and some supporting singers and musicians. There are two styles of narration in Pandavani, Vedamati, and Kapalik. In the Vedamati style, the lead artist narrates in a simple manner by sitting on the floor throughout the performance. The Kaplik style is livelier, where the narrator actually enacts the scenes and characters. Padma Shri, Padma Bhushan, and Padma Vibhushan Teejan Bai is most popular artist of Pandavani[109]

Raut Nacha
Raut Nacha, the folk dance of cowherds, is a traditional dance of Yaduvanshis (clan of Yadu) as symbol of worship to Krishna from the 4th day of Diwali (Goverdhan Puja) till the time of Dev Uthani Ekadashi (day of awakening of the gods after a brief rest) which is the 11th day after Diwali according to the Hindu calendar. The dance closely resembles Krishna's dance with the gopis (milkmaids).[110][111]

In Bilaspur, the Raut Nach Mahotsav folk dance festival has been organised annually since 1978. Tens of hundreds of Rautt dancers from remote areas participate.[112]

Suwa Nacha
Soowa or Suwa tribal dance in Chhattisgarh is also known as Parrot Dance. It is a symbolic form of dancing related to worship. Dancers keep a parrot in a bamboo pot and form a circle around it. Then performers sing and dance, moving around it with clapping. This is one of the main dance forms of tribal women of Chhattisgarh.[113]

Karma
Tribal groups like Gonds, the Baigas and the Oraons in Chhattisgarh have the Karma dance as part of their culture. Both men and women arrange themselves in two rows and follow the rhythmic steps, directed by the singer group. The Karma tribal dance marks the end of the rainy season and the advent of spring season.[clarification needed][114][115]

Theatre
Theater is known as Gammat in Chhattisgarh. Pandavani is one of the lyrical forms of this theatre. Several acclaimed plays of Habib Tanvir, such as Charandas Chor, are variations of Chhattisgarhi theatre.

Cinema
Chhollywood is Chhattisgarh's film industries. Every year many Chhattisgarhi films are produced by local producers.

Lata Mangeshkar sang a song for Chhattisgarhi film Bhakla of Dhriti pati sarkar.

Mohammed Rafi sang a song for Chhattisgarhi film. He had also sung songs for various Chhattisgarhi films like Ghardwaar, Kahi Debe Sandesh, Punni Ke Chanda, etc.[116][117]

Cuisine
Main article: Cuisine of Chhattisgarh
Chhattisgarh is known as the rice bowl of India and has a rich tradition of food culture.

The typical Chhattisgarhi thali consists of roti, bhat, dal or kadhi, curry, chutney and bhaji. Few Chhattisgarhi dishes are Aamat, Bafauri, Bhajia, Chousela, Dubkikadhi, Farra, Khurmi, Moong Bara, Thethari, and Muthia.[118][119][120][121][122][123]

Festivals of Chhattisgarh
Main article: Festivals of Chhattisgarh
Major festivals of Chhattisgarh include Bastar Dussehra/ Durga Puja, Bastar Lokotsav, Madai Festival, Rajim Kumbh Mela, and Pakhanjore Mela (Nara Narayan Mela).

Tourism
Main article: Tourism in Chhattisgarh
Chhattisgarh, situated in the heart of India, is endowed with a rich cultural heritage and attractive natural diversity. The state is full of ancient monuments, rare wildlife, exquisitely carved temples, Buddhist sites, palaces, waterfalls, caves, rock paintings, and hill plateaus.

Maitri Bagh in Bhilai is the largest and oldest zoo of Madhya Pradesh and Chhattisgarh.

Mainpat is mini Shimla of Chhattisgarh.

There are many waterfalls, hot springs, caves, temples, dams and national parks, tiger reserves and wildlife sanctuaries in Chhattisgarh.

India's first man-made jungle safari is also situated in Raipur.

Sports
Abujhmad Peace Marathon is the largest sports event of Narainpur.

The Chhattisgarhiya Olympics are an annual Chhattisgarhi celebration of traditional Indian games such as kabaddi and kho-kho. The inaugural 2022 edition drew in around 2.6 million participants (almost 10% of the state's population).[124]

Education
Main article: Education in Chhattisgarh
See also: List of institutions of higher education in Chhattisgarh
According to the census of 2011, Chhattisgarh's literacy, the most basic indicator of education, was at 71.04 percent. Female literacy was at 60.59 percent.

Absolute literates and literacy rate
Data from Census of India, 2011.[125]

Description	2001 census	2011 census
Total	20,833,803	25,540,196
Male	10,474,218	12,827,915
Female	10,359,585	12,712,281
% Total	64.66	71.04
% Male	77.38	81.45
% Female	55.85	60.99
