const assamCulture = {
    name: "Assam",
    historicalPerspective: {
        roots: "The roots of culture in Assam go back almost five thousand years.",
        migrations: [
            "Austroasiatic people",
            "Tibeto-Burman peoples",
            "Indo-Aryan peoples",
            "Tai/Shan peoples"
        ],
        significantEvents: [
            "Formation of the Ahom kingdom in 1228",
            "Vaishnava Movement in the 15th century"
        ],
        dynasties: [
            { name: "Varman dynasty", duration: "300 years" },
            { name: "Mlechchha dynasty", duration: "250 years" },
            { name: "Pala dynasty", duration: "200 years" }
        ],
        culturalAssimilation: "Cultural assimilation occurred under various political-economic systems."
    },
    compositionAndCharacteristics: {
        culturalSystem: "A cultural system composed of different ethnic cultural compositions.",
        sourceCultures: "Many source-cultures are still surviving as sub-systems or sister entities."
    },
    elements: {
        symbolism: {
            tamulPaan: "Areca nut and betel leaves, considered offers of devotion and respect.",
            xorai: {
                description: "A traditional bell-metal object used for respectful offerings.",
                uses: [
                    "Offering tray for tamul-pan to guests",
                    "Food offerings in front of the altar",
                    "Decorative symbol in traditional functions",
                    "Gift during felicitations"
                ]
            },
            gamosa: {
                description: "An honorary piece of cloth used for felicitation.",
                significance: "Symbolizes the life and culture of Assam."
            }
        },
        festivals: {
            bihu: {
                description: "A series of three prominent festivals marking the seasons.",
                types: [
                    { name: "Rongali Bihu", significance: "Celebrated with the coming of spring." },
                    { name: "Kongali Bihu", significance: "The barren Bihu when fields are lush." },
                    { name: "Bhogali Bihu", significance: "Thanksgiving after harvest." }
                ]
            },
            baisagu: {
                description: "A popular seasonal festival of the Bodo community, marking the new year."
            },
            jonbeelMela: {
                description: "A three-day annual indigenous Tiwa Community fair.",
                location: "Dayang Belguri at Joonbeel."
            },
            aliAiLigang: {
                description: "Spring festival of the Mising people."
            }
        },
        music: {
            description: "Rich in folk music influenced by various ethnic groups.",
            notableArtists: [
                "Jyoti Prasad Agarwala",
                "Bhupen Hazarika",
                "Zubeen Garg"
            ]
        },
        traditionalCrafts: {
            description: "Rich tradition of crafts including cane and bamboo work, silk weaving, and pottery.",
            notableItems: [
                "Mekhela (traditional attire)",
                "Xorai (offering tray)",
                "Bell metal and brass crafts"
            ]
        },
        paintings: {
            description: "Ancient tradition influenced by medieval works.",
            notableWorks: [
                "Sundarakanta Ramayan",
                "Hastividyarnava"
            ]
        }
    },
    stateAnthem: {
        title: "O Mur Apunar Dekh",
        composer: "Rasaraj Lakshminath Bezbaroa"
    }
};

console.log(assamCulture);
