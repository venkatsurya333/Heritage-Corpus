The culture of Assam is traditionally a hybrid one, developed due to cultural assimilation of different ethno-cultural groups under various political-economic systems in different periods of its history.

Historical perspective
See also: People of Assam
The roots of culture in Assam goes back almost five thousand years when the first wave of humans, the Austroasiatic people reached the Brahmaputra valley. They mixed with the later immigrant Tibeto-Burman and the Indo-Aryan peoples out there in prehistoric times. The last wave of migration was that of the Tai/Shan who later formed the idea of Assamese culture and its identity. The Ahoms, later on, brought some more Indo-Aryans like the Assamese Brahmins and Ganaks and Assamese Kayasthas to Assam.[4]


Actors of Abinaswar Gosthi perform the play "Surjya Mandirot Surjyasta"

17th century pleasure boat (Mayurpokhyi khel-nao) of medieval Assam. A great example of Assamese wood craftsmanship.
According to the epic Mahabharata and on the basis of local folklore, people of Assam (Kiratas) probably lived in a strong kingdom under the Himalayas in the era before Jesus Christ, which led to early assimilation of various Tibeto-Burman and Autro-Asiatic ethnic groups on a greater scale. Typical naming of the rivers and spatial distribution of related ethno-cultural groups also support this theory. Thereafter, western migrations of Indo-Aryans such as those of various branches of Irano-Scythians and Nordics along with mixed northern Indians (the ancient cultural mix already present in northern Indian states such as Magadha enriched the aboriginal culture and under certain stronger politico-economic systems, Sanskritisation and Hinduisation intensified and became prominent. Such an assimilated culture, therefore, carries many elements of source cultures, of which exact roots are difficult to trace and are a matter for research. However, in each of the elements of cultures in Assam, i.e. language, traditional crafts, performing arts, festivities, and beliefs, either indigenous local elements or the indigenous local elements in Sanskritised forms are always present.

It is believed that Assamese culture developed its roots over 750 years as the country of Kamarupa during the first millennium AD of Bodo-Kachari people assimilation with Aryan which is debatable as the idea of Assam as an entity was not present. The first 300 years of Kamarupa was under the great Varman dynasty, 250 years under the Mlechchha dynasty and 200 years under the Pala dynasty. The records of many aspects of the language, traditional crafts (silk, lace, gold, bronze, etc.) are available in different forms. When the Tai-Shans entered the region in 1228 under the leadership of Sukaphaa to establish Ahom kingdom in Assam for the next 600 years, again a new chapter of cultural assimilation was written, and thus the modern form of Assamese culture developed. The original Tai-Shans assimilated with the local culture adopted the language on one hand and on the other also influenced the culture with the elements from their own. Similarly, the Chutiya kingdom in eastern Assam, the Koch Kingdom in western Assam and the medieval Kachari and Jaintia kingdoms in southern Assam provided stages for assimilation at different intensities and with different cultural-mixes.

The Vaishnava Movement, a 15th-century religio-cultural movement under the leadership of Srimanta Sankardeva and his disciples, has provided another dimension to the Assamese culture.


Khol badan during Ankiya Bhaona
A renewed Hinduisation in local forms took place, which was initially greatly supported by the Koch and later by the Ahom Kingdoms. The resultant social institutions such as namghar and sattra – the Vaishnav Hermitage have become part of the Assamese way of life. The movement contributed greatly towards language, literature, and performing and fine arts. On many occasions, the Vaishnav Movement attempted to introduce alien cultural attributes and modify the way of life of the common people. Brajavali, a language specially created by introducing words from other Indian languages, failed as a language but left its traces on the Assamese language. Moreover, new alien rules were also introduced changing people's food habits and other aspects of cultural life. This had a greater impact on the alienation of many ethnocultural and political groups in the later periods.

During periods when strong politico-economic systems emerged under powerful dynasties, greater cultural assimilation created common attributes of Assamese culture, while under less powerful politico-economic systems or during political disintegration, more localized attributes were created with spatial differentiation. Time-factors for such integrations differentiations have also played an important role along with the position of individual events in the entire series of events.

Dunori from Assam.
Dunori from Assam.
 
Traditional painting of Assam.
Traditional painting of Assam.
 
Asamiya textile print design of Gamosa.
Asamiya textile print design of Gamosa.
 
Tamul-paan of Assam.
Tamul-paan of Assam.
 
A Bihu dancer with a horn.
A Bihu dancer with a horn.
 
Jhumura Nritya.
Jhumura Nritya.
With a strong base of tradition and history, modern Assamese culture is greatly influenced by various events that took place in under British rule of Assam and in the Post-British Era. The language was standardized by American Missionaries according to that of the Sibsagar District, the nerve center of the Ahom politico-economic system while a renewed Sanskritisation was increasingly adopted for developing Assamese language and grammar (ব্যাকৰণ). A new wave of Western and northern Indian influence was apparent in the performing arts and literature.

Due to increasing efforts of standardization in the 19th and 20th centuries, the localized forms present in different districts and also among the remaining source-cultures with the less-assimilated ethnocultural groups have seen greater alienation. However, Assamese culture in its hybrid form and nature is one of the richest and is still under development. 20th century saw numerous self-determination and identity movement and many states were new states created in the process as most indigenous tribal communities of the state refused to accept the idea of collective Assamese identity which was imposed upon them. Many indigenous tribal communities of the state still oppose the efforts of assimilation into Assamese cultural identity.

Composition and characteristics

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)
Culture in Assam in its true sense today is a 'cultural system' composed of different ethnic cultural compositions. It is more interesting to note that even many of the source-cultures of culture in Assam are still surviving either as sub-systems or as sister entities. In a broader sense, therefore, the cultural system of Assam incorporates its source-cultures and However, it is also important to keep the broader system closer to its roots.

Elements
Symbolism

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)

Xorai, a traditional symbol of Assam.
Symbolism is an important part of culture in Assam. Various elements are being used to represent beliefs, feelings, pride, identity, etc. Symbolism is an ancient cultural practice in Assam, which is still very important for the people. Tamulpan, Xorai and Gamosa are three important symbolic elements in Assamese culture.

Tamul-paan (the areca nut and betel leaves) or guapan (gua from Goi of Bodo-Chutia language) are considered as the offers of devotion, respect, and friendship. It is an ancient tradition and is being followed since time-immemorial with roots in the aboriginal culture.

Xorai, a traditional symbol of Assam, is a manufactured bell-metal object and an article of great respect and is used as a container-medium while performing respectful offerings. It is an offering tray with a stand at the bottom similar to those found in East and South East Asia. There are Xorais with or without a cover on the top. Traditionally Xorai is made of bell metal although nowadays they can be made from brass and/or silver. Hajo and Sarthebari are the most important centers of traditional bell-metal and brass crafts including Xorais. Xorais are used:

as an offering tray for tamul-pan (betel nuts and betel leaves) to guests as a sign of welcome and thanks.
as an offering tray for food and other items placed in front of the altar (naam ghar) for blessing by the Lord.
as a decorative symbol in traditional functions such as during Bihu dances.
as a gift to a person of honor during felicitations.

Gamosa, an honorary piece of cloth commonly used for Felicitation in Assam very similar to other traditional headgears of East and South East Asia.
The Gamosa is an article of great significance for the people of Assam. Literally translated, it means 'something to wipe the body with' (Ga=body, mosa=to wipe), Its original term is Gamcha; interpreting the word "gamosa" as the body-wiping towel is misleading. It is generally a white rectangular piece of cloth with primarily a red border on three sides and red woven motifs on the fourth (in addition to red, other colors are also used). Though it is used daily to wipe the body after a bath (an act of purification), the use is not restricted to this. It is used by the farmer as a waistcloth (tongali) or a loincloth (suriya); a Bihu dancer wraps it around the head with a fluffy knot. It is hung around the neck at the prayer hall and was thrown over the shoulder in the past to signify social status. Guests are welcomed with the offering of a gamosa and tamul (betel nut) and elders are offered gamosas (bihuwaan) during Bihu. It is used to cover the altar at the prayer hall or cover the scriptures. An object of reverence is never placed on the bare ground, but always on a gamosa. One can, therefore, very well say that the gamosa symbolizes the life and culture of Assam.

Significantly the gamosa is used equally by all irrespective of religious and ethnic backgrounds.

At par with Gamosa, there are beautifully woven symbolic clothes with attractive graphic designs being used by different cultural ethno-cultural groups as well.

There were various other traditional symbolic elements and designs in use, which are now found only in literature, art, sculpture, architecture, etc. or used for only religious purposes (in particular occasions). The typical designs of assamese-lion, dragon, flying-lion, etc. were used for symbolising various purposes and occasions.

Festivals

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)
There are several important indigenous traditional festivals in Assam. Bihu/Bwisagu(for Kacharis) is the most celebrated festival among all. There are various Indigenous traditional festivals as well as belonging to different indigenous communities which are celebrated every year around different corners of Assam.

Bihu
Main article: Bihu

A group of Bihu dancers.

Youth wearing Assamese traditional costumes
Bihu is a series of three prominent festivals of Assam. Primarily a festival celebrated to mark the seasons and the significant points of a cultivator's life over a yearly cycle, in recent times the form and nature of celebration have changed with the growth of urban centers. Three Bihus are celebrated: Rongali, celebrated with the coming of spring and the beginning of the sowing season; Kongali, the barren Bihu when the fields are lush but the barns are empty; and the Bhogali, the thanksgiving when the crops have been harvested and the barns are full. Rongali, Kongali & Bhogali Bihu are also known as 'Bohag Bihu', 'Kati Bihu' & 'Magh Bihu' respectively. The day before each Bihu is known as uruka. There are unique features of each Bihu. The first day of 'Rongali Bihu' is called 'Goru Bihu' (the Bihu of the cows). On this day the cows are taken to the nearby rivers or ponds to be bathed with special care. Traditionally, cows are respected as sacred animals by the people of Assam. Bihu songs and Bihu dance are associated with rongali bihu.

Baisagu
Main article: Bwisagu
Bwisagu is a very popular seasonal festival of the Bodo of Assam. Bwisagu means the start of the new year. Bwisagu is a Boro word which originated from the word "Bwisa" which means year or age, and "Agu" that means New Year.

Chunbîl Melâ (Jonbeel Mela)
Main article: Jonbeel Mela
Jonbeel Mela (pron:ˈʤɒnˌbi:l ˈmeɪlə) (Tiwa: Chunbîl Melâ) is a three-day annual indigenous Tiwa Community fair held the weekend of Magh Bihu at a historic place known as Dayang Belguri at Joonbeel. It is 3 km from Jagiroad in Morigaon district of Assam and 32 km from Guwahati. The National Highway connecting the mela is NH 37. The Joonbeel (Joon and Beel are Assamese terms for the Moon and a wetland respectively) is so-called because a large natural water body is shaped like a crescent moon.

Beshoma
Beshoma is a festival of Deshi people.[5] It is a celebration of sowing crop. The Beshoma starts on the last day of Chaitra and goes on until the sixth of Baisakh. With varying locations it is also called Bishma or Chait-Boishne.[6]

Ali Ai Ligang
Main article: Ali Ai Ligang
Ali-Ai-Ligang is the spring festival of the Mising people of Assam, India. The name of the festival is made up of three terms, 'Ali', root and seed, 'Ai', fruit and 'Ligang', to sow.

Bohuwa dance
Main article: Bohuwa dance
Bohuwa dance is a festival of the Sonowal Kacharis of Assam, India.

Music
Main article: Music of Assam

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)
Assam, being the home to many ethnic groups and different cultures, is rich in folk music. The indigenous folk music has in turn influenced the growth of a modern idiom, that finds expression in the music of such artists are Jyoti Prasad Agarwala, Bishnuprasad Rabha, Parvati Prasad Baruva, Bhupen Hazarika, Nirmalendu Choudhury & Utpalendu Choudhury, Pratima Barua Pandey, Luit Konwar Rudra Baruah, Parvati Prasad Baruva, Jayanta Hazarika, Khagen Mahanta, Beauty Sarma Baruah. Among the new generation Zubeen Garg, Angaraag Mahanta, Kalpana Patowary, Joi Barua, Jitul Sonowal and Manoj Borah are well known.

And other than traditional Assamese music Assam's capital city Guwahati has become the country's capital for rock music other than Shillong. A number of talented rock bands have formed showcasing their talents around the world.

Traditional crafts
See also: Assam silk, Textiles and dresses of Assam, and Mask Art of Assam

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)

Mekhela, the traditional attire of women in Assam.
Pictured, one of the most exclusive variants, Muga Mekhela.
Assam has maintained a rich tradition of various traditional crafts for more than two thousand years. Presently, Cane and bamboo craft, bell metal and brass craft, silk and cotton weaving, toy and mask making, pottery and terracotta work, wood craft, jewellery making, musical instruments making, etc. are remained as major traditions. Historically, Assam also excelled in making boats, traditional guns and gunpowder, colours and paints, articles of lac, traditional building materials, utilities from iron, etc.

Cane and bamboo craft provides the most commonly used utilities in daily life, ranging from household utilities, weaving accessories, fishing accessories, furniture, musical instruments to building construction materials. Traditional utilities and symbolic articles made from bell metal and brass are found in every Assamese household. The Xorai and bota have been in use for centuries to offer gifts to respected persons and are two prominent symbolic elements. Hajo and Sarthebari are the most important centers of traditional bell-metal and brass crafts. Assam is the home of several types of silks, the most prominent and prestigious being Muga, the natural golden silk is exclusive only to Assam. Apart from Muga, there are other two varieties called Pat, creamy-bright-silver colored silk, and Eri, a variety used for manufacturing warm clothes for winter. Apart from Sualkuchi, the center for the traditional silk industry, in almost every part of the Brahmaputra Valley, rural households produce silk and silk garments with excellent embroidery designs. Moreover, various ethno-cultural groups in Assam make different types of cotton garments with unique embroidery designs and wonderful color combinations.

Moreover, Assam possesses unique crafts of toy and mask making mostly concentrated in the Vaishnav Hermitage, pottery and terracotta work in Western Assam districts and woodcraft, iron craft, jewelry, etc. in many places across the region. However, we can see Assam populated because of these.

Traditional clothes and fabric of the Assamese include Suriya, Pirawn, Gamusa, Jaapi, Mekhela chador, Riha, Tongali.

Paintings
Main article: Painting of Assam

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)

Sundarakanta Ramayan a medieval-century manuscript painting from Assam
Painting is an ancient tradition of Assam. The ancient practices can be known from the accounts of the Chinese traveller Xuanzang (7th century CE). The account mentions that Bhaskaravarma, the king of Kamarupa has gifted several items to Harshavardhana, the king of Magadha including paintings and painted objects, some of which were on Assamese silk. Many of the manuscripts available from the Middle Ages bear excellent examples of traditional paintings. The most famous of such medieval works are available in the Hastividyarnava (A Treatise on Elephants), the Chitra Bhagawata and in the Gita Govinda. The medieval painters used locally manufactured painting materials such as the colors of hangool and haital. The medieval Assamese literature also refers to chitrakars and patuas. Traditional Assamese paintings have been influenced by the motifs and designs in the medieval works such as the Chitra Bhagawata.

There are several renowned contemporary painters in Assam. The Guwahati Art College in Guwahati is the only government institution for tertiary education. Several art-societies and non-government initiatives exist across the state and the Guwahati Artists Guild is a front-runner organization based in Guwahati along with the Guwahati art college. There is a Department of Fine Arts in Assam University Silchar, a central government organization, and its thrust area concentrates on the art and craft of northeast India with special reference to Assam.

State anthem

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2017) (Learn how and when to remove this message)
Main article: O Mur Apunar Dekh
The song O Mur Apunar Dekh (অ’ মোৰ আপোনাৰ দেশ) (O my endearing country, 'desh', phonetically 'dex', with a talôibbô xô=country), composed by Rasaraj Lakshminath Bezbaroa, is popularly accepted as the state anthem of the state of Assam.