const andhraPradeshCulture = {
  traditionalWear: {
    women: [
      "Venkatagiri sarees",
      "Pedana sarees",
      "Bandarulanka sarees",
      "Uppada sarees",
      "Mangalagiri sarees",
      "Dharmavaram sarees"
    ]
  },
  handicrafts: {
    metalWare: "Budithi (Srikakulam)",
    musicalInstruments: "Veenas from Bobbili",
    toys: ["Etikoppaka", "Kondapalli"]
  },
  religionAndPhilosophy: {
    saints: [
      "Yogi Potuluri Veerabrahmam",
      "Nimbarka",
      "Mother Meera",
      "Sri Sathya Sai Baba",
      "Swami Sundara Chaitanyanandaji"
    ]
  },
  pilgrimagePlaces: [
    "Tirumala (Venkateswara)",
    "Annavaram (Satyanarayana)",
    "Daksharamam (Shiva)",
    "Simhachalam (Narasimha)",
    "Srisailam (Shiva - Jyotirlingam)",
    "Srikalahasti (Shiva - Panchalingam)",
    "Kanipakam (Ganesha)",
    "Kanaka Durga Temple (Vijayawada)"
  ],
  festivals: [
    "Makara Sankranti",
    "Maha Shivaratri",
    "Ugadi",
    "Sri Rama Navami",
    "Varalakshmi Vratam",
    "Vinayaka Chaviti",
    "Dasara",
    "Bathukamma",
    "Deepavali",
    "Karthika Deepothsavam"
  ],
  ceremonies: {
    vodiBiyyam: {
      meaning: "Vodi = Womb, Biyyam = Rice",
      description: "A traditional ceremony for married couples performed every three years.",
      elements: ["Turmeric rice", "Dried coconut core", "Hot chilli powder", "Five married women offering rice"]
    }
  },
  museums: [
    "Archaeological Museum at Amaravati",
    "Visakha Museum, Visakhapatnam",
    "Victoria Jubilee Museum, Vijayawada"
  ],
  culturalElements: [
    "Kondapalli toys",
    "Bapu's paintings",
    "Yenki Paatalu by Nanduri Subbarao",
    "Budugu by Mullapudi",
    "Annamayya's songs",
    "Aavakaaya",
    "Gongura",
    "Atla Taddi",
    "Godavari river",
    "Dudu Basavanna",
    "Durgi stone craft"
  ],
  architecture: {
    styles: [
      "Amaravati (Satavahana) style with abstract sculpture",
      "Granite and limestone temples and forts"
    ]
  },
  literature: {
    classicalPoets: ["Nannaya", "Tikkana", "Yerrapragada", "Srinatha", "Molla", "Tarikonda Venkamamba"],
    translators: ["Nannaya", "Tikkana", "Yerrapragada", "Potana"],
    modernAuthors: ["Charles Phillip Brown", "Vemana", "Sri Sri", "Viswanatha Satyanarayana"],
    famousQuotes: {
      krishnaDevaRaya: "Desha Bhashalandu Telugu lessa",
      bharathiyar: "Sundhara telungunil paatisaithu"
    }
  },
  cuisine: {
    mainDishes: [
      "Bandar Laddu",
      "Avakaya",
      "Gongura",
      "Pulusu",
      "Pappucharu",
      "Jonna Kudu",
      "Bobbattu",
      "Kaja",
      "Arisa"
    ],
    staple: "Rice",
    specialties: ["Pesarattu", "Attu", "Dosas", "Pappu"]
  },
  performingArts: {
    music: {
      classicalComposers: ["Annamacharya", "Tyagaraja", "Syama Sastri", "Kshetrayya", "Bhadrachala Ramadasu"],
      genre: "Carnatic music",
      folk: "Popular in rural areas"
    },
    dance: {
      classical: "Kuchipudi",
      historicalText: "Nritya Ratnavali by Jayapa Senani",
      folkForms: [
        "Chenchu Bhagotam",
        "Bhamakalapam",
        "Burrakatha",
        "Veeranatyam",
        "Butta Bommalu",
        "Dappu",
        "Tappeta Gullu",
        "Dhimsa",
        "Kolaatam"
      ]
    }
  },
  fashionAndJewelry: {
    textiles: ["Kalamkari", "Venkatagiri", "Langa-Voni"],
    gems: ["Koh-i-Noor", "Hope Diamond", "Others from Kollur mine"],
    jewelryDesigns: ["Vaddaanam", "Aravanke", "Kashulahaaram", "Buttalu"]
  },
  cinema: {
    industry: "Telugu cinema (Tollywood)"
  }
};
