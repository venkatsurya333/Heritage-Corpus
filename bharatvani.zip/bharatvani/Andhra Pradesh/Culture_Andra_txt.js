The culture of Andhra Pradesh embodies some very exclusive and special entities.

Women wear Venkatagiri, Pedana, Bandarulanka, Uppada, Mangalagiri, Dharmavaram sarees. The exclusive metal ware, brass, stone and wood carving from Budithi in Srikakulam District and Veenas from Bobbili and colourful toys from Etikoppaka and Kondapalli highlight the immense talent of the Andhra Pradeshi's.

Religion and philosophy
Andhra Pradesh is home to Hindu saints of all castes. An important figure is Saint Yogi Potuluri Veerabrahmam, who was a Viswa Brahmin who even had Brahmin, Shudra Harijan and Muslim disciples.[1] Fisherman Raghu was also a Shudra.[2]

Several important Hindu modern-day saints are from Andhra Pradesh. These include Nimbarka who founded Dvaitadvaita, Mother Meera who advocated the Indian Independence and Aurobindo Mission, Sri Sathya Sai Baba and Swami Sundara Chaitanyanandaji.

Pilgrimage places

Sacred Tirumala Temple
Annavaram, where the main temple is dedicated to the Hindu god Satyanarayana.
Daksharamam, where the main temple is dedicated to the Hindu god Shiva.
Tirupati or Tirumala, where the main temple is dedicated to the Hindu god Venkateswara.
Simhachalam is said in mythology to be the abode of the saviour-god Narasimha, who rescued Prahlada from abusive father Hiranyakasipu.
Srisailam is dedicated mainly to Shiva. It is one of the locations of the various Jyotirlingams.
Srikalahasti is also dedicated to Shiva. It is one of the panchalingam.
Kanipakam is a famous temple dedicated to Ganesha.
Kanaka Durga Temple in Vijayawada is a temple dedicated to Goddess Durga
Annual festivals
See also: List of festivals in Andhra Pradesh
Makara Sankranti/Pongal in January. Makara is the name of one of the twelve astrological signs (in Telugu they say Raasi) resembling a crocodile in shape, which means that the Sun entering northern direction in that particular Raasi.
Maha Shivaratri in February/March.
Ugadi or the Telugu New Year in March/April.
Sri Rama Navami celebrated in March/April 9 days after Ugadi.
Varalakshmi Vratam in August.
Vinayaka Chaviti in August.
Dasara in September/October.
Bathukamma in September/October (some parts of Andhra Pradesh
Deepavali in October/November.
Karthika Deepothsavam during the Deepavali season.
Vodi Biyyam
Vodi Biyyam (Vodi means the Womb and Biyyam means rice grains) is a traditional ceremony performed for married couples in some communities. The ceremony starts before the marriage. After marriage, the ceremony is performed at least once in three years, wherein the parents or the brother(s) of the married woman invite all the relatives for the ceremony celebration.[3]

The Process
The parents of the married woman give money to buy clothes for the ceremony. A good quantity of rice is mixed with turmeric, dried coconut core and other ingredients. Five married women (not widowed) come one after another and put rice in a cloth wrapped around the neck and spread out in the front. There is another food item which is hot chilli powder and rice.

Cultural institutions
Andhra Pradesh has many museums, including the Archaeological Museum at Amaravati Stupa near Guntur City that features relics of nearby ancient sites; the Visakha Museum in Visakhapatnam, which displays the history of the pre-Independence Madras Presidency in a rehabilitated Dutch bungalow; and Victoria Jubilee Museum in Vijayawada, which has a collection of ancient sculptures, paintings, idols, weapons, cutlery, and inscriptions.

Other cultural elements

Kondapalli toys at a house in Vijayawada
Other elements that have long defined Telugu culture include Bapu's paintings, Nanduri Subbarao's Yenki Paatalu (Songs on/by a washerwoman called Yenki), the mischievous Budugu (a character by Mullapudi), Annamayya's songs, Aavakaaya (a variant of mango pickle in which the kernel of the mango is retained), Gongura (a chutney from the Roselle plant), Atla Taddi (a seasonal festival predominantly for teenage girls), the banks of the river Godavari, and Dudu basavanna (the ceremonial ox decorated for door-to-door exhibition during the harvest festival Sankranti). The village of Durgi is known for originating stone craft, carvings of idols in soft stone that must be exhibited in the shade because they are prone to weathering.

Architecture

See also: Architecture of India by state and Indian vernacular architecture
There are two distinct architectural traditions in Andhra Pradesh. The first traces back to the building of the city of Amaravati under Satavahanas. This unique style of architecture emphasises the use of intricate and abstract sculpture with inspiration from religious themes. The second tradition draws on the enormous granite and limestone reserves of the region and is reflected in the various temples and forts built over a very long period of time.

Literature
Main article: Telugu literature
As an ancient language, Telugu has a rich and deep literary culture. Nannaya, Tikkana, Yerrapragada, Srinatha, Molla, and Tarikonda Venkamamba made the Telugu language alluring- a lingua franca for religion, musical composition and philosophy. The contributions of Charles Phillip Brown, Vemana, Sri Sri and Viswanatha Satyanarayana made Telugu a vibrant and evolving modern language. The contributions of various Telugu/Tamil/Sanskrit grammarians to the formalisation of English grammar gave Telugu literary traditions a truly global reach.

Telugu literature is highly influenced by Sanskrit literature and Hindu scriptures. Nannayya, Tikkana, and Yerrapragada form the trinity who translated the great epic Mahabharatha into Telugu. Bammera Potana is another great poet from Vontimitta (Kadapa district), famous for his great classic Sri Madandhra Maha Bhagavatamu, a Telugu translation of Sri Bhagavatam (authored by Veda Vyasa in Sanskrit). Nannayya derived the present Telugu script (lipi) from the old Telugu-Kannada script. Emperor Krishna Deva Raya wrote and also made the famous statement: "Desha Bhashalandu Telugu lessa" meaning "Telugu is the sweetest among all Indian languages". Famous Tamil poet Mahakavi Bharathiyar wrote "Sundhara telungunil paatisaithu", which literally means "create songs in beautiful Telugu". Philosophical poems by Yogi-Vemana are quite famous. Modern writers include Jnanpith Award winner Sri Viswanatha Satya Narayana. Revolutionary poets like SriSri and Joshua are popular.

Cuisine
Main article: Andhra cuisine

Mango pickle
The Andhra Pradesh cuisine includes bandar laddu, avakaya, gongura, pulusu, pappucharu, jonna kudu, bobbattu, kaja, and arisa. It uses spices, fruit and vegetable harvests of the region.

Rice is the staple food and is used in a wide variety of ways. Typically, rice is either boiled and eaten with curry, or made into a batter for use in a crepe-like dish called attu (pesarattu) or dosas. The rice is usually eaten with pappu, a simple curry. Pesarattu is different from attu and dosas; it has sprouts ground into the batter, making it green.

Meat, vegetables, and greens are prepared with different masalas into a variety of strongly flavored dishes.

Performing arts
The influential musical contributions of Annamacharya and Tyagaraja to the "grammar of sound" made the Telugu language the preferred language of composition for Carnatic music. Their influence not only on Carnatic but global classical music and the organisation of sound as a medium of emotional resonance is unparalleled. Kuchipudi, as a refinement of the ancient art of Bharatanatyam, and in the context of the unique religious and cultural traditions of Andhra Pradesh, stands on par with all the great global traditions of classical dance.

Dance
Main article: Kuchipudi

Kuchipudi, a traditional dance of Andhra Pradesh
Jayapa Senani (Jayapa Nayudu) was the first known author to write about the dance forms prevalent in Andhra Pradesh.[4] Both Desi and Margi forms of dance have been included in his Sanskrit treatise Nritya Ratnavali, which contains eight chapters. Folk dance forms like Perani, Prenkhana, Suddha Nartana, Carcari, Rasaka, Danda Rasaka, Shiva Priya, Kanduka Nartana, Bhandika Nrityam, Carana Nrityam, Chindu, Gondali and Kolatam are described. In the first chapter the author discusses the differences between Marga and Desi, Tandava and Lasya, Natya and Nritta. In the second and third chapters, he deals with Angi-Kabhinaya, Caris, Sthanakas and Mandalas. In the fourth chapter, Karnas, Angaharas and Recakas are described. In the following chapters, he describes local dance forms, e.g., Desi Nritya. In the last chapter, he deals with the art and practice of dance.

Classical dance in Andhra can be performed by both men and women; nowadays, women tend to learn it more often. Traditionally it was done by men and female temple dancers. Women did not dance it in public, and men played female parts in Kuchipudi ballets. As time went by, women began to learn it as an art as well. This started when women danced in kings' courts. Kuchipudi is the best-known classical dance form of Andhra Pradesh. The various dance forms that existed through the state's history are Chenchu Bhagotam, Kuchipudi, Bhamakalapam, Burrakatha, Veeranatyam, Butta bommalu, Dappu, Tappeta Gullu, Dhimsa, and Kolaatam.

Music
Main article: Music of Andhra Pradesh
The state has a rich musical heritage. Many legends of the Carnatic music, including two among the Trinity of Carnatic music (Thyagaraja and Syama Sastri), were of Telugu descent. Other composers include Annamacharya, Kshetrayya, and Bhadrachala Ramadasu. Folk songs are also popular in the rural areas of the state.

Movies
Main article: Telugu cinema
Costume
Andhra Pradesh is home to some of the finest historical cloth-making, fashion and dying traditions of the world. Its rich cotton production, with its innovative plant dye extraction history stand next to its diamond mining, pearl harvesting and jewelry traditions to form an impressive fashion tradition that has stood the test of time. The ancient Kollur mine is the mother of the numerous legendary gems such as the Koh-i-Noor and Hope Diamond. Andhra Pradesh had a virtual monopoly in the global jewelry industry till 1826 (founding of the diamond mines in Rhodesia, Africa) and eight of the ten most valuable jewelry pieces on earth today trace their history back to Andhra Pradesh. Langa-Voni (Half saree), Sarees made in Kalamkari, Venkatagiri are the result of this 3000-year-old fashion tradition. Vaddaanam, Aravanke, Kashulahaaram, Buttalu and various standard gold jewelry designs are fine examples of this continuously evolving ancient tradition.