Bihari culture refers to the culture of the Indian state of Bihar. Bihari culture includes Angika culture, Mithila culture, Bhojpuri Culture and the culture of Magadha.

Language and literature
Main articles: Languages in Bihar and Literature in Bihar
See also: Maithili language, Maithili literature, Bhojpuri language, Angika, Magahi, Magadhi Prakrit, Hindi in Bihar, and Urdu Language in Bihar
Language and script


(L) Bhojpuri story written in Kaithi (1898), (R) Maithili language in Tirhuta and Devanagari scripts
Famous Bihari Author


(L) Ramdhari Singh Dinkar, (R) Phanishwar Nath Renu
Bihar has produced a number of writers of Hindi, including Ramdhari Singh 'Dinkar',[1] Ram Briksh Benipuri, Phanishwar Nath 'Renu', Gopal Singh "Nepali", Baba Nagarjun Raja Radhika Raman Singh[2] and Shiva Pujan Sahay.[3] Mahapandit Rahul Sankrityayan, the great writer and Buddhist scholar, was born in U.P. but spent his life in the land of Lord Buddha, i.e., Bihar. Hrishikesh Sulabh and Neeraj Singh (from Ara) are the prominent writer of the new generation. They are short story writer, playwright and theatre critic. Arun Kamal and Aalok Dhanwa are the well-known poets. Different regional languages also have produced some prominent poets and authors. Sharat Chandra Chattopadhyay, who is among the greatest writers in Bengali, resided for some time in Bihar. Upamanyu Chatterjee also hails from Patna in Bihar. Devaki Nandan Khatri, who rose to fame at the beginning of the 20th century on account of his novels such as Chandrakanta and Chandrakanta Santati, was born in Muzaffarpur, Bihar. Bhikhari Thakur is known as the Shakespeare of Bhojpuri. Heera Dom, a Bhojpuri poet has contributed to Dalit literature. Vidyapati is the most renowned poet of Maithili (c. 14–15th century). Satyapal Chandra[4] has written many English best-seller novels and he is one of India's emerging young writer.

Despite the large number of speakers of Bihari languages, they have not been constitutionally recognised in India, except Maithili which is recognised under the Eighth Schedule of the Constitution of India. Hindi is the language used for educational and official matters in Bihar.[5] These languages were legally absorbed under the subordinate label of Hindi in the 1961 Census. Such state and national politics are creating conditions for language endangerment.[6] The first success in spreading Hindi occurred in Bihar in 1881, when Hindi displaced Urdu as the sole official language of the province. In this struggle between competing Hindi and Urdu, the potential claims of the three large mother tongues in the region – Bhojpuri, Maithili and Magahi were ignored. After independence Hindi was again given the sole official status through the Bihar Official Language Act, 1950.[7] Urdu became the second official language in the undivided State of Bihar on 16 August 1989. Bihar also produced several eminent Urdu writers including Kalim Aajiz, Bismil Azimabadi, Shad Azimabadi, Sulaiman Nadvi, Manazir Ahsan Gilani, Abdul Qavi Desnavi, Paigham Afaqui, Jabir Husain, Sohail Azimabadi, Hussain Ul Haque, Dr. Shamim Hashimi,[8] Wahab Ashrafi[9] etc.

Bihar has also produced some prominent poets and authors who write in various regional languages:

Sharat Chandra Chattopadhyay, who is among the most prominent authors who writes in Bengali, resided for some time in Bihar.
The Indian author who writes in English, Upamanyu Chatterjee, also hails from Patna in Bihar.
Devaki Nandan Khatri, who rose to fame at the beginning of the 20th century with his novels Chandrakanta and Chandrakanta Santati, was born in Muzaffarpur, Bihar.
Vidyapati Thakur, who wrote around the 14th to 15th centuries, is the most renowned Maithili-language poet in India.
Satyapal Chandra[10] has written many critically acclaimed best-sellers in English.[11]
Performing arts
Music and Dance of Bihar




(Top-Left) Bharat Ratna Ustad Bismillah Khan, from Dumraon, Bihar, (Top-Right) Padma Bhushan Sharda Sinha
(Bottom-Left)Magahi folksingers, (Bottom-Right) Jat Jatin folk dance
Drama and theatre
In 1984, Satish Anand had evolved a new 'Bidesia Style' for modern Indian theatre.[12] The new style used elements of traditional folk theatre from indigenous Bihari culture.[13] Some other traditional Bihari forms of theatre include those centred around Raja Salhesh, and the festival of Sama Chakeva originating from the Mithila region of Bihar.[14]

Dance
See also: Jhijhiya and Domkach
Jhijhiya is a ritual dance mostly performed at time of Dusshera, in dedication to Durga Bhairavi, the goddess of victory.[15] In Bihar, Domkach is a ceremonial dance form performed in the Magadh, Mithila and Bhojpur regions.[16] Bideshiya is a form of dance-drama that is believed to have been created by Bhikhari Thakur, a barber with a passion for drama.[17] It deals with social issues and conflict between traditional and modern, rich and poor. Fagua(performed in bhojpur and Magadh region) is a dance and also a type of folk song performed during Holi. Painki evokes the infantry's agility, courage, and excitement.[18] Danced on flat ground, it highlights the dancers' weapon-handling ability. Jat Jatin Dance of the Mithila region of Bihar is supposed to be performed on moonlit nights during the monsoons. Jhoomar is the most famous dance from Magadh region, It's performed during wedding and Karma puja, Jitiya etc. Danda Bhanjaul dance is also performed in Magadh region by yadava community during diwali in front of Bir Kuar baba( a folk deity). Sohar-Khilona dance is also performedin Magadh region dueing birth of a child. While Sohar is a folk song in other reguons but in Magadh it's also a dance form.[19]

Music
[icon]	
This section needs expansion. You can help by adding to it. (April 2025)
Main article: Music of Bihar
See also: Maithili music
Bihar has contributed a lot to the Indian classical music. Bihar has produced musicians like Bharat Ratna Ustad Bismillah Khan and dhrupad singers like the Malliks (Darbhanga Gharana) and the Mishras (Bettiah Gharana) along with poets like Vidyapati Thakur who contributed to Maithili Music.

Visual arts
Painting in Bihar




Top  : (L) Mithila Painting, (R) Patna Qualam Bottom  : (L) Tikuli Painting, (R) Bihari Paintings
Paintings
Main article: Painting in Bihar
See also: Mithila painting, Patna Qualam, and Manjusha Painting
There are several traditional styles of painting practised in Bihar. One is Mithila painting, a style of Indian painting used in the Mithila region of Bihar. The Mithila painting was one of the skills that were passed down from generation to generation in the families of the Mithila region, mainly by women. The painting was usually done on walls during festivals, religious events, and other milestones of the life cycle, like birth, Upanayanam (the sacred thread ceremony), and marriage.[20] Mithila painting was traditionally done on huts' freshly plastered walls. Today it is also done on cloth, handmade paper, and canvas. Mithila painting is also called Madhubani art.[21] It depicts human beings and their association with nature. The sun, moon, and religious plants like tulsi are widely painted. Following the scenes from the royal court and social events like weddings. Generally, no space is left empty.[20] Common scenes illustrate deities like Krishna, Ram, Shiva, Durga, Lakshmi, and Saraswati from ancient epics. Famous Mithila painters include Smt Bharti Dayal, Mahasundari Devi, the late Ganga Devi, and Sita Devi.

Historically, the Patna School of Painting (Patna Qualam), sometimes called Company Painting, flourished in Bihar during the early 18th to mid-20th centuries.[22] The Patna School of Painting was an offshoot of the well-known Mughal Miniature School of Painting. Those who practised this art form were descendants of Hindu artisans of Mughal painting. Facing persecution from the Mughal Emperor, Aurangzeb, these artisans found refuge, via Murshidabad, in Patna during the late 18th century.[22] Their art shared the characteristics of the Mughal painters. Whereas the Mughal style depicted only royalty and court scenes, the Patna artists also started painting bazaar scenes. They used watercolours on paper and on mica. The style's subject matter evolved to include scenes of Indian daily life, local rulers, festivals, and ceremonies. This school of painting formed the basis for the formation of the Patna Art School under the leadership of Shri Radha Mohan.[22] The School is an important centre of fine arts in Bihar.[23]

Alongwith Patna Qalam, Kohbar painting (a painting created during wedding rituals in kohbar room), Tikuli art(an art and painting originated from Patna around 800–1000 years ago), Sohrai painting(painted on walls during Sohrai/Gaiya dadh/Gaay parab to decorate walls of house) and Sujani art(originated in bhusura village of Arwal, mainly crafted on bedsheets, sarees etc) are also famous and important paintings from Magadh region or South Bihar.

Sculpture in Bihar


Top  : (L) Famous Didarganj Yakshi, (R) Modern Sculpture in Bihar Museum
Sculpture
Further information: Didarganj Yakshi, Mauryan polish, and Mauryan art
The first sculptures in Bihar date back to the Mauryan Empire. The Pillars of Ashoka, Masarh lion and Didarganj Yakshi are estimated to be at least 2000 years old, and were carved out of a single piece of stone.[24] Ancient statues are found throughout Bihar. Some of these sculptures were made from bronze, an advanced technique at that time. For example, the Sultanganj Buddha statue, estimated to be 1500 years old, is about seven feet tall and made of 500 kg of bronze, making it the largest statue of that period. Many statues, ranging from Hellenistic gods to various Gandharan lay devotees, are combined with what are thought to be early representations of the Buddha and Bodhisattvas.

Today, it is still unclear exactly when the Greco-Buddhist art of Gandhara emerged. However, evidence from Sirkap indicates that this style of art was already highly developed before the advent of the Kushans. Mandar Hill features the unique image of Lord Vishnu, from the Gupta period, in his man-lion incarnation. The image is 34 inches high and made of black stone.[25]

Architecture
Further information: Hindu temple architecture, Buddhist architecture, Mughal architecture, Indo-Islamic architecture, and Indo-Saracenic
Architecture of Bihar









Lomas Rishi Cave, Son Bhandar Caves Golghar, Sabhyata Dwar, Shergarh Fort, Darbhanga Fort, Great Buddha, Vasupujya Statue, Sher Shah Suri Tomb
The first significant architectural pieces in Bihar date back to the Vedic period. While the Mauryan period marked a transition to the use of brick, stone and wood remained the material of choice. Contemporary writers, like Chanakya in the Arthashastra, advised the use of brick and stone for their durability. However, in his writings, Megasthenes described a wooden palisade encircling the capital city of Pataliputra. Evidence of ancient structures have been found in recent excavations in Kumrahar, in modern-day Patna. Remains of an 80-pillared hall have also been unearthed.

The Buddhist stupa, a dome-shaped monument, was used in India as a commemorative monument used to enshrine sacred relics.[26] The stupa architecture was adopted in Southeast and East Asia, where it became prominent.[26] Many stupas, like those at Nalanda and Vikramshila, were originally built as brick and masonry mounds during the reign of Ashoka (273 BCE - 232 BCE). Fortified cities with stūpas, viharas, and temples were constructed during the Maurya empire (c. 321–185 BCE). Wooden architecture remained popular, while rock-cut architecture became solidified. Guard rails—consisting of posts, crossbars, and a coping—became a safety feature surrounding a stupa. Upon its discovery by Westerners, the stupa became known as pagoda in the West.[26]

Temples—built on elliptical, circular, quadrilateral, or apsidal plans—were constructed using brick and timber. The Indian gateway arches, the torana, reached East Asia with the spread of Buddhism.[27] Some scholars hold that torii derives from the torana gates at the Buddhist historic site of Sanchi (3rd century BCE – 11th century CE).[28]

Important features of the architecture during this period included walled and moated cities with large gates and multi-storied buildings, which consistently used arched windows and doors. . The Indian emperor Ashoka, who ruled from 273 BCE to 232 BCE, established a chain of hospitals throughout the Mauryan empire by 230 BCE.[29] One of the edicts of Ashoka reads: "Everywhere, King Piyadasi (Ashoka) erected two kinds of hospitals, hospitals for people and hospitals for animals. Where there were no healing herbs for people and animals, he ordered that they be bought and planted."[30]

Buddhist architecture blended with Roman and Hellenestic architecture to give rise to unique new styles, such as the Greco-Buddhist style.[31]

Rock-cut stepwells in India date from 200 to 400 CE.[32] Subsequently, the wells at Dhank (550–625 CE) and the stepped ponds at Bhinmal (850–950 CE) were constructed.[32]

Bihar was largely in ruins when visited by Xuanzang, and suffered further damage at the hands of Mughal raiders in the 12th century.[33] Though parts of the Bihar have been excavated, much of its ancient architecture still lies buried beneath the modern city.

Persian influence can be seen in surviving Mughal tombs made of sandstone and marble.[34] Surviving Mughal architecture includes Sher Shah Suri Tomb, built by Sher Shah Suri and his successor. Ibrahim Khan, Governor of Bihar and a disciple of Makhdum Daulat, oversaw the completion of Makhdum Daulat mausoleum in 1616.[35] Another example of Mughal architecture is the building at Maner Sharif. The domed building features walls adorned with intricate designs and a ceiling full of inscriptions from the Quran.

Patna High Court, Bihar Vidhan Sabha, Bihar Vidhan Parishad, Transport Bhawan, Patna, Golghar St. Mary's Church and Patna Museum are some example of Indo-Saracenic Architectures.

Strips or cane reeds painted in vivid colours are commonly found in homes of the people of Bihar. A special container called a "pauti," woven out of Sikki Grass Craft in the north, is a sentimental gift that accompanies a bride when she leaves her home after her wedding. Bihar is well known for the games played there, for example - Kabaddi.

Bhagalpur is well known for its sericulture, manufacture of silk yarn, and silk-weaving. Silk produced here is called tussah or tussar silk. Appliqué works in Bihar are known as Khatwa.

Cuisine
Traditional Bihari cuisine




Litti, Kadhi bari, Ghugni, Khichdi
Main article: Bihari cuisine
Bihari cuisine is eaten mainly in the eastern Indian state of Bihar, as well as in the places where people originating from the state of Bihar have settled: Jharkhand, Eastern Uttar Pradesh, Bangladesh, Nepal, Mauritius, South Africa, Fiji, some cities of Pakistan, Guyana, Trinidad and Tobago, Suriname, Jamaica, and the Caribbean. Bihari cuisine includes Angika cuisine, Bhojpuri cuisine,[36] Maithil cuisine and Magahi cuisine.

The cuisine of Bihar is largely similar to North indian cuisine and East Indian cuisines (for example Bengali cuisine). It is highly seasonal; watery foods such as watermelon and sharbat made from the pulp of the wood-apple fruit is consumed mainly in the summer months, while dry foods such as preparations made of sesame seeds and poppy seeds are consumed more frequently in the winter months.

There are numerous Bihari meat dishes, with chicken and mutton being the most common. Fish dishes are especially common in the Mithila region of North Bihar due to the number of rivers, such as the Sone, Gandak, Ganges and Koshi. Dairy products are consumed frequently throughout the year, including dahi (yogurt), spiced buttermilk (known as mattha), ghee, lassi and butter.

Dishes for which Bihar is famous include Litti (cuisine), Chokha, Kadhi bari, Ghugni, Khichdi, Bihari kebabs, Champaran meat, Machhak Jhor (fish curry), Makhana. Famous native sweets includes halwa of posta-dana and Makhana, Khaja, Tilkut and Anarasa.

Religion
Dharmic religion pilgrimages in Bihar








Vishnupad Temple, Gaya, Deo Surya Mandir, Mundeshwari Temple, Jal Mandir a Jain temple, Vietnam Temple, Bodh Gaya, Takht Sri Patna Sahib, Mahavir Mandir

This section does not cite any sources. Please help improve this section by adding citations to reliable sources. Unsourced material may be challenged and removed. (October 2018) (Learn how and when to remove this message)
Main article: Religion in Bihar
See also: Christianity in Bihar, Islam in Bihar, Jainism in Bihar, and Buddhism in Bihar
Religion in Bihar
Religion		Percent
Hinduism	
 
82.7%
Islam	
 
16.9%
Other	
 
0.4%
Hindu Goddess Sita, the consort of Lord Rama, is believed to have been born in Sitamarhi district in the Mithila region of modern-day Bihar.[37][38] It was the Ancient Bihar that give birth to new Indic religions: Buddhism and Jainism.[39] Gautama Buddha attained Enlightenment at Bodh Gaya, a town located in the modern-day district of Gaya in Bihar.[40] Vasupujya, the 12th Jain Tirthankara was born in Champapuri, Bhagalpur. Vardhamana Mahavira, the 24th and last Tirthankara of Jainism, was born in Vaishali around the 6th century BC.[41] Bodh Gaya in Bihar is an important pilgrimage center for the global Buddhists. The tenth Guru of the Sikhs, Guru Gobind Singh, was born here in 1666 and spent his early years here before moving to Anandpur.[42] The Gurdwara at Patna Sahib marks the birthplace of Guru Gobind Singh.[42]

Festivals
Chhath Mahaparv
Main article: Chhath

Chhath Puja
Chhath, also called "Dala Chhath", Surya vrat, is a Vedic festival celebrated in Bihar. It is celebrated twice a year: once in the summers, called the Chaiti Chhath, and once around a week after Deepawali, called the Karthik Chhath. The Karthik Chhath is more popular because winters are the usual festive season in northern India, and fasting without water for around 42 hours or more, as required for worshipers during Chhath Puja, is easier to do in the Indian winters.

In Chhath prayers are offered to Sun God, known as Surya.[43] Wherever people from Bihar have migrated, they have taken with them the tradition of Chhath. During chhath worshiper do ritual bathing that follows a period of abstinence and segregation from their main household for four days.[43] On the eve of Chhath, houses and their surroundings are scrupulously cleaned. Further, the ritual bathing and worship of the Sun God is performed twice: once in the evening and once at dawn, usually on the banks of a flowing river, or a common large water body. The main god worshiped is Aditya the sun god with his wife Ushas the evening dusk goddess and Kiran the dawn goddess and Aditi the mother of Gods, the occasion generally resembles a carnival.[43] For several days, ritual renditions of regional folk songs are sung. These folk songs have been carried on through oral transmission from mothers and mothers-in-law to daughters and daughters-in-law for generations. It is one of the oldest festivals continuously celebrated since the time of vedic period.

Durga Puja
Main article: Durga Puja

Durga Puja

Chief Minister of Bihar Nitish Kumar and Deputy Chief Minister of Bihar Samrat Chaudhary participating in Ravan Vadh ceremony during Dussera in Patna on 12 October 2024.
Durga puja is the second big festival of Bihar.[44] Here, it is celebrated for ten days. People do fasts. All married women perform Saanjh (transl. Evening) which means Sandhya Arti and "khoecha" is given to the goddess. Traditionally, in Bihar when a daughter comes to her father's house "khoecha" is given to her by her mother. It is believed that goddess Durga comes to her Maayka (transl. Mother's Home) from her Sasural (transl. Husband's Home) every year. Whole cities and villages are decorated with beautiful lights and pandals[45] are created for this grand occasion. During ten days of fasting pure vegetarian dishes are cooked in households. These dishes do not contain onion and garlic. Ritually, kanya pujan is performed on the auspicious day of Ashtami (transl. Eighth Day) and Navami (transl. Ninth Day). On Dashami (transl. Tenth Day) the "Visarjan puja" is performed in which "Jayanti from 'Kalash" is distributed to devotees and "Aprajita Pujan" is performed in which Goddess is worshiped from the vines of a flower named "Aprajita" (Clitoria ternatea). After Puja "Dahi Chhurra" (Curd (India) and Churra) is presented to Goddess Durga. The idols of goddess Durga are immersed in water (also, known as visarjan) on Dashmi or the Day after Dashmi. The visarjan of "Bari Devi ji" and "Choti Devi ji" in Patna and visarjan of "Bari Durga Maharani ji," "Choti Durga ji", "Bari Kali ji", and "Choti Kali ji" in Munger and Jamalpur holds a grand procession.

Saraswati Puja
Main article: Saraswati Puja

Saraswati Puja
Saraswati Puja is performed by students.[46] Usually, Students start preparations for the special day around one month early. It is mainly celebrated in schools and colleges. Nowadays, Saraswati puja is also performed in households and localities. In bihar, students offer their books and study materials as well as musical instruments in front of the goddess Saraswati who is believed to be the goddess of knowledge and wisdom.[47]

Other festivals
Other local festivals celebrated with fervour in Bihar include:

Sama Chakeva
Jivitputrika
Jur Sital
Teej
Bihula-Bishari Puja (celebrated in the Ang region of Bihar)
Buddha Purnima
Diwali;
Holi(Fagua, celebrated as new year in south Bihar)
Karma Puja(celebrated in Magadh region)
Godhan Kutai
Fair
Pitri Paksha Mela
Main article: Pitru Paksha
This is a 15-day fair held on the bank of River Falgu at Gaya during Pitru Paksha every year. Pilgrims from all parts of India visit Gaya, offering pinda to honor their ancestors. According to estimates from the Bihar Tourism Department, about 500,000 to 750,000 pilgrims arrive in Gaya each year during the Pitri Paksha Mela.[48]

Sonepur Mela
Main article: Sonepur Cattle Fair
The Sonepur cattle fair, a month-long event starting approximately half a month after Deepawali. Considered the largest cattle fair in Asia, it is held at the junction of the Ganges and Gandak Rivers, in the town of Sonepur. However, new laws governing the sale of animals and prohibiting the trafficking in exotic birds and beasts have adversely impacted the fair's success.
Sama Chakeva
Shravani Mela
Shravani Mela is an important month-long ritual observance, held along a 108-kilometre route linking the towns of Sultanganj and Deoghar (now located in the state of Jharkhand.) It is held every year in the Hindu month of Shravan (the lunar month of July–August). Pilgrims, known as Kanwarias, wear saffron-coloured clothes and collect water from a sacred Ghat (river bank) at Sultanganj. They walk the 108 km stretch barefoot to the town of Deoghar to bathe a sacred Shiva-Linga. The observance draws thousands of people from all over India to the town of Deoghar.

Media
Main article: Media in Bihar
Print
Popular Hindi newspapers in Bihar include the Hindustan Times, Dainik Jagran, Navbharat Times, Aj The Hindu and Prabhat Khabar. E-papers, such as the Bihar Times and Patna Daily, have become very popular among educated Biharis, especially those living outside the region. National English dailies like The Times of India and The Economic Times and Bihar Now are read in urban regions.

Electronic
Several national and international television channels are popular in Bihar. DD Bihar, Sahara Bihar, and Zee Bihar-Jharkhand are the channels dedicated specifically to Bihar. In 2008, two dedicated Bhojpuri channels, called Mahuaa TV,[49][50] and Purva TV[51] were launched.

Several government radio channels exist in Bihar. All India Radio has stations in Bhagalpur, Daltonganj, Darbhanga, Patna, Purnea, and Sasaram. Other government radio channels include Gyan Vani in Patna; Radio Mirchi, also in Patna; and Radio Dhamaal in Muzaffarpur.[52]

Cinema
Main articles: Cinema of Bihar and Bhojpuri Film Industry
See also: Bodhisattava International Film Festival and Patna Film Festival
See also: International Bhojpuri Film Awards, Bhojpuri Film Awards, and Sabrang Film Awards
Further information: List of Bhojpuri films, Category:Maithili-language films, and Category:Magahi-language films
Bihar has a robust Bhojpuri-language cinema industry. There are also small Maithili-, Angika- and Magadhi-language film industries in the region.

The earliest Bihari films were released in the 1960s.[53] The release of the first Magadhi-language film, called Bhaiyaa, released in 1961. It was the first movie of any Bihari language.[54] In 1963, a well-received Bhojpuri film, Ganga Maiyya Tohe Piyari Chadhaibo ("Mother Ganges, I will offer you a yellow sari"), was released, directed by Kundan Kumar.[55] in 1971, the first movie filmed in significant portions in the Maithili language, Kanyadan, was released. The first Angika movie was released in 2007, Khagadiya wali bhauji[56]

Over the next two decades, films were produced sporadically. In general, Bhojpuri films were not commonly made in the 1960s and 1970s. By the 1980s, though, enough Bhojpuri films had been made to comprise a small industry. Films such as Mai ("Mom," 1989, directed by Rajkumar Sharma) and Hamar Bhauji ("My Brother's Wife," 1983, directed by Kalpataru) continued to have at least sporadic success at the box office. However, this trend faded out by the end of the decade, and by 1990, the Bihari film industry seemed to be defunct.[57]

Yet the industry took off again in 2001 with the extremely popular Saiyyan Hamar ("My Sweetheart," directed by Mohan Prasad).[58] This success was quickly followed by several other very popular films, including Panditji Batai Na Biyah Kab Hoi ("Priest, tell me when I will marry," 2005, directed by Mohan Prasad) and Sasura Bada Paisa Wala ("My father-in-law, the rich guy," 2005). In a measure of the Bhojpuri film industry's rising status, both of these films did much better business in the states of Uttar Pradesh and Bihar than mainstream Bollywood hits did. Additionally, both films, made on extremely small budgets, earned back more than ten times their production costs.[59] The success, status, and visibility of Bhojpuri cinema has continued to increase. The industry now supports an awards show[60] and a trade magazine, Bhojpuri City,[61] and now produces over one hundred films per year. Many of the major stars of mainstream Bollywood cinema, including Amitabh Bachchan, have recently worked in Bhojpuri films.