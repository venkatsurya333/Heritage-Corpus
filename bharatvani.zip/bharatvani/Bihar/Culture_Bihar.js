const bihariCulture = {
    name: "Bihari Culture",
    regions: ["Angika", "Mithila", "Bhojpuri", "Magadha"],
    languageAndLiterature: {
        languages: [
            "Maithili",
            "Bhojpuri",
            "Angika",
            "Magahi",
            "Hindi",
            "Urdu"
        ],
        notableAuthors: [
            { name: "Ramdhari Singh Dinkar", contribution: "Hindi literature" },
            { name: "Phanishwar Nath Renu", contribution: "Hindi literature" },
            { name: "Vidyapati", contribution: "Maithili poetry" },
            { name: "Devaki Nandan Khatri", contribution: "Novels" },
            { name: "Bhikhari Thakur", contribution: "Bhojpuri literature" },
            { name: "Satyapal Chandra", contribution: "English best-sellers" }
        ],
        languageRecognition: {
            recognized: "Maithili",
            status: "Constitutionally recognized under the Eighth Schedule"
        }
    },
    performingArts: {
        music: {
            notableMusicians: [
                "Ustad Bismillah Khan",
                "Sharda Sinha"
            ],
            folkMusic: "Rich in folk music influenced by various ethnic groups."
        },
        dance: [
            { name: "Jhijhiya", description: "Ritual dance performed during Dusshera." },
            { name: "Domkach", description: "Ceremonial dance in Magadh, Mithila, and Bhojpur." },
            { name: "Bideshiya", description: "Dance-drama created by Bhikhari Thakur." },
            { name: "Fagua", description: "Dance and folk song performed during Holi." },
            { name: "Jat Jatin", description: "Performed on moonlit nights during monsoons." }
        ],
        dramaAndTheatre: {
            description: "Bidesia Style evolved in 1984, using elements of traditional folk theatre."
        }
    },
    visualArts: {
        paintings: {
            styles: [
                { name: "Mithila Painting", description: "Traditional painting style from Mithila region." },
                { name: "Patna Qualam", description: "Flourished during the early 18th to mid-20th centuries." },
                { name: "Kohbar Painting", description: "Created during wedding rituals." },
                { name: "Tikuli Art", description: "Originated from Patna around 800–1000 years ago." }
            ]
        },
        sculpture: {
            notableWorks: [
                "Didarganj Yakshi",
                "Pillars of Ashoka",
                "Sultanganj Buddha"
            ]
        },
        architecture: {
            styles: [
                "Buddhist Stupa",
                "Mughal Architecture",
                "Indo-Saracenic Architecture"
            ],
            notableStructures: [
                "Lomas Rishi Cave",
                "Sher Shah Suri Tomb",
                "Patna High Court"
            ]
        }
    },
    cuisine: {
        description: "Traditional Bihari cuisine is seasonal and varies by region.",
        notableDishes: [
            "Litti",
            "Kadhi Bari",
            "Ghugni",
            "Khichdi",
            "Bihari Kebabs"
        ]
    },
    religion: {
        predominantReligions: {
            Hinduism: "82.7%",
            Islam: "16.9%",
            Other: "0.4%"
        },
        notableSites: [
            "Bodh Gaya",
            "Vishnupad Temple",
            "Takht Sri Patna Sahib"
        ]
    },
    festivals: {
        majorFestivals: [
            { name: "Chhath", description: "Vedic festival dedicated to the Sun God." },
            { name: "Durga Puja", description: "Celebrated for ten days with fasting and rituals." },
            { name: "Saraswati Puja", description: "Celebrated by students, offering books to the goddess." }
        ],
        otherFestivals: [
            "Bihula-Bishari Puja",
            "Buddha Purnima",
            "Diwali",
            "Holi"
        ]
    },
    media: {
        print: {
            notableNewspapers: [
                "Hindustan Times",
                "Dainik Jagran",
                "Navbharat Times"
            ]
        },
        electronic: {
            notableChannels: [
                "DD Bihar",
                "Mahuaa TV",
                "Radio Mirchi"
            ]
        }
    },
    cinema: {
        description: "Bihar has a robust Bhojpuri-language cinema industry.",
        notableFilms: [
            { title: "Ganga Maiyya Tohe Piyari Chadhaibo", year: 1963 },
            { title: "Saiyyan Hamar", year: 2001 }
        ]
    }
};

console.log(bihariCulture);
